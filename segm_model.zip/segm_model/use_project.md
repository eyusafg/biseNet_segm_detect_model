## Release Note
### Summary
#### 主要功能
1.基于bisenet的分割网络

# change log
- v0.0.2: 新增openvino、 trt模型转换以及推理功能、 新增UI界面
- v0.0.1: 新增与plc通信调用摄像头实时推理功能以及优化dataset读取方式

# used
1、修改config 配置文件中数据集路径
2、修改tools中train的配置文件路径即可开始训练
3、python tools/train/train.py --cfg 配置文件路径
4、tools/test为推理文件
