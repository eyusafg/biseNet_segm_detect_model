import numpy as np
import cv2

def analyze_angle(y, contour_points, x_start, x_end):

    # # 设置虚拟水平线
    # virtual_horizontal_line_y = img_height - 100

    # # 将图像分为4段
    # segment_width = img_width / 4
    # x_start = segment_index * segment_width
    # x_end = (segment_index + 1) * segment_width

    # 截取该段轮廓点
    filtered_points = np.array([p for p in contour_points if x_start <= p[0] <= x_end])
    print('该段轮廓点数：{len(filtered_points)}')

    # 判断数量
    if len(filtered_points) < 2:
        return None, None, None, None, None, None, None
        raise ValueError("该段内的轮廓点数不足，无法计算角度")

    # # 计算该段外接矩
    # rect = cv2.


    # 计算该段的y值平均值
    avg_y = np.mean(filtered_points[:, 1])
    distance_to_horizontal = avg_y - y
    print(f'该段平均y值：{avg_y:.2f}')
    print(f'该段与水平线距离：{distance_to_horizontal:.2f} 像素')

    # 计算角度
    # 使用arctan2计算角度
    start_point = filtered_points[0]
    end_point = filtered_points[-1]
    dx = end_point[0] - start_point[0]
    dy = end_point[1] - start_point[1]
    angle_rad = np.arctan2(dy, dx)
    angle_deg = np.degrees(angle_rad)
    print(f'该段角度：{angle_deg:.2f} 度')

    # 中点
    mid_point = (start_point + end_point) / 2

    return filtered_points, angle_deg, distance_to_horizontal, mid_point, avg_y, start_point, end_point

def get_bottom_contour_segment(contour):
    """
    获取轮廓的底部线段：
    1. 找到轮廓的最左下和最右下两个点
    2. 获取这两个点之间的轮廓线段
    
    参数:
    contour: OpenCV轮廓点集
    
    返回:
    bottom_left_point: 最左下点 (x, y)
    bottom_right_point: 最右下点 (x, y)
    bottom_segment: 底部轮廓线段点集
    """
    # 将轮廓点转换为numpy数组
    points = np.array(contour).reshape(-1, 2)
    
    # 1. 找到最左下和最右下点
    # 最左下点：x最小，如果x相同则y最大
    leftmost_idx = np.argmin(points[:, 0])
    leftmost_x = points[leftmost_idx, 0]
    leftmost_candidates = points[points[:, 0] == leftmost_x]
    leftmost_point = leftmost_candidates[np.argmax(leftmost_candidates[:, 1])]
    
    # 最右下点：x最大，如果x相同则y最大
    rightmost_idx = np.argmax(points[:, 0])
    rightmost_x = points[rightmost_idx, 0]
    rightmost_candidates = points[points[:, 0] == rightmost_x]
    rightmost_point = rightmost_candidates[np.argmax(rightmost_candidates[:, 1])]
    
    print(f"最左下点: ({leftmost_point[0]:.1f}, {leftmost_point[1]:.1f})")
    print(f"最右下点: ({rightmost_point[0]:.1f}, {rightmost_point[1]:.1f})")
    
    # 2. 找到这两个点在轮廓中的索引位置
    leftmost_idx = np.where((points[:, 0] == leftmost_point[0]) & (points[:, 1] == leftmost_point[1]))[0][0]
    rightmost_idx = np.where((points[:, 0] == rightmost_point[0]) & (points[:, 1] == rightmost_point[1]))[0][0]
    
    # 3. 直接取两个端点之间的轮廓点集
    if leftmost_idx < rightmost_idx:
        # 从左到右
        segment_indices = np.arange(leftmost_idx, rightmost_idx + 1)
    else:
        # 从右到左，需要处理轮廓的循环特性
        segment_indices = np.concatenate([
            np.arange(leftmost_idx, len(points)),  # 从左端点到轮廓末尾
            np.arange(0, rightmost_idx + 1)        # 从轮廓开始到右端点
        ])
    
    segment_points = points[segment_indices]
    
    print(f"底部轮廓线段点数: {len(segment_points)}")
    
    # 4. 截取中间段
    # 按x坐标排序（确保顺序正确）
    segment_points = segment_points[np.argsort(segment_points[:, 0])]
    
    return leftmost_point, rightmost_point, segment_points

if __name__ == '__main__':

    mask_path = r'Glue_Pred_mask\20250909100048348.png.png'
    mask = cv2.imread(mask_path, cv2.IMREAD_GRAYSCALE)
    mask_bgr = cv2.cvtColor(mask, cv2.COLOR_GRAY2BGR)

    if mask is None:
        print('读取mask失败')
        exit()
    
    img_height, img_width = mask.shape
    virtual_horizontal_line_y = img_height - 100

    # 在宽度方向分为4段
    segment_index = 2
    # 2. 将图像宽度分为4段
    segment_width = img_width / 4
    x_start = segment_index * segment_width
    x_end = (segment_index + 1) * segment_width
    print(f"图像宽度: {img_width}, 每段宽度: {segment_width:.1f}")
    x_mid = int((x_start + x_end) / 2)
    print(f"截取第{segment_index + 1}段: x范围 [{x_start:.1f}, {x_end:.1f}]")


    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    if len(contours) == 0:
        print('未找到轮廓')
        exit()
    
    # 选择最大轮廓
    max_contour = max(contours, key=cv2.contourArea)
    bottom_left_point, bottom_right_point, bottom_segment = get_bottom_contour_segment(max_contour)

    contour_points = max_contour.reshape(-1, 2)
    try:
        angle_deg, distance_to_horizontal, mid_point, avg_y, start_point, end_point = analyze_angle(virtual_horizontal_line_y, bottom_segment, x_start, x_end)
        print(f"角度: {angle_deg:.2f} 度")
        print(f"距离: {distance_to_horizontal:.2f} 像素")
        print(f"中点坐标: ({mid_point[0]:.1f}, {mid_point[1]:.1f})")

        # 可视化结果
        cv2.circle(mask_bgr, bottom_left_point, 8, (255, 0, 0), -1)  # 蓝色：最左下
        cv2.circle(mask_bgr, bottom_right_point, 8, (255, 255, 0), -1)  # 青色：最右下
        cv2.circle(mask_bgr, (int(mid_point[0]), int(mid_point[1])), 5, (255, 0, 0), -1)  # 蓝色：中点
        cv2.circle(mask_bgr, (int(mid_point[0]), int(mid_point[1])), 5, (255, 0, 0), -1)  # 蓝色：中点
        cv2.line(mask_bgr, (int(x_start), 0), (int(x_start), img_height), (0, 255, 0), 2)
        cv2.line(mask_bgr, (int(x_end), 0), (int(x_end), img_height), (0, 255, 0), 2)
        for p in bottom_segment:
            cv2.circle(mask_bgr, (int(p[0]), int(p[1])), 2, (0, 0, 255), -1)  # 红色：轮廓点
        cv2.line(mask_bgr, (0, int(virtual_horizontal_line_y)), (img_width, int(virtual_horizontal_line_y)), (0, 255, 0), 2)
        cv2.line(mask_bgr, (x_mid, int(avg_y)), (x_mid, virtual_horizontal_line_y), (0, 255, 255), 2)
        cv2.line(mask_bgr, tuple(start_point.astype(int)), tuple(end_point.astype(int)), (255, 255, 0), 2)
        cv2.putText(mask_bgr, f"angle: {angle_deg:.2f}", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)
        cv2.putText(mask_bgr, f"distance: {distance_to_horizontal:.2f}px", (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)
        cv2.namedWindow('mask', cv2.WINDOW_NORMAL)
        cv2.imshow('mask', mask_bgr)
        cv2.waitKey(0)
        cv2.destroyAllWindows()
    
    except ValueError as e:
        print(e)
        exit()