"""
数据增强脚本 - 用于分割训练

【整体流程】
1. generate_variants(): 几何变换（旋转、缩放、翻转）+ 质量检查
2. apply_random_color_augmentation(): 颜色变换（HSV/LAB/单色）
3. save_xml_segment(): 保存mask轮廓点集到XML
4. 多进程并行处理

【功能说明】
1. 对图像进行几何变换（旋转、缩放、翻转等）
2. 应用可靠的颜色变换（HSV、LAB、单色变换），保留纹理细节
3. 处理两个mask：
   - mask: 整体mask（衣服）- 用于生成XML标注
   - mask_: 需要分割的目标mask - 用于颜色变换区域
4. 保存mask的轮廓点集用于分割训练（不包含关键点）
5. 多进程并行处理，提高效率

【颜色变换方法】（参考自augmentation_engine.py）
- hsv_shift: HSV颜色空间变换，保留原始亮度和纹理
- lab_transform: LAB颜色空间变换，保留亮度通道
- monochrome: 单色变换，完美保留纹理细节

【注意】
- 几何变换和颜色变换分离，避免双重变换
- 颜色变换仅应用于目标mask区域（mask_），不影响背景
- 质量检查确保mask面积和连通性符合要求
"""
import os
import cv2
import random
import numpy as np
import albumentations as A
from lxml import etree
import time
from tqdm import tqdm
import multiprocessing as mp
import glob
import xml.etree.ElementTree as ET

# 颜色增强方法列表
COLOR_METHODS = ['hsv_shift', 'lab_transform', 'monochrome']
NUM_COLOR_PER_GEOM = 4
MONOCHROME_TARGET_HUES = list(range(0, 180, 10))

def hsv_color_shift(img: np.ndarray, mask: np.ndarray, 
                   hue_shift: float = None,
                   sat_scale: float = None) -> np.ndarray:
    """
    HSV颜色空间变换，保留原始亮度和纹理
    
    Args:
        img: BGR图像 (uint8)
        mask: 二值掩码
        hue_shift: 色相偏移 (-180~180)，None则随机
        sat_scale: 饱和度缩放 (0.3~2.5)，None则随机
    """
    if img.dtype != np.uint8:
        img = np.clip(img, 0, 255).astype(np.uint8)
    
    result = img.copy()
    cloth_mask = mask > 0
    
    if not np.any(cloth_mask):
        return result
    
    # 转换到HSV空间
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV).astype(np.float32)
    h, s, v = cv2.split(hsv)
    
    # 保存原始亮度（纹理信息）
    original_v = v.copy()
    
    # 应用变换
    if hue_shift is None:
        hue_shift = np.random.uniform(-180, 180)
    if sat_scale is None:
        sat_scale = np.random.uniform(0.5, 2.0)
    
    # 仅在掩码区域变换
    h[cloth_mask] = (h[cloth_mask] + hue_shift) % 180
    s[cloth_mask] = np.clip(s[cloth_mask] * sat_scale, 0, 255)
    v[cloth_mask] = original_v[cloth_mask]  # 保留原始亮度
    
    # 转换回BGR
    hsv_transformed = cv2.merge([h, s, v]).astype(np.uint8)
    result = cv2.cvtColor(hsv_transformed, cv2.COLOR_HSV2BGR)
    
    return result

def lab_color_transform(img: np.ndarray, mask: np.ndarray,
                       a_scale: float = None,
                       b_scale: float = None) -> np.ndarray:
    """
    LAB颜色空间变换，保留亮度通道
    
    Args:
        img: BGR图像
        mask: 二值掩码
        a_scale: a通道缩放因子
        b_scale: b通道缩放因子
    """
    if img.dtype != np.uint8:
        img = np.clip(img, 0, 255).astype(np.uint8)
    
    result = img.copy()
    cloth_mask = mask > 0
    
    if not np.any(cloth_mask):
        return result
    
    # 转换到LAB空间
    lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB).astype(np.float32)
    l, a, b = cv2.split(lab)
    
    # 保存原始亮度
    original_l = l.copy()
    
    # 随机生成变换参数
    if a_scale is None:
        a_scale = np.random.uniform(0.6, 1.6)
    if b_scale is None:
        b_scale = np.random.uniform(0.6, 1.6)
    
    a_shift = np.random.uniform(-40, 40)
    b_shift = np.random.uniform(-40, 40)
    
    # 应用变换（仅在掩码区域）
    a[cloth_mask] = np.clip(
        (a[cloth_mask] - 128) * a_scale + 128 + a_shift, 
        0, 255
    )
    b[cloth_mask] = np.clip(
        (b[cloth_mask] - 128) * b_scale + 128 + b_shift, 
        0, 255
    )
    l[cloth_mask] = original_l[cloth_mask]  # 保留原始亮度
    
    # 转换回BGR
    lab_transformed = cv2.merge([l, a, b]).astype(np.uint8)
    result = cv2.cvtColor(lab_transformed, cv2.COLOR_LAB2BGR)
    
    return result

def texture_preserving_monochrome(img: np.ndarray, mask: np.ndarray,
                                 target_hue: int = None) -> np.ndarray:
    """
    单色变换，完美保留纹理细节
    
    Args:
        img: BGR图像
        mask: 二值掩码
        target_hue: 目标色相 (0-180)，None则随机
    """
    if img.dtype != np.uint8:
        img = np.clip(img, 0, 255).astype(np.uint8)
    
    result = img.copy()
    cloth_mask = mask > 0
    
    if not np.any(cloth_mask):
        return result
    
    # 获取原始亮度信息
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    original_v = hsv[:, :, 2].copy()
    
    # 生成单色HSV图像
    if target_hue is None:
        base_hue = random.choice(MONOCHROME_TARGET_HUES)
        jitter = np.random.randint(-5, 6)
        target_hue = int((base_hue + jitter) % 180)
    
    saturation = np.random.randint(50, 200)
    
    mono_hsv = hsv.copy()
    mono_hsv[cloth_mask, 0] = target_hue
    mono_hsv[cloth_mask, 1] = saturation
    mono_hsv[cloth_mask, 2] = original_v[cloth_mask]  # 保留原始亮度
    
    result = cv2.cvtColor(mono_hsv, cv2.COLOR_HSV2BGR)
    
    return result

def enhance_contrast_and_sharpness(img: np.ndarray) -> np.ndarray:
    if img.dtype != np.uint8:
        img = np.clip(img, 0, 255).astype(np.uint8)
    lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
    l, a, b = cv2.split(lab)
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    l_enhanced = clahe.apply(l)
    lab_enhanced = cv2.merge([l_enhanced, a, b])
    img_enhanced = cv2.cvtColor(lab_enhanced, cv2.COLOR_LAB2BGR)
    blurred = cv2.GaussianBlur(img_enhanced, (0, 0), sigmaX=1.0, sigmaY=1.0)
    alpha = 0.7
    sharp = cv2.addWeighted(img_enhanced, 1.0 + alpha, blurred, -alpha, 0)
    return sharp

def apply_random_color_augmentation(img: np.ndarray, mask: np.ndarray,
                                   method: str = None) -> np.ndarray:
    """
    随机应用一种颜色增强方法
    
    Args:
        img: BGR图像
        mask: 二值掩码
        method: 指定方法名，None则随机选择
    """
    methods = {
        'hsv_shift': hsv_color_shift,
        'lab_transform': lab_color_transform,
        'monochrome': texture_preserving_monochrome,
    }
    
    if method is None:
        method = random.choice(list(methods.keys()))
    
    if method in methods:
        return methods[method](img, mask)
    else:
        return img.copy()

def generate_variants(img_path, mask_path, mask_path_):
    """
    生成几何变换的增强样本（不包含颜色变换）
    
    Args:
        img_path: 图像路径
        mask_path: 整体mask路径（衣服）
        mask_path_: 目标mask路径（需要分割的部分）
    
    Returns:
        augmented_image, augmented_mask, augmented_mask_ (或 None, None, None)
    """
    image = cv2.imread(img_path)
    mask = cv2.imread(mask_path, cv2.IMREAD_GRAYSCALE)
    if mask_path_ is not None:
        mask_ = cv2.imread(mask_path_, cv2.IMREAD_GRAYSCALE)
    
    if image is None or mask is None:
        return None, None, None
    
    H, W = image.shape[:2]

    # 检查mask是否有效
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if len(contours) == 0:
        return None, None, None
    
    # 几何变换列表（不包含颜色变换，颜色变换在后续单独处理）
    transform_list = [
        # 步骤1: 几何变换（旋转、缩放、平移）
        A.ShiftScaleRotate(
            shift_limit=0.1,      # 平移范围：±10%
            scale_limit=0.2,      # 缩放范围：0.8-1.2倍
            rotate_limit=20,      # 旋转范围：±10度
            border_mode=cv2.BORDER_CONSTANT,
            value=0,
            p=0.5
        ),

        # 步骤2: 翻转变换
        A.HorizontalFlip(p=0.3),
        A.VerticalFlip(p=0.3),
    ]

    # 根据是否有第二个mask选择不同的compose
    if mask_path_ is not None:
        transform = A.Compose(transform_list, additional_targets={'mask_': 'mask'})
        augmented = transform(image=image, mask=mask, mask_=mask_)
    else:
        transform = A.Compose(transform_list)
        augmented = transform(image=image, mask=mask)
    
    # 质量检查：确保增强后的mask有效
    aug_mask = augmented['mask']
    aug_mask_ = augmented.get('mask_', None) if mask_path_ is not None else None

    # 检查1：mask面积变化不超过10%
    original_pixels = np.count_nonzero(mask)
    augmented_pixels = np.count_nonzero(aug_mask)
    
    if original_pixels == 0:
        return None, None, None
    
    area_ratio = augmented_pixels / original_pixels
    if not (0.9 <= area_ratio <= 1.1):
        return None, None, None
    
    # 检查2：mask的连通性（应该只有一个连通区域）
    num_labels, _ = cv2.connectedComponents(aug_mask)
    if num_labels != 2:  # 背景算一个，物体算一个，总共2个
        return None, None, None
    
    # 检查3：如果有第二个mask，也要检查其有效性
    if aug_mask_ is not None:
        aug_pixels_ = np.count_nonzero(aug_mask_)
        if aug_pixels_ == 0:
            return None, None, None
    
    return augmented['image'], aug_mask, aug_mask_

def save_xml_segment(mask, mask_, img_name, xml_temp_dir):
    """保存XML片段到临时文件"""
    contour = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)[0][0].reshape(-1, 2)
    if mask_ is not None:
        contour_ = cv2.findContours(mask_, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)[0][0].reshape(-1, 2)

    h, w = mask.shape
    image_id = int(time.time() * 1000) + random.randint(1000, 9999)  # 更唯一的时间戳
    
    # 使用标准的xml.etree.ElementTree，它支持pickle
    img_child = ET.Element('image')
    img_child.set('id', str(image_id))
    img_child.set('name', '%s' % img_name)
    img_child.set('subset', 'Train')
    img_child.set('width', str(w))
    img_child.set('height', str(h))

    polygon_child = ET.Element('polygon')
    polygon_points = []
    for pt in contour:
        polygon_points.append('%.2f,%.2f' % (pt[0], pt[1]))

    polygon_child.set('label', '衣服')
    polygon_child.set('occlued', str(0))
    polygon_child.set('source', 'augmented_with_trans')
    polygon_child.set('z_order', '0')
    polygon_child.set('points', ';'.join(polygon_points))
    img_child.append(polygon_child)

    # 将XML元素保存到临时文件
    temp_xml_path = os.path.join(xml_temp_dir, f"{img_name.split('.')[0]}_{image_id}.xml")
    tree = ET.ElementTree(img_child)
    tree.write(temp_xml_path, encoding='utf-8', xml_declaration=True)
    
    return temp_xml_path

def process_single_image(args):
    """处理单个图像的多进程函数"""
    img_name, img_path, mask_path, mask_path_, save_img_path, xml_temp_dir, task_id = args
    
    try:
        img_path_full = os.path.join(img_path, img_name)
        mask_path1 = os.path.join(mask_path, img_name)
        mask_path_1 = os.path.join(mask_path_, img_name) if mask_path_ else None
        
        if not os.path.exists(mask_path_1):
            mask_path_1 = None

        augmented_imgs, augmented_masks, augmented_masks_ = generate_variants(img_path_full, mask_path1, mask_path_1)
        # cv2.namedWindow('augmented_masks', cv2.WINDOW_NORMAL)
        # cv2.namedWindow('augmented_masks_', cv2.WINDOW_NORMAL)
        # cv2.imshow('augmented_masks', augmented_masks)
        # cv2.imshow('augmented_masks_', augmented_masks_)
        # cv2.waitKey(0)
        # cv2.destroyAllWindows()
        if augmented_imgs is None:
            return None

        base_img = enhance_contrast_and_sharpness(augmented_imgs)

        # 应用随机颜色变换，使用目标mask（如果有mask_则使用mask_，否则使用mask）
        target_mask = augmented_masks_ if mask_path_1 is not None else augmented_masks

        results = []
        for color_idx in range(NUM_COLOR_PER_GEOM):
            result_img = apply_random_color_augmentation(base_img, target_mask)

            # 生成新的图像名称
            img_name_new = img_name.split('.')[0] + f'_{task_id}_{color_idx}.png'
            
            # 保存图像
            cv2.imwrite(os.path.join(save_img_path, img_name_new), result_img)
            
            # 保存XML片段
            if mask_path_1 is None:
                xml_path = save_xml_segment(augmented_masks, None, img_name_new, xml_temp_dir)
            else:
                xml_path = save_xml_segment(augmented_masks, augmented_masks_, img_name_new, xml_temp_dir)
            
            results.append((img_name_new, xml_path))
        
        return results
    except Exception as e:
        print(f"处理图像 {img_name} 时出错: {e}")
        return None

def merge_xml_files(xml_temp_dir, output_xml_path):
    """合并所有XML片段文件"""
    # 创建根元素
    root = ET.Element('annotations')
    
    # 获取所有临时XML文件
    xml_files = glob.glob(os.path.join(xml_temp_dir, "*.xml"))
    
    for xml_file in xml_files:
        try:
            tree = ET.parse(xml_file)
            xml_root = tree.getroot()
            # 将每个image元素添加到根元素中
            root.append(xml_root)
        except Exception as e:
            print(f"解析XML文件 {xml_file} 时出错: {e}")

    # 美化XML输出
    def prettify(element, indent='  '):
        """美化XML元素，添加缩进和换行"""
        queue = [(0, element)]  # (level, element)
        while queue:
            level, element = queue.pop(0)
            children = [(level + 1, child) for child in list(element)]
            if children:
                element.text = '\n' + indent * (level + 1)  # 为有子元素的元素添加换行和缩进
            if queue:
                element.tail = '\n' + indent * queue[0][0]  # 为元素尾部添加换行和缩进
            else:
                element.tail = '\n' + indent * (level - 1)  # 最后一个元素
            queue[0:0] = children  # 将子元素添加到队列前面

    prettify(root)     

    # 保存合并后的XML文件
    tree = ET.ElementTree(root)
    tree.write(output_xml_path, encoding='utf-8', xml_declaration=True)
    
    # 清理临时文件
    for xml_file in xml_files:
        try:
            os.remove(xml_file)
        except:
            pass

def main():
    img_path = r'C:\DH_data\polo_img\roi\total_imgs'
    mask_path = r'C:\DH_data\polo_img\roi\cutout_mask\polo_total\imgs\masks_cloth'
    mask_path_ = r'C:\DH_data\polo_img\roi\cutout_mask\polo_total\imgs\masks'

    save_img_path = 'Dataset/gending/polo_total_1128/imgs'
    save_xml_path = 'Dataset/gending/polo_total_1128'
    xml_temp_dir = 'Dataset/gending/polo_total_1128/temp_xml'
    
    if not os.path.exists(save_img_path):
        os.makedirs(save_img_path)
    if not os.path.exists(save_xml_path):
        os.makedirs(save_xml_path)
    if not os.path.exists(xml_temp_dir):
        os.makedirs(xml_temp_dir)

    num_aug = 4000
    num_processes = min(mp.cpu_count(), 6)  # 使用CPU核心数，最多8个进程

    # 获取所有图像文件
    img_files = [f for f in os.listdir(img_path) if f.endswith('.png')]
    
    # 准备任务参数
    tasks = []
    for i in range(num_aug):
        img_name = random.choice(img_files)
        tasks.append((img_name, img_path, mask_path, mask_path_, save_img_path, xml_temp_dir, i))

    # 使用多进程处理
    successful_count = 0
    
    with mp.Pool(processes=num_processes) as pool:
        with tqdm(total=num_aug, desc='正在生成') as pbar:
            for result in pool.imap_unordered(process_single_image, tasks):
                if result is not None:
                    if isinstance(result, list):
                        successful_count += len(result)
                    else:
                        successful_count += 1
                pbar.update(1)

    # 合并所有XML片段
    output_xml_file = os.path.join(save_xml_path, 'annotations_auged.xml')
    merge_xml_files(xml_temp_dir, output_xml_file)
    
    # 清理临时目录
    try:
        os.rmdir(xml_temp_dir)
    except:
        pass
    
    print(f"成功生成 {successful_count} 个增强样本")

if __name__ == '__main__':
    main()