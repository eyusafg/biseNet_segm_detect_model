from lxml import etree
import os
import cv2


def parse_key_points_xml(xml_path: str, img_name: str):

    tree = etree.parse(xml_path)
    root = tree.getroot()
    points = None
    for child in root[:]:
        if child.tag == 'image':
            if len(child) < 1:
                continue
            img_path = child.get('name')
            if img_name != img_path:
                continue
           
            h = int(child.get('height'))
            w = int(child.get('width'))

            for anno in child[:]:
                label_type = anno.tag
                if label_type in ('polygon'):  # only supports points
                    label_name = anno.get('label')
                    if label_name != '衣服':
                        continue
                    points = [point.split(',') for point in anno.get('points').split(';')]
                
    return points


im_p = r'Dataset\gending\thor_1030\imgs'
img_paths = os.listdir(im_p)
xml_path = r'Dataset\gending\thor_1030\annotations_auged.xml'
                    
                                       

cv2.namedWindow('img', cv2.WINDOW_NORMAL)
for img_name in img_paths:
    points = parse_key_points_xml(xml_path, img_name)
    if points is None:
        print(f"正在处理图像: {img_name}")

        continue

    img_path = os.path.join(im_p, img_name)

    img = cv2.imread(img_path)


    for kpt in points: 
        x,y = float(kpt[0]), float(kpt[1])
        cv2.circle(img, (int(x), int(y)), 5, (0, 0, 255), -1)
       
    cv2.imshow('img', img)
    cv2.waitKey(0)  # To pause the display until a key is pressed

  
   
cv2.destroyAllWindows()















# def parse_key_points_xml(xml_path: str, base_p: str):
#     tree = etree.parse(xml_path)
#     root = tree.getroot()
#     img_names_in_xml = set()  # 使用集合来存储xml中提到的图像名称
    
#     for child in root[:]:
#         if child.tag == 'image':
#             img_name = child.get('name')
#             img_names_in_xml.add(img_name)  # 将图像名称添加到集合中
#             if len(child) < 3:
#                 continue
#             h = int(child.get('height'))
#             w = int(child.get('width'))
#             img_anno_pts = []
#             for anno in child[:]:
#                 label_type = anno.tag
#                 if label_type != 'points':  # 仅支持points标签
#                     continue
#                 points = anno.get('points').split(';')[0].split(',')
#                 x, y = float(points[0]), float(points[1])
#                 if x < 0 or x > w or y < 0 or y > h:
#                     break
#                 img_anno_pts.append((x, y))
#             yield img_name, img_anno_pts
    
#     yield 'img_names_in_xml', img_names_in_xml

# base_p = r'Datasets\gened_img\Round_Neck\Have_sleeves\Flat_shouder\aug'
# im_p = os.path.join(base_p, 'images')
# img_paths = os.listdir(im_p)
# xml_path = os.path.join(base_p, 'annotations_auged.xml')

# # 解析xml并获取所有在xml中的图像名称
# img_names_in_xml = None
# for img_name, kpts in parse_key_points_xml(xml_path, base_p):
#     if img_name == 'img_names_in_xml':
#         img_names_in_xml = kpts
#         break

# # 遍历im_p目录中的所有图像，并删除不在xml中的图像
# for img_name in img_paths:
#     if img_name not in img_names_in_xml:
#         img_path_to_delete = os.path.join(im_p, img_name)
#         os.remove(img_path_to_delete)
#         print(f"已删除不在xml中的图像: {img_name}")
#     else:
#         print(f"正在处理图像: {img_name}")
#         img_path = os.path.join(im_p, img_name)
#         kpts = parse_key_points_xml(xml_path, base_p)
#         for img_name, kpts in kpts:
#             if img_name != img_path:
#                 continue
#             img = cv2.imread(img_path)
#             for i, kpt in enumerate(kpts):
#                 cv2.circle(img, (int(kpt[0]), int(kpt[1])), 5, (0, 0, 255), -1)
#             cv2.imshow('img', img)
#             cv2.waitKey(0)  # 按任意键显示下一张图像
#             cv2.destroyAllWindows()



