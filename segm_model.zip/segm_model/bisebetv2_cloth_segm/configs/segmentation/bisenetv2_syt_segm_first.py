
## bisenetv2
cfg = dict(
    use_syt_dataset=True,
    n_cats=2,  # 类
    in_ch=3,  # 输入的通道数
    ims_per_gpu=22,  # batch_size
    eval_ims_per_gpu=16,  # batch_sizes
    # 在syt_dataset时，填写图像路径, cvat格式的xml命名为annotations.xml
    train_im_anns='/home/syt/datasets/first/train',
    # 在syt_dataset时，填写图像路径, cvat格式的xml命名为annotations.xml
    val_im_anns='/home/syt/datasets/first/val',
    target_size=(384, 384),  # 32倍数
    # resize(cols, rows) (x, y) (width,height)

    model_type='bisenetv2',
    epochs=1000,
    num_aux_heads=4,
    lr_start=5e-3,
    weight_decay=1e-4,
    warmup_iters=1000,
    max_iter=180000,
    dataset='CocoStuff',  # 在syt_dataset时，没有作用
    im_root='./datasets/coco',  # 在syt_dataset时，没有作用
    scales=[0.75, 2.],
    cropsize=[640, 640],
    eval_crop=[640, 640],
    eval_scales=[0.5, 0.75, 1, 1.25, 1.5, 1.75],
    use_fp16=False,
    use_sync_bn=False,
    respth='./output/segmentation/res',

    net_config={'DetailBranch':
        {
            'S1': [64, 64],
            'S2': [64, 64, 64],
            'S3': [128, 128, 128]
        },
        'SegmentBranch': {
            'S3': [32],
            'S4': [64],
            'S5_4': [128],
            # 'S5_5': [128], S5_5 = DetailBranch 'S3'
        },
        'BGALayer': {
            'bga': [128]
        },
        'SegmentHead': {
            'head': [1024],
            # 下面SegmentHead仅用于模型训练过程
            'aux2': [128],
            'aux3': [128],
            'aux4': [128],
            'aux5_4': [128]
        }

    }

)
