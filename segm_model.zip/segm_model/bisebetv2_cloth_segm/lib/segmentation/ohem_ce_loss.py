#!/usr/bin/python
# -*- encoding: utf-8 -*-


import torch
import torch.nn as nn
import torch.nn.functional as F


#  import ohem_cpp
#  class OhemCELoss(nn.Module):
#
#      def __init__(self, thresh, lb_ignore=255):
#          super(OhemCELoss, self).__init__()
#          self.score_thresh = thresh
#          self.lb_ignore = lb_ignore
#          self.criteria = nn.CrossEntropyLoss(ignore_index=lb_ignore, reduction='mean')
#
#      def forward(self, logits, labels):
#          n_min = labels[labels != self.lb_ignore].numel() // 16
#          labels = ohem_cpp.score_ohem_label(
#                  logits, labels, self.lb_ignore, self.score_thresh, n_min).detach()
#          loss = self.criteria(logits, labels)
#          return loss


class OhemCELoss(nn.Module):

    def __init__(self, thresh, lb_ignore=255):
        super(OhemCELoss, self).__init__()
        self.thresh = -torch.log(torch.tensor(thresh, requires_grad=False, dtype=torch.float)).cuda()
        self.lb_ignore = lb_ignore
        self.criteria = nn.CrossEntropyLoss(ignore_index=lb_ignore, reduction='none')

    def forward(self, logits, labels):
        n_min = labels[labels != self.lb_ignore].numel() // 16
        loss = self.criteria(logits, labels).view(-1)
        loss_hard = loss[loss > self.thresh]
        if loss_hard.numel() < n_min:
            loss_hard, _ = loss.topk(n_min)
        return torch.mean(loss_hard)
    
class CustomLoss(nn.Module):
    '''
    将多通道的label拆分，逐一计算每个通道的损失，最后求平均'''
    def __init__(self, thresh, lb_ignore=255):
        super(CustomLoss, self).__init__()
        self.thresh = -torch.log(torch.tensor(thresh, requires_grad=False, dtype=torch.float)).cuda()
        self.lb_ignore = lb_ignore
        self.criteria = nn.BCEWithLogitsLoss(reduction='none')

    def forward(self, logits, labels):

        batch_size, num_classes, height, width = logits.size()
        # print(num_classes)

        total_loss = 0.0
        for c in range(num_classes):
            if c == self.lb_ignore:
                continue

            logits_c = logits[:, c, :, :]
            labels_c = labels[:, c, :, :].float()  

            loss_c = self.criteria(logits_c, labels_c).view(-1)

            loss_hard = loss_c[loss_c > self.thresh]
            if loss_hard.numel() < batch_size:
                loss_hard, _ = loss_c.topk(batch_size)

            total_loss += loss_hard.mean()

        return total_loss / num_classes

if __name__ == '__main__':
    pass

