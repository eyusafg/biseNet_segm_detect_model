import copy

import numpy as np
import cv2
def get_max_contour(contours):
    max_idx = -1
    max_area = 0
    for i in range(len(contours)):
        area = cv2.contourArea(contours[i])
        if area > max_area:
            max_area = area
            max_idx = i
    return contours[max_idx]
def generate_boxes_along_contour(contour: np.array,image_size = (2748, 3672), box_size = (384, 384), shift_size=16, box_step=1.0):
    contour = np.array(contour)

    boxes = []
    i = 0
    j = 1
    point_num = len(contour)
    min_x_diff = 0
    min_y_diff = 0
    max_x_diff = 0
    max_y_diff = 0
    lt = copy.deepcopy(contour[0])
    rb = copy.deepcopy(contour[0])
    while j < point_num:
        if lt[0] > contour[j][0]:
            lt[0] = contour[j][0]
        if lt[1] > contour[j][1]:
            lt[1] = contour[j][1]
        if rb[0] < contour[j][0]:
            rb[0] = contour[j][0]
        if rb[1] < contour[j][1]:
            rb[1] = contour[j][1]
        vec_ij = rb - lt
        min_x_diff = vec_ij[0] if vec_ij[0] < min_x_diff else min_x_diff
        min_y_diff = vec_ij[1] if vec_ij[1] < min_y_diff else min_y_diff
        max_x_diff = vec_ij[0] if vec_ij[0] > max_x_diff else max_x_diff
        max_y_diff = vec_ij[1] if vec_ij[1] > max_y_diff else max_y_diff
        if (abs(vec_ij[0]) >= box_step * box_size[0]) or (abs(vec_ij[1]) >= box_step * box_size[1]):

            # 如果i和j的欧氏距离超过阈值，就画一个框，包络i到j之间所有的轮廓点
            box = {}
            box['x'] = lt[0] + min_x_diff
            box['y'] = lt[1] + min_y_diff
            box['width'] = max_x_diff - min_x_diff
            box['height'] = max_y_diff - min_y_diff

            offset_w = box_size[0] - box['width']
            offset_h = box_size[1] - box['height']
            # 确保box的大小符合box size
            # shift 将框增大一圈，确保囊括目标
            box['x'] -= offset_w / 2.0 + shift_size
            box['y'] -= offset_h / 2.0 + shift_size
            box['width'] += 2.0 * shift_size + offset_w
            box['height'] += 2.0 * shift_size + offset_h

            # 使其成为正方形
            max_length = max([box['width'], box['height']])
            if max_length % 32 != 0:
                max_length = np.ceil(max_length / 32) * 32

            x_center = box['x'] + box['width'] // 2
            y_center = box['y'] + box['height'] // 2

            box['x'] = x_center - max_length // 2
            box['y'] = y_center - max_length // 2
            box['width'] = max_length
            box['height'] = max_length

            # 将框增大一圈，确保囊括目标
            # box['x'] -= shift_size
            # box['y'] -= shift_size
            # box['width'] += 2 * shift_size
            # box['height'] += 2 * shift_size

            # 当边框位于图像边缘，且不满足box size，则往内偏移。
            if box['x'] + box_size[0] >= image_size[0]:
                box['x'] -= (box['x'] + box_size[0] - image_size[0]) + 1
            if box['y'] + box_size[1] >= image_size[1]:
                box['y'] -= (box['y'] + box_size[1] - image_size[1]) + 1


            box['x'] = 0 if box['x'] < 0 else box['x']
            box['y'] = 0 if box['y'] < 0 else box['y']


            # box['width'] = image_size[0] - box['x'] if box['x'] + box['width'] > image_size[0] else box['width']
            # box['height'] = image_size[1] - box['y'] if box['y'] + box['height'] > image_size[1] else box['height']

            boxes.append(box)

            min_x_diff = min_y_diff = max_x_diff = max_y_diff = 0
            i = j
            j = i + 1
            # lt = rb = contour[i]
            lt = copy.deepcopy(contour[i])
            rb = copy.deepcopy(contour[i])
        else:
            j += 1

        # 如果j - i 大于1， 说明还有一段轮廓没被框选
    if (j - i) > 1:
        j -= 1
        box = {}
        box['x'] = lt[0] + min_x_diff
        box['y'] = lt[1] + min_y_diff
        box['width'] = max_x_diff - min_x_diff
        box['height'] = max_y_diff - min_y_diff
        offset_w = box_size[0] - box['width']
        offset_h = box_size[1] - box['height']
        # 确保box的大小符合box size
        # shift 将框增大一圈，确保囊括目标
        box['x'] -= offset_w / 2.0 + shift_size
        box['y'] -= offset_h / 2.0 + shift_size
        box['width'] += 2.0 * shift_size + offset_w
        box['height'] += 2.0 * shift_size + offset_h


        max_length = max([box['width'], box['height']])
        if max_length % 32 != 0:
            max_length = np.ceil(max_length / 32) * 32

        x_center = box['x'] + box['width'] // 2
        y_center = box['y'] + box['height'] // 2

        box['x'] = x_center - max_length // 2
        box['y'] = y_center - max_length // 2
        box['width'] = max_length
        box['height'] = max_length

        # 将框增大一圈，确保囊括目标
        # box['x'] -= shift_size
        # box['y'] -= shift_size
        # box['width'] += 2 * shift_size
        # box['height'] += 2 * shift_size
        # 当边框位于图像边缘，且不满足box size，则往内偏移。
        if box['x'] + box_size[0] >= image_size[0]:
            box['x'] -= (box['x'] + box_size[0] - image_size[0]) + 1
        if box['y'] + box_size[1] >= image_size[1]:
            box['y'] -= (box['y'] + box_size[1] - image_size[1]) + 1
        box['x'] = 0 if box['x'] < 0 else box['x']
        box['y'] = 0 if box['y'] < 0 else box['y']

        # box['width'] = image_size[0] - box['x'] if box['x'] + box['width'] > image_size[0] else box['width']
        # box['height'] = image_size[1] - box['y'] if box['y'] + box['height'] > image_size[1] else box['height']

        # box['width'] = box_size[0] + 2 * shift_size
        # box['height'] = box_size[0] + 2 * shift_size

        boxes.append(box)
        # 最后一个轮廓点到最开始轮廓点之间没有画框，需要补上
    j = len(contour) - 1
    min_x_diff = min_y_diff = max_x_diff = max_y_diff = 0
    vec_ij = contour[j] - contour[0]
    min_x_diff = vec_ij[0] if vec_ij[0] < min_x_diff else min_x_diff
    min_y_diff = vec_ij[1] if vec_ij[1] < min_y_diff else min_y_diff
    max_x_diff = vec_ij[0] if vec_ij[0] > max_x_diff else max_x_diff
    max_y_diff = vec_ij[1] if vec_ij[1] > max_y_diff else max_y_diff
    box = {}
    box['x'] = lt[0] + min_x_diff
    box['y'] = lt[1] + min_y_diff
    box['width'] = max_x_diff - min_x_diff
    box['height'] = max_y_diff - min_y_diff
    offset_w = box_size[0] - box['width']
    offset_h = box_size[1] - box['height']
    # 确保box的大小符合box size
    # shift 将框增大一圈，确保囊括目标
    box['x'] -= offset_w / 2.0 + shift_size
    box['y'] -= offset_h / 2.0 + shift_size
    box['width'] += 2.0 * shift_size + offset_w
    box['height'] += 2.0 * shift_size + offset_h

    max_length = max([box['width'], box['height']])
    if max_length % 32 != 0:
        max_length = np.ceil(max_length / 32) * 32

    x_center = box['x'] + box['width'] // 2
    y_center = box['y'] + box['height'] // 2

    box['x'] = x_center - max_length // 2
    box['y'] = y_center - max_length // 2
    box['width'] = max_length
    box['height'] = max_length
    if box['x'] + box_size[0] >= image_size[0]:
        box['x'] -= (box['x'] + box_size[0] - image_size[0]) + 1
    if box['y'] + box_size[1] >= image_size[1]:
        box['y'] -= (box['y'] + box_size[1] - image_size[1]) + 1
    # box['x'] -= shift_size
    # box['y'] -= shift_size
    # box['width'] += 2 * shift_size
    # box['height'] += 2 * shift_size

    box['x'] = 0 if box['x'] < 0 else box['x']
    box['y'] = 0 if box['y'] < 0 else box['y']
    # box['width'] = image_size[0] - box['x'] if box['x'] + box['width'] > image_size[0] else box['width']
    # box['height'] = image_size[1] - box['y'] if box['y'] + box['height'] > image_size[1] else box['height']

    # boxes.append(box)

    return boxes