# 2
# (30, 1, 2)
# (1245, 1, 2)
# contours_tl, _ = cv2.findContours(mask_tl.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
# contour_tl = get_max_contour(contours_tl)
import sys
sys.path.insert(0, '')
from lxml import etree
import os
import numpy as np
import time
def contours_to_cvat(img_child, contours:tuple, img_size, polygon_label, img_name):
    image_id = img_name
    # image_name = '%s/%s.png' % ('img', img_name)
    image_name = '%s.png' % (img_name)
    if len(contours) == 0:
        img_child.set('id', str(image_id))
        img_child.set('name', str(image_name))
        img_child.set('subset', 'Train')
        img_child.set('width', str(img_size[0]))
        img_child.set('height', str(img_size[1]))
        polygon_points = []
        polygon_child = etree.Element('polygon')
        polygon_child.set('label', polygon_label)
        polygon_child.set('occlued', str(0))
        polygon_child.set('source', 'img_to_cvat')
        polygon_child.set('z_order', '0')
        polygon_child.set('points', ';'.join(polygon_points))
        img_child.append(polygon_child)
        return img_child
    for contour in contours:
        contour = contour.reshape(contour.shape[0], contour.shape[2])

        img_child.set('id', str(image_id))
        img_child.set('name', str(image_name))
        img_child.set('subset', 'Train')
        img_child.set('width', str(img_size[0]))
        img_child.set('height', str(img_size[1]))

        polygon_points = []
        for pt in contour:
            polygon_points.append('%.2f,%.2f' % (pt[0], pt[1]))

        polygon_child = etree.Element('polygon')
        polygon_child.set('label', polygon_label)
        polygon_child.set('occlued', str(0))
        polygon_child.set('source', 'img_to_cvat')
        polygon_child.set('z_order', '0')
        polygon_child.set('points', ';'.join(polygon_points))
        img_child.append(polygon_child)
    return img_child
if __name__ == '__main__':
    etree_root = etree.Element('annotations')
    output_root_dir = 'C:/Users/Administrator/dataset/cvat/'
    if not os.path.exists(output_root_dir + '/img'):
        os.mkdir(output_root_dir + '/img')
    contours = (np.array([[[1,2]], [[2,3]],[[4,5]]]),
                np.array([[[11, 12]], [[12, 13]], [[14, 15]],[[16, 17]],[[18, 19]]])
                )
    contours_to_cvat(etree_root,contours,[100,200], 'mask','1')
    contours = (np.array([[[21,2]], [[23,3]],[[4,5]]]),
                np.array([[[71, 12]], [[52, 13]], [[14, 15]],[[16, 17]],[[18, 19]]])
                )
    contours_to_cvat(etree_root, contours, [100, 200], 'mask', '2')
    # xml_string = etree.tostring(root, pretty_print=True, encoding="utf-8",xml_declaration=True)
    # pretty_xml = etree.tounicode(etree.fromstring(xml_string), pretty_print=True, method='xml')
    # xml_string = etree.tounicode(root, pretty_print=True, method='xml')
    xml_string = etree.tostring(etree_root, encoding='utf-8', pretty_print=True, method='xml')
    xml_file_path = os.path.join(output_root_dir, 'annotations.xml')
    with open(xml_file_path, 'wb') as f:
        f.write(xml_string)