#!/usr/bin/env python
# -*- encoding: utf-8 -*-

import sys
sys.path.insert(0, '')
sys.path.append('bisebetv2_cloth_segm')
import torch
from torch.utils.data import Dataset
from lib.segmentation.data.syt_segm_augment import Augmentation
import copy
import cv2
import os
import numpy as np
from lib.segmentation.data.get_data_list import get_image_list, get_cvat_list, get_cvat_data
from torchvision import transforms


class SytSegmDataset(Dataset):
    def __init__(self, data_root_path, 
                 class_mapping={'背景': 0,'衣服': 255,}, 
                 class_colors= {0: (0,0,0),1: (255, 0, 0)}, 
                 inv=False, 
                 target_size=(640, 480), 
                 in_ch=3, 
                 augment_flag=True, 
                 return_img=False):
        self.in_ch_ = in_ch
        self.data_root_path_ = data_root_path
        self.augment_flag_ = augment_flag
        self.return_img = return_img
        self.class_mapping = class_mapping
        self.class_colors = class_colors
        self.inv = inv
        self.xml_files_ = []
        for dirpath, dirnames, filenames in os.walk(data_root_path):
            # print(dirnames)

            for filename in filenames:
                if os.path.splitext(filename)[-1] == '.xml':
                    # file_path = os.path.join(dirpath, filename)
                    self.xml_files_.append((dirpath, filename))
            # break
        if not len(self.xml_files_)==0:
            self.cvat_mode_ = True
            self.image_list_ = []
            self.image_first_index_ = [-1]
            for (dirpath, filename) in self.xml_files_:
                self.image_list_.extend(get_cvat_list(dirpath, filename))
                self.image_first_index_.append(len(self.image_list_) - 1)
        else:

            # self.image_dir_ = os.path.join(data_root_path, "images/")
            # self.label_dir_ = os.path.join(data_root_path, "labels/")
            # self.mask_dir_ = os.path.join(data_root_path, "masks/")
            # if os.path.exists(self.image_dir_) == False or os.path.exists(self.label_dir_) == False:
            #     raise Exception("SytDataset: Invalid Path!")
            self.cvat_mode_ = False
            self.image_list_, self.label_list_ = get_image_list(data_root_path)



        if self.in_ch_ == 4:
            self.tensor_mean = [0.5, 0.5, 0.5, 0]
            self.tensor_std = [0.5, 0.5, 0.5, 1.0]

        else:
            self.tensor_mean = [0.5, 0.5, 0.5]
            self.tensor_std = [0.5, 0.5, 0.5]
        self.img_transform = transforms.Compose([transforms.ToTensor(),
                                                 transforms.Normalize(self.tensor_mean, self.tensor_std,
                                                                          inplace=True)])

        self.target_size = target_size
        if self.in_ch_ == 4:
            aug_option = [4, 6, 7, 10, 11]
        else:
            aug_option = [1, 4, 6, 7, 10,12]
        self.aug_ = Augmentation(aug_option)

    def __len__(self):
        dataset_len = len(self.image_list_)
        if self.augment_flag_:
            dataset_len = dataset_len * 4  # 数据增强4张图: 不翻转1张，翻转3张，然后处理图片
        return dataset_len

    def __getitem__(self, index):
        # img_path = os.path.join(self.image_dir_, self.image_list_[index])
        if self.augment_flag_:
            aug_mode = index % 4
            curr_index = index// 4
        else:
            aug_mode = 0
            curr_index = index

        if not self.cvat_mode_:
            img_path = self.data_root_path_ + '/' + self.image_list_[curr_index]
            label_path = self.data_root_path_ + '/' + self.label_list_[curr_index]

            # label_path = os.path.join(self.label_dir_, "label_" + self.image_list_[index].split('_')[-1])
            img = cv2.imread(img_path, cv2.IMREAD_COLOR)
            label = cv2.imread(label_path, cv2.IMREAD_GRAYSCALE)
            if self.in_ch_ == 4:
                mask_path_split = os.path.split(self.label_list_[curr_index])
                mask_path = self.data_root_path_ + '/' + os.path.split(mask_path_split[0])[0] + '/masks/' + \
                            mask_path_split[-1]
                mask = cv2.imread(mask_path, cv2.IMREAD_GRAYSCALE)
                if self.return_img == False:
                    mask = cv2.resize(mask, self.target_size, interpolation=cv2.INTER_NEAREST)
        else:
            image_first_index_length = len(self.image_first_index_)
            for i in range(image_first_index_length):
                if curr_index > self.image_first_index_[i] and (curr_index <= self.image_first_index_[i+1]):
                    img, label, mask = get_cvat_data(self.xml_files_[i][0], self.image_list_[curr_index], self.in_ch_, self.class_mapping, self.class_colors, self.inv)
                    break
            if self.in_ch_ == 4 and self.return_img == False:
                mask = cv2.resize(mask, self.target_size, interpolation=cv2.INTER_NEAREST)

        if not self.return_img:
            img = cv2.resize(img, self.target_size, interpolation=cv2.INTER_NEAREST)
            label = cv2.resize(label, self.target_size, interpolation=cv2.INTER_NEAREST)
            img = np.ascontiguousarray(img[:, :, ::-1])  #bgr to rgb
        if self.in_ch_ == 4:
            if self.augment_flag_:
                img, label, mask  = self.aug_.augment_task(img, label, mask, aug_mode)
            mask = np.where(mask > 0, 255, 0).astype(np.uint8)
            # cv2.imshow("label", label)
            # cv2.imshow("mask", mask)
            # cv2.imshow("img", img)
            # cv2.waitKey(0)
            if not len(mask.shape) == 3:
                img = np.dstack((img, np.expand_dims(mask, axis=-1)))
            else:
                img = np.dstack((img, mask))
        else:
            if self.augment_flag_:
                img, label, _ = self.aug_.augment_task(img, label, [], aug_mode)
            # label = np.where(label > 0, 255, 0).astype(np.uint8)
            # cv2.imshow("label", label)
            # cv2.imshow("img", img)
            # cv2.waitKey(0)
        # img = np.ascontiguousarray(img)
        if self.return_img:
            return img, label
        # label = np.where(label > 0, 1, 0)
        # print(img.shape)
        # print(label.shape)
        img_tensor = self.img_transform(copy.deepcopy(img))
        # label_copy = np.copy(label).transpose(2, 0, 1)
        # label_tensor = torch.as_tensor(label_copy, dtype=torch.int64).long()
        label_cp = np.copy(label)
        label_tensor = torch.as_tensor(label_cp, dtype=torch.int64)
        return img_tensor, label_tensor
if __name__ == '__main__':
    in_channle = 4
    input_dir = r'D:\thor_rib_segment_data\Datasets\round_neck_113\test\img'
    class_mapping = {
    '背景': 0,
    '衣服': 255,
    # 'mask': 255
 }
    class_colors = {0: [0, 0, 0], 1: [0, 255, 0]}
    inv = False
    # dataset = SytSegmDataset(r'C:\Users\Administrator\dataset\cvat_dataset',
    #                          in_ch=in_channle, augment_flag=False,return_img=True)
    dataset = SytSegmDataset(input_dir,class_mapping,  class_colors, inv, in_ch=in_channle,augment_flag=False,return_img=True )
    print(len(dataset))


    # dataset = SytSegmDataset("/home/syt/datasets/cloth/train")
    if in_channle == 4:
        cv2.namedWindow('mask', cv2.WINDOW_KEEPRATIO)
    cv2.namedWindow('label', cv2.WINDOW_KEEPRATIO)
    cv2.namedWindow('img', cv2.WINDOW_KEEPRATIO)
    # dataset = SytSegmDataset("/home/syt/datasets/cloth_segment/second_stage/train")
    # dataset = SytSegmDataset("/home/syt/datasets/cloth_segment/ClothSegment/train")

    # dataset = SytSegmDataset(r'C:\Users\Administrator\dataset\clothEdgeData\val', augment_flag=False, return_img=True)

    for idx, (img, label) in enumerate(dataset):
        # return numpy
        # label = np.where(label > 0, 255, 0).astype(np.uint8)
        print(label.shape)
        print(img.shape)
        print(type(img))
        if in_channle == 4:
            mask = copy.deepcopy(img[:, :, 3:])
            img = img[:, :, :3].astype(np.uint8)

            cv2.imshow("mask", mask)
        contours, hierarchy = cv2.findContours(label, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
        cv2.drawContours(img, contours, -1, (200, 200, 50), 2)
        cv2.imshow('img', img)
        cv2.imshow("label", label)

        if cv2.waitKey(0) == ord('q'):
            cv2.destroyAllWindows()
            break



        # # return tensor
        # label_img = label.numpy()
        # label_img *= 255
        # label_img = label_img.astype(np.uint8)
        # #cv2.waitKey(0)
        #
        # # 反转归一化
        # original_img = img[:3].clone()
        # original_img[0] = (original_img[0] * dataset.tensor_std[0]) + dataset.tensor_mean[0]
        # original_img[1] = (original_img[1] * dataset.tensor_std[1]) + dataset.tensor_mean[1]
        # original_img[2] = (original_img[2] * dataset.tensor_std[2]) + dataset.tensor_mean[2]
        #
        # # original_img[3] = (original_img[3] * dataset.tensor_std[3]) + dataset.tensor_mean[3]
        # original_img = original_img.clip(0, 1)  # 将数据范围限制在 [0, 1]
        #
        # # 反转ToTensor转换
        # original_img = original_img.numpy()
        # original_img = (original_img.transpose(1, 2, 0) * 255).astype(np.uint8)
        # original_img = cv2.cvtColor(original_img, cv2.COLOR_RGB2BGR)
        # contours, hierarchy = cv2.findContours(label_img, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
        # cv2.drawContours(original_img, contours, -1, (200, 200, 50), 2)
        #
        # # 使用OpenCV显示
        # cv2.imshow('img', original_img)
        # cv2.imshow("label", label_img)
        # if cv2.waitKey(0) == ord('q'):
        #     cv2.destroyAllWindows()
        #     break

