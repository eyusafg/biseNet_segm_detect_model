import xml.etree.ElementTree as ET
import os
import cv2
import numpy as np
from tqdm import tqdm

def xml2txt(path_root, im_save_path, mk_save_path, target_size, class_map):
    
    xml_file = [os.path.join(path_root, f) for f in os.listdir(path_root) if f.endswith('.xml')]
    if xml_file:
        for xml_path in xml_file:
            tree = ET.parse(xml_path)
            root = tree.getroot()
            for image_tree in tqdm(root.findall('image')):
                image_name = image_tree.get('name')
                im = cv2.imread(os.path.join(path_root, image_name))
                h, w = im.shape[:2]
                im = cv2.resize(im, target_size, interpolation=cv2.INTER_NEAREST)
                cv2.imwrite(os.path.join(im_save_path, image_name.replace('.jpg', '.png')), im)
                # with open(txt_path, 'w') as t:
                #     t.
                polygons = image_tree.findall('polygon')

                label_map = np.zeros((h,w), dtype=np.uint8)
                
                for polygon in polygons:
                    label = polygon.get('label')
                    points_str = polygon.get('points')
                    points = [list(map(float, point.split(','))) for point in points_str.split(';')]
                    contour = np.array(points, dtype=np.int32)
                    contour = contour.reshape((-1, 1, 2))
                    cv2.drawContours(label_map, [contour], -1, class_map[label], -1)
                label_map = cv2.resize(label_map, target_size, interpolation=cv2.INTER_NEAREST) 
                cv2.imwrite(os.path.join(mk_save_path, image_name.replace('.jpg', '.png')), label_map)    
                   




if __name__ == '__main__':

    path_root = 'D:\Data\Round_neck'
    # txt_path ='./train.txt'
    im_save_path = 'D:\Data\\DRD_round_neck\\img_dir\\val'
    os.makedirs(im_save_path, exist_ok=True)
    mk_save_path = 'D:\Data\\DRD_round_neck\\ann_dir\\val'
    os.makedirs(mk_save_path, exist_ok=True)
    target_size = (640, 640)
    class_map = {'背景': 0, '衣服': 1}
    xml2txt(path_root, im_save_path, mk_save_path, target_size, class_map)