from torchvision import transforms
import cv2
import numpy as np
from PIL import Image
import random
import torchvision.transforms.functional as tf
import copy
class Augmentation:
    def __init__(self, aug_option=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10,11, 12]):
        self.aug_option = aug_option

    def rotate(self, image, label, mask, angle=None):
        if angle == None:
            angle = transforms.RandomRotation.get_params([-15, 15])  # -180~180随机选一个角度旋转
        if isinstance(angle, list):
            angle = random.choice(angle)
        image = image.rotate(angle)
        image = np.asarray(image)
        label = label.rotate(angle)
        label = np.asarray(label)
        if type(mask) == list:
            mask_empty = True
        else:
            mask_empty = False
        if not mask_empty:
            mask = mask.rotate(angle)
            mask = np.asarray(mask)
        return image, label, mask

    def flip(self, image, label, mask):  # 水平翻转和垂直翻转
        if random.random() > 0.5:
            if type(mask) == list:
                mask_empty = True
            else:
                mask_empty = False
            image = tf.hflip(image)
            if not mask_empty:
                mask = tf.hflip(mask)
            label = tf.hflip(label)
        if random.random() < 0.5:
            if type(mask) == list:
                mask_empty = True
            else:
                mask_empty = False
            image = tf.vflip(image)
            if not mask_empty:
                mask = tf.vflip(mask)
            label = tf.vflip(label)
        image = np.asarray(image)
        if type(mask) == list:
            mask_empty = True
        else:
            mask_empty = False
        if not mask_empty:
            mask = np.asarray(mask)
        label = np.asarray(label)
        return image, label, mask

    def randomResizeCrop(self, image, label, mask, scale=(0.3, 1.0),
                         ratio=(1, 1)):  # scale表示随机crop出来的图片会在的0.3倍至1倍之间，ratio表示长宽比
        img = np.array(image)

        h_image, w_image, _ = img.shape
        resize_size = h_image
        i, j, h, w = transforms.RandomResizedCrop.get_params(image, scale=scale, ratio=ratio)
        image = tf.resized_crop(image, i, j, h, w, resize_size)
        if type(mask) == list:
            mask_empty = True
        else:
            mask_empty = False
        if not mask_empty:
            mask = tf.resized_crop(mask, i, j, h, w, resize_size)
            mask = np.asarray(mask)
        label = tf.resized_crop(label, i, j, h, w, resize_size)
        image = np.asarray(image)
        label = np.asarray(label)
        return image, label, mask

    def adjustContrast(self, image, label, mask):
        # factor = transforms.RandomRotation.get_params([0.2, 6])  # 这里调增广后的数据的对比度
        factor = transforms.RandomRotation.get_params([0.2, 4])  # 这里调增广后的数据的对比度
        image = tf.adjust_contrast(image, factor)
        # mask = tf.adjust_contrast(mask,factor)
        image = np.asarray(image)
        if type(mask) == list:
            mask_empty = True
        else:
            mask_empty = False
        if not mask_empty:
            mask = np.asarray(mask)
        label = np.asarray(label)
        return image, label, mask

    def adjustBrightness(self, image, label, mask):
        # factor = transforms.RandomRotation.get_params([0.4, 1.7])  # 这里调增广后的数据亮度
        factor = transforms.RandomRotation.get_params([0.4, 1.6])  # 这里调增广后的数据亮度
        image = tf.adjust_brightness(image, factor)
        # mask = tf.adjust_contrast(mask, factor)
        image = np.asarray(image)
        if type(mask) == list:
            mask_empty = True
        else:
            mask_empty = False
        if not mask_empty:
            mask = np.asarray(mask)
        label = np.asarray(label)
        return image, label, mask

    def centerCrop(self, image, label, mask, size=None):  # 中心裁剪
        if size == None: size = image.size  # 若不设定size，则是原图。
        image = tf.center_crop(image, size)
        if type(mask) == list:
            mask_empty = True
        else:
            mask_empty = False
        if not mask_empty:
            mask = tf.center_crop(mask, size)
            mask = np.asarray(mask)
        label = tf.center_crop(label, size)
        image = np.asarray(image)
        label = np.asarray(label)
        return image, label, mask

    def adjustSaturation(self, image, label, mask):  # 调整饱和度
        factor = transforms.RandomRotation.get_params([0.5, 2.5])  # 这里调增广后的数据亮度
        image = tf.adjust_saturation(image, factor)
        # mask = tf.adjust_saturation(mask, factor)
        image = np.asarray(image)
        label = np.asarray(label)
        if type(mask) == list:
            mask_empty = True
        else:
            mask_empty = False
        if not mask_empty:
            mask = np.asarray(mask)
        return image, label, mask
    def add_blur(self, image, label, mask):
        image = np.asarray(image)
        if type(mask) == list:
            mask_empty = True
        else:
            mask_empty = False
        if not mask_empty:
            mask = np.asarray(mask)
        label = np.asarray(label)
        image = cv2.GaussianBlur(image,(3,3),0)
        return image, label, mask
    def trans_bg_color(self, image, mask, color_mode):
        b, g, r = cv2.split(image)
        bg_mask = cv2.bitwise_not(mask)
        bg_b = cv2.bitwise_and(b,bg_mask)
        bg_g = cv2.bitwise_and(g,bg_mask)
        bg_r = cv2.bitwise_and(r,bg_mask)
        cloth_b = cv2.bitwise_and(b,mask)  
        cloth_g = cv2.bitwise_and(g,mask)
        cloth_r = cv2.bitwise_and(r,mask)
        if color_mode == 1:
            cloth_b, cloth_g, cloth_r = [cloth_b, cloth_r, cloth_g]
        elif color_mode == 2:
            cloth_b, cloth_g, cloth_r = [cloth_g, cloth_r, cloth_b]
        elif color_mode == 3:
            cloth_b, cloth_g, cloth_r = [cloth_g, cloth_b, cloth_r]
        elif color_mode == 4:
            cloth_b, cloth_g, cloth_r = [cloth_r, cloth_b, cloth_g]
        elif color_mode == 5:
            cloth_b, cloth_g, cloth_r = [cloth_r, cloth_g, cloth_b]
        b = cv2.add(bg_b, cloth_b)
        g = cv2.add(bg_g, cloth_g)
        r = cv2.add(bg_r, cloth_r)
        image = cv2.merge([b, g, r])
        return image, mask
    def add_gaussian_noise(self, image, label, mask, noise_sigma=8):
        """
        给图片添加高斯噪声
        image:输入图片
        noise_sigma：
        """
        temp_image = np.float64(np.copy(image))
        h, w, _ = temp_image.shape
        # 标准正态分布*noise_sigma
        noise = np.random.randn(h, w) * noise_sigma
        noisy_image = np.zeros(temp_image.shape, np.float64)
        if len(temp_image.shape) == 2:
            noisy_image = temp_image + noise
        else:
            noisy_image[:, :, 0] = temp_image[:, :, 0] + noise
            noisy_image[:, :, 1] = temp_image[:, :, 1] + noise
            noisy_image[:, :, 2] = temp_image[:, :, 2] + noise
        noisy_image = Image.fromarray(np.uint8(noisy_image))
        image = np.asarray(noisy_image)
        if type(mask) == list:
            mask_empty = True
        else:
            mask_empty = False
        if not mask_empty:
            mask = np.asarray(mask)
        label = np.asarray(label)
        return image, label, mask
    def color_jitter(self,img, label, mask):
        r_a = np.random.uniform(0.6, 1.5)
        r_b = np.random.uniform(-0.2, 0.2)
        img = np.asarray(img)
        img_f = img.astype(np.float32) / 255.0
        img_f = img_f * r_a + r_b
        img_f = np.round(img_f * 255)
        img_f = np.clip(img_f, 0, 255).astype(np.uint8)
        if type(mask) == list:
            mask_empty = True
        else:
            mask_empty = False
        if not mask_empty:
            mask = np.asarray(mask)
        label = np.asarray(label)
        return img_f, label, mask
    
    def gamma_trans(self, img, label, mask):

        factor = np.random.uniform(0.2, 1.2)
        gamma_table = [np.power(x / 255.0, factor) * 255.0 for x in range(256)]
        gamma_table = np.round(np.array(gamma_table)).astype(np.uint8)
        img = np.asarray(img)
        img = cv2.LUT(img, gamma_table)
        if type(mask) == list:
            mask_empty = True
        else:
            mask_empty = False
        if not mask_empty:
            mask = np.asarray(mask)
        label = np.asarray(label)
        return img, label, mask 
        
    def random_cutout(self, img, label, mask, max_cutout_width=200):
        if isinstance(label, Image.Image):
            label = np.asarray(label)
            img = np.asarray(img)

        img = np.copy(img)
        label = np.copy(label)

        mask_indices = np.argwhere(label > 0)  
        if mask_indices.size == 0:
            return img, label, mask  

        min_x, min_y = np.min(mask_indices, axis=0)
        max_x, max_y = np.max(mask_indices, axis=0)

    
        cutout_x_start = random.randint(int(min_x), int(max_x) - 1)
        cutout_y_start = random.randint(int(min_y), int(max_y) - 1)

        cutout_width = random.randint(1, max_cutout_width)
        cutout_height = random.randint(1, int(max_y) - cutout_y_start)

        y_end = cutout_y_start + cutout_height
        x_end = cutout_x_start + cutout_width

        cutout_x_start = max(0, cutout_x_start)
        cutout_y_start = max(0, cutout_y_start)
        x_end = min(img.shape[1], x_end)
        y_end = min(img.shape[0], y_end)

        img[cutout_y_start:y_end, cutout_x_start:x_end] = 0
        label[cutout_y_start:y_end, cutout_x_start:x_end] = 0  
        label = np.where(label > 0, 255, 0).astype(np.uint8)

        return img, label, mask


    def augment_task(self, image, label, mask=[], filp_mode=0):
        color_mode = random.randint(0, 5)
        image_orgin, label = self.trans_bg_color(image, label, color_mode)
        # image_orgin = image
        # label_orgin = label.copy
        image_orgin = Image.fromarray(image_orgin)
        label_orgin = Image.fromarray(label)
        if len(mask) == 0:
            mask_empty = True
        else:
            mask_empty = False
        if not mask_empty:
            mask_orgin = Image.fromarray(mask)
            # print(mask_orgin.size[0])
        if filp_mode == 1:
            image = tf.hflip(image_orgin)
            label = tf.hflip(label_orgin)
            if not mask_empty:
                mask = tf.hflip(mask_orgin)
        elif filp_mode == 2:
            image = tf.vflip(image_orgin)
            label = tf.vflip(label_orgin)
            if not mask_empty:
                mask = tf.vflip(mask_orgin)
        elif filp_mode == 3:
            image = tf.hflip(image_orgin)
            image = tf.vflip(image)
            label = tf.hflip(label_orgin)
            label = tf.vflip(label)
            if not mask_empty:
                mask = tf.hflip(mask_orgin)
                mask = tf.vflip(mask)
        else:
            image = copy.deepcopy(image_orgin)
            label = copy.deepcopy(label_orgin)
            if not mask_empty:
                mask = copy.deepcopy(mask_orgin)

        trans_mode = self.aug_option[random.randint(0, len(self.aug_option) - 1)]
        if 1 == trans_mode:
            # if 1 in self.aug_option:
            return self.rotate(image, label, mask)
        # if 2 == trans_mode:
        #     return aug.flip(image, label, mask)

        if 3 == trans_mode:
            # if 3 in self.aug_option:
            return self.randomResizeCrop(image, label, mask)

        if 4 == trans_mode:
            # if 4 in self.aug_option:
            return self.adjustContrast(image, label, mask)

        if 5 == trans_mode:
            # if 5 in self.aug_option:
            return self.centerCrop(image, label, mask)

        if 6 == trans_mode:
            # if 6 in self.aug_option:
            return self.adjustBrightness(image, label, mask)

        if 7 == trans_mode:
            # if 7 in self.aug_option:
            return self.adjustSaturation(image, label, mask)

        if 8 == trans_mode:
            # if 8 in self.aug_option:
            return self.add_gaussian_noise(image, label, mask)
        if 9 == trans_mode:
            return self.add_blur(image, label, mask)
        if 10 == trans_mode:
            return self.color_jitter(image, label, mask)
        if 11 == trans_mode:
            return self.gamma_trans(image, label, mask)
        if 12 == trans_mode:
            return self.random_cutout(image, label, mask)