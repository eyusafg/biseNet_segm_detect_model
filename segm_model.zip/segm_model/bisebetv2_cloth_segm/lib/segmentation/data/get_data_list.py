import os
import xml.etree.ElementTree as ET
import cv2
import numpy as np
import random


def get_cvat_list(path_root, annotations_xml_name):
    # tree_root = ET.parse(path_root + annotations_xml_name).getroot()
    tree_root = ET.parse(os.path.join(path_root, annotations_xml_name)).getroot()
    images_tree = tree_root.findall('image')
    img_tree_list = []
    for image_tree in images_tree:
        # polygon_tree = image_tree.find('polygon')

        polygon_trees = image_tree.findall('polygon')
        if len(polygon_trees) == 0:
            continue
        img_path = image_tree.get('name')
        img_path_ = img_path.split('/')[0]
        path_root_ = path_root.split('/')[-1]
        if img_path_ == path_root_:
            img_path = img_path.split('/')[-1]
        if os.path.exists(os.path.join(path_root, img_path)):
        # if os.path.exists(path_root + img_path):
            img_tree_list.append(image_tree)

    return img_tree_list

def get_cvat_data(path_root, image_tree, in_ch, class_mapping, class_colors, inv):
    # for image_tree in images_tree:
    # print(image_tree.keys())
    img_path = image_tree.get('name')
    img = cv2.imread(os.path.join(path_root, img_path))
    if img is None:
        raise ValueError(f'failed to load image: {path_root}/{img_path}')
    h, w = img.shape[:2]
    # w = int(image_tree.get('width'))
    # h = int(image_tree.get('height'))

    polygon_trees = image_tree.findall('polygon')
    label = np.zeros((h, w), dtype=np.uint8)
    # 外部类别的掩码
    external_mask = np.zeros((h, w), dtype=np.uint8)
    # 内部类别的掩码
    internal_mask = np.zeros((h, w), dtype=np.uint8)
    for polygon_tree in polygon_trees:
        str_list = polygon_tree.get('points')
        if str_list == '':
            break
        tree_label = polygon_tree.get('label')
        if tree_label not in class_mapping:
            continue
        class_idx = class_mapping[tree_label]
        points = [list(map(float, sub_str.split(','))) for sub_str in str_list.split(';')]
        contour = np.array(points, dtype=np.int32).reshape(-1, 1, 2)
  

############ 原代码 ################################
        # 分割字符串，得到子字符串列表
        # sub_str_list = str_list.split(';')
        # contour = []
        # # 将每个子字符串按照逗号进行分割，得到子列表
        # for sub_str in sub_str_list:
        #     sub_list = sub_str.split(',')
        #     # 将每个子列表中的两个元素转换为浮点数，并添加到结果列表中
        #     contour.append([[float(sub_list[0]), float(sub_list[1])]])
        mask = np.zeros([h, w, 1], np.uint8)
        # contour = np.asarray(contour)
        # contour = contour.astype(np.int32)
 
        # if tree_label == '衣服':
            #label = cv2.drawContours(label, [contour], -1, 255, -1)
        # elif in_ch == 4:
        #     mask = cv2.drawContours(mask, [contour], -1, 255, -1)
############ 原代码 ################################




########### 单通道映射尝试 ##############################
        if inv:
            # 绘制外部类别的掩码
            if class_idx == 2:
                cv2.drawContours(external_mask, [contour], -1, 2, -1)
            # 绘制内部类别的掩码
            elif class_idx == 1:
                cv2.drawContours(internal_mask, [contour], -1, 1, -1)
            elif class_idx == 3:  # 单类别时使用这个
                cv2.drawContours(label, [contour], -1, 3, -1)

            if np.any(external_mask) and np.any(internal_mask):
                label = cv2.subtract(external_mask, internal_mask)
            else:
                label = label
                # label = np.where(label > 0, 255, 0).astype(np.uint8)
        elif tree_label == '衣服':
            cv2.drawContours(label, [contour], -1, class_idx, -1)
        elif in_ch == 4:
            mask = cv2.drawContours(mask, [contour], -1, 255, -1)
        else:
            cv2.drawContours(label, [contour], -1, class_idx, -1)

        # if tree_label in class_mapping:
        #     class_idx = class_mapping[tree_label]
            # print(tree_label, class_idx)
            # 
            # label = cv2.drawContours(label, [contour], -1, class_colors[class_idx], -1)
            # print(class_colors[class_idx])
            # cv2.imshow('label', label)
            # cv2.waitKey(0)
########### 单通道映射尝试 ##############################


    # if random_crop:  # 根据配置文件的设置， 模型的输入尺寸
	#     img = img[0:256, :]
	#     label = label[0:256, :]


    color_label = np.zeros((h, w, 3), dtype=np.uint8)
    for idx, color in class_colors.items():
        if idx in class_mapping.values():
            color_label[label == idx] = color

    # cv2.imshow('label', color_label)
    # cv2.imshow('img', label)
    # cv2.waitKey(0)
    return img, label, mask


def get_image_list(data_root_path):
    input_path = os.listdir(data_root_path)
    input_path.append('')
    image_list_ = []
    label_list_ = []

    for datasets_dir in input_path:
        # print(os.path.join(data_root_path,datasets_dir))
        # print(os.path.join(input_dir,datasets_dir))
        datasets_path = os.path.join(data_root_path, datasets_dir)
        # file_name = datasets_dir+'/app.png'
        # print(file_name)
        # print(os.path.dirname(file_name))

        if 'images' in os.listdir(datasets_path) and 'labels' in os.listdir(datasets_path):
        #     print('add')
        # for dataset_dir in os.listdir(datasets_path):
        #     print(dataset_dir)

            image_dir_ = os.path.join(datasets_path, "images/")
            label_dir_ = os.path.join(datasets_path, "labels/")
            # mask_dir_ = os.path.join(data_root_path, "masks/")
            # in_ch_ = in_ch


            ims = sorted(os.listdir(image_dir_))
            lbs = sorted(os.listdir(label_dir_))
            img_idx = 0
            img_file_size = len(ims)
            lab_file_size = len(lbs)
            fail_count = 0
            for label_idx in range(lab_file_size):
                curr_img_idx_start = img_idx
                found_flag = False
                print('\rload label list:', label_idx + 1, '/', lab_file_size, ' fail:', fail_count, end="")
                while (img_idx < img_file_size):
                    # if os.path.splitext(ims[img_idx])[0] == os.path.splitext(lbs[label_idx])[0]:  # image和label同名
                    # if os.path.splitext(ims[img_idx])[0][3:] == os.path.splitext(lbs[label_idx])[0][4:]:  # img_ mask_的前缀
                    img_prefix = os.path.splitext(ims[img_idx])[0]
                    label_prefix = os.path.splitext(lbs[label_idx])[0]
                    if (os.path.splitext(ims[img_idx])[0] == os.path.splitext(lbs[label_idx])[0]) or \
                            (img_prefix[:5] == 'image' and label_prefix[:4] == 'mask' and img_prefix[5:] == label_prefix[4:]) \
                            or (img_prefix[:3] == 'img' and label_prefix[:4] == 'mask' and img_prefix[3:] == label_prefix[4:]):
                        # image_list_.append(image_dir_ + ims[img_idx])
                        # label_list_.append(label_dir_ + lbs[label_idx])
                        image_list_.append(datasets_dir+'/images/'+ims[img_idx])
                        label_list_.append(datasets_dir+'/labels/'+lbs[label_idx])
                        img_idx = img_idx + 1
                        found_flag = True
                        break
                    img_idx = img_idx + 1
                if (found_flag):
                    continue
                if curr_img_idx_start >= img_file_size:
                    curr_img_idx_start = img_file_size - 1
                img_idx = curr_img_idx_start
                while (img_idx > 0):
                    # if os.path.splitext(ims[img_idx-1])[0] == os.path.splitext(lbs[label_idx])[0]:  # image和label同名
                    # if os.path.splitext(ims[img_idx])[0][3:] == os.path.splitext(lbs[label_idx])[0][4:]:  # img_ mask_的前缀
                    img_prefix = os.path.splitext(ims[img_idx])[0]
                    label_prefix = os.path.splitext(lbs[label_idx])[0]
                    if (os.path.splitext(ims[img_idx])[0] == os.path.splitext(lbs[label_idx])[0]) or \
                            (img_prefix[:5] == 'image' and label_prefix[:4] == 'mask' and img_prefix[5:] == label_prefix[4:]) \
                            or (img_prefix[:3] == 'img' and label_prefix[:4] == 'mask' and img_prefix[3:] == label_prefix[4:]):
                        # image_list_.append(image_dir_ + ims[img_idx-1])
                        # label_list_.append(label_dir_ + lbs[label_idx])
                        image_list_.append(datasets_dir+'/images/'+ims[img_idx - 1])
                        label_list_.append(datasets_dir+'/labels/'+lbs[label_idx])
                        img_idx = img_idx - 1
                        found_flag = True
                        break
                    img_idx = img_idx - 1
                if (found_flag):
                    continue
                fail_count = fail_count + 1
                # print('cant not find <', os.path.splitext(lbs[label_idx])[0], '> data in images dir')
                img_idx = curr_img_idx_start
            print('\rload label list:', label_idx + 1, '/', lab_file_size, ' fail:', fail_count)


    return image_list_, label_list_

