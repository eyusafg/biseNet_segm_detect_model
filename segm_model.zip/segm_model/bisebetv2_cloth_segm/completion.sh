eval "$(register-python-argcomplete syt_train syt_test syt_eval syt_export)"
