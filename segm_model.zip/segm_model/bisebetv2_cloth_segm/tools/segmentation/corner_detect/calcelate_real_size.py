import cv2
import numpy as np
import math



def calculate_real_size(given_pixel_size):

    # 参数
    focal_length = 3.9  # mm
    sensor_size_inch = 1 / 2.5  # inch
    sensor_size_mm = 16.67 * sensor_size_inch  # 对角线尺寸，mm
    resolution = (2592, 1944)
    working_distance = 190  # mm

    # 计算感光芯片的长和宽
    aspect_ratio = resolution[0] / resolution[1]
    sensor_height = sensor_size_mm / math.sqrt(1 + aspect_ratio**2)
    sensor_width = aspect_ratio * sensor_height

    # 计算视场 (Field of View, FOV)
    fov_width = 2 * math.atan((sensor_width / 2) / focal_length)
    fov_height = 2 * math.atan((sensor_height / 2) / focal_length)

    # 计算实际尺寸 (object size) 在给定工作距离下
    object_width = 2 * working_distance * math.tan(fov_width / 2)
    object_height = 2 * working_distance * math.tan(fov_height / 2)

    # 计算每个像素对应的实际宽度
    pixel_width_mm = round(object_width / resolution[0],4)
    # print(f"实际宽度: {pixel_width_mm} 毫米")
    pixel_width_mm = 0.1069
    # 给定像素尺寸，对应的实际距离
    # given_pixel_size = caluetation_w(mask, contour, show_im=True)
    # given_pixel_size = 193
    actual_distance = given_pixel_size * pixel_width_mm
    # print(f"实际宽度: {actual_distance} 毫米")
    return actual_distance



if __name__ == '__main__':
    actual_distance = calculate_real_size(193)