import cv2
import numpy as np
import os


class MeasureNeck:
    def __init__(self, img=None, use_four_stage=True, use_two_stage=False, show_image=False, unsewn_way=True):
        self.img = img
        self.use_four_stage = use_four_stage
        self.use_two_stage = use_two_stage
        self.show_image = show_image
        self.unsewn_way = unsewn_way

    @staticmethod
    def calculate_angle(p1,p2,p3):
        # 计算三个点构成的夹角
        v1 = p1 - p2
        v2 = p3 - p2
        angle = np.arctan2(np.linalg.det([v1,v2]),np.dot(v1,v2))
        return np.degrees(angle)

    def find_nearest_point_index(points, target):
        # 最近点索引
        distances = np.linalg.norm(points - target, axis=1)
        return np.argmin(distances)
    
    # @classmethod
    def caluetation_w(self, mask, contour, way2=False, show_im=False):
        x,y,w,h = cv2.boundingRect(contour)

        # rect = cv2.minAreaRect(contour)
        # box = cv2.boxPoints(rect)
        # box = np.intp(box)

        s_h = y -100
        if s_h < 0:
                s_h = 0

        new_mask = mask[s_h:y+h, x+w//2-200:x+w//2+200]

        contours_NEW, _ = cv2.findContours(new_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)

        raw_dist = np.empty(new_mask.shape, dtype=np.float32)
        for i in range(new_mask.shape[0]):
                for j in range(new_mask.shape[1]):
                        raw_dist[i, j] = cv2.pointPolygonTest(contours_NEW[0], (j, i), True)

        
        # 获取最大值即内接圆半径，中心点坐标
        minVal, maxVal, _, maxDistPt = cv2.minMaxLoc(raw_dist)
        minVal = abs(minVal)
        maxVal = abs(maxVal)
        radius = np.intp(maxVal)
        # center_of_circle = maxDistPt
        print('内接圆直径', 2*radius)

        # (center_max, radius_max) = cv2.minEnclosingCircle(contours_NEW[0])
        # center_ = (int(center_max[0]), int(center_max[1]))
        # radius_ = int(radius_max)

        if self.show_image:
                output_image = cv2.cvtColor(mask, cv2.COLOR_GRAY2BGR)
                output_image_new = cv2.cvtColor(new_mask, cv2.COLOR_GRAY2BGR)

                cv2.rectangle(output_image, (x, y), (x + w, y + h), (0, 255, 0), 2)  

                # cv2.drawContours(output_image, [box], 0, (255, 0, 0), 2)  

                cv2.circle(output_image_new, maxDistPt, radius, (0, 0, 255), 2)  
                # cv2.circle(output_image_new, center_, radius_, (0, 0, 255), 2) 

                cv2.namedWindow('Bounding Rectangles and Circle', cv2.WINDOW_KEEPRATIO)
                cv2.imshow('Bounding Rectangles and Circle', output_image)
                # cv2.namedWindow('Bounding  Circle', cv2.WINDOW_KEEPRATIO)
                cv2.imshow('Bounding Circle', output_image_new)
                cv2.waitKey(0)
                cv2.destroyAllWindows()
        
        if way2:
            # 第二种方法
            moments = cv2.moments(mask)
            if moments["m00"] != 0:
                cX = int(moments["m10"] / moments["m00"])
                cY = int(moments["m01"] / moments["m00"])
            else:
                cX, cY = 0, 0
            
            bottommost = tuple(contour[contour[:, :, 1].argmax()][0])
            bottommost_index = contour[:, :, 1].argmax()
            topmost = tuple(contour[contour[:, :, 1].argmin()][0])
            if abs(cX - topmost[0]) > abs(cX - bottommost[0]):
                bottommost = bottommost
                y1 = bottommost[1] - 400
                y2 = bottommost[1] - 150
            else:
                bottommost = topmost
                y1 = bottommost[1] + 150
                y2 = bottommost[1] + 400
                
            valid_points = []
            # 遍历轮廓点，找到满足条件的点
            for i, point in enumerate(contour):
                point = tuple(point[0])
                if abs(i - bottommost_index) >= 300 and y1 < point[1] < y2:
                    valid_points.append((point, i))
            
            # 如果没有找到满足条件的点，返回None
            if not valid_points:
                print("No valid point found.")
                return None
            
            # 计算最低点与满足条件的点的最短距离
            min_distance = float('inf')
            closest_point = None
            for point, _ in valid_points:
                distance = np.sqrt((bottommost[0] - point[0]) ** 2 + (bottommost[1] - point[1]) ** 2)
                if distance < min_distance:
                    min_distance = distance
                    closest_point = point
            
            # 输出这两个点的坐标
            print(f"Bottommost point: {bottommost}")
            print(f"Closest valid point: {closest_point}")
            print(f"min_distance: {min_distance}")
            
            # 如果需要显示图像，用线连接这两个点
            if show_im:
                img = cv2.cvtColor(mask, cv2.COLOR_GRAY2BGR)
                cv2.circle(img, bottommost, 5, (0, 0, 255), -1)
                cv2.circle(img, closest_point, 5, (0, 255, 0), -1)
                cv2.line(img, bottommost, closest_point, (255, 0, 0), 2)
                for point, _ in valid_points:
                    cv2.circle(img, point, 5, (255, 0, 255), -1)
                cv2.namedWindow('Result', cv2.WINDOW_NORMAL)
                cv2.imshow('Result', img)
                cv2.waitKey(0)
                cv2.destroyAllWindows()

        return 2*radius

    def calculate_perimeter(self):
        if os.path.isfile(self.img):
            image = cv2.imread(self.img, 0)
        else:
            image = self.img
        
        # 查找轮廓
        contours, _ = cv2.findContours(image, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)
        contour = max(contours, key=cv2.contourArea)
        # 轮廓逼近
        epsilon = 0.01 * cv2.arcLength(contour, True)
        approx = cv2.approxPolyDP(contour, epsilon, True)
        points = approx.reshape(-1,2)
        num_points = points.shape[0]

        moments = cv2.moments(image)
        topmost = tuple(contour[contour[:, :, 1].argmin()][0])
        bottommost = tuple(contour[contour[:, :, 1].argmax()][0])
        if moments["m00"] != 0:
            cX = int(moments["m10"] / moments["m00"])
            cY = int(moments["m01"] / moments["m00"])
        else:
            cX, cY = 0, 0

        angles_and_points = []
        for i in range(num_points):
            p1 = points[(i -1) % num_points]
            p2 = points[i]
            p3 = points[(i + 1) % num_points]

            angle = self.calculate_angle(p1,p2,p3)
            angles_and_points.append((abs(angle), p2))
        
        angles_and_points.sort(key=lambda x: x[0])
        target_points = [p for _, p in angles_and_points] # 直接取前四个，但是对未缝领子不友好

        # 单独计算轮廓
        point_1 = angles_and_points[0][1]
        point_2 = angles_and_points[1][1]
        point_3 = angles_and_points[2][1]
        point_4 = angles_and_points[3][1]

        index_1 = np.where((contour[:,0,0] == point_1[0]) & (contour[:,0,1] == point_1[1]))[0][0]
        index_2 = np.where((contour[:,0,0] == point_2[0]) & (contour[:,0,1] == point_2[1]))[0][0]
        index_3 = np.where((contour[:,0,0] == point_3[0]) & (contour[:,0,1] == point_3[1]))[0][0]
        index_4 = np.where((contour[:,0,0] == point_4[0]) & (contour[:,0,1] == point_4[1]))[0][0]
        index_list = [index_1, index_2, index_3, index_4]

        x_1 = point_1[0]
        x_2 = point_2[0]
        x_3 = point_3[0]
        x_4 = point_4[0]

        x_list = [x_1, x_2, x_3, x_4]
        ws1 = np.where(np.array(x_list) == np.min(x_list))[0][0] + 1
        we1 = np.where(np.array(x_list) == np.max(x_list))[0][0] + 1

        if ws1 == 1:
            index_s1 = index_1
        elif ws1 == 2:
            index_s1 = index_2
        elif ws1 == 3:
            index_s1 = index_3
        elif ws1 == 4:
            index_s1 = index_4

        if we1 == 1:
            index_e1 = index_1
        elif we1 == 2:
            index_e1 = index_2
        elif we1 == 3:
            index_e1 = index_3
        elif we1 == 4:
            index_e1 = index_4

        if self.use_two_stage:
            if abs(cX - topmost[0]) > abs(cX - bottommost[0]):
                if index_s1 > index_e1:
                    index_s1, index_e1 = index_e1, index_s1
                subcontour1 = contour[index_s1:index_e1+1]
                
            else:
                subcontour1 = np.concatenate((contour[0:index_s1+1], contour[index_e1:]))

            s_e_2 = []
            for idx in index_list:
                if idx == index_s1 or idx == index_e1:
                    continue
                s_e_2.append(idx)

            # subcontour2 = None

            if s_e_2[0] > s_e_2[1] and s_e_2[0] != 0 and s_e_2[1] != 0:
                s_e_2[0], s_e_2[1] = s_e_2[1], s_e_2[0]

            # 这里需要查一下的25 L8图像， 比较经典， 轮廓2在轮廓1中
            subcontour2 = contour[s_e_2[0]:s_e_2[1]+1]
            if subcontour2.any():
                if subcontour1.reshape(-1, 2).tolist()[0] in subcontour2.reshape(-1, 2).tolist():
                    print(1111)
                    subcontour2 = contour[s_e_2[0]:]
                    if subcontour1[0][0] in subcontour2:
                        subcontour2 = contour[s_e_2[1]:]
            else:
                subcontour2 = contour[s_e_2[0]:]
                if subcontour1.reshape(-1, 2).tolist()[0] in subcontour2.reshape(-1, 2).tolist():
                    subcontour2 = contour[s_e_2[1]:s_e_2[0]]
            
            if self.show_image:
                image_show = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
                for i, (angle, point) in enumerate(angles_and_points[:4]):
                    cv2.circle(image_show, tuple(point), 10, (0, 0, 255), -1)

                for p in subcontour1:
                    cv2.circle(image_show, tuple(p[0]), 10, (0, 255, 0), -1)
            
                for p in subcontour2:
                    cv2.circle(image_show, tuple(p[0]), 10, (255, 0, 0), -1)   
                cv2.namedWindow('Corners', cv2.WINDOW_NORMAL)
                cv2.imshow('Corners', image_show)
                cv2.waitKey(0)
                cv2.destroyAllWindows()

        if self.use_four_stage:
            index_list.sort()
            # 找到x坐标最小的点和x坐标最大的点
            x_coords = [contour.reshape(-1, 2)[index][0] for index in index_list]
            start_index = index_list[np.argmin(x_coords)]
            end_index = index_list[np.argmax(x_coords)]

            # 分割轮廓为四个线段
            segments = [
                contour[start_index:end_index+1],
                contour[end_index:] + points[:start_index+1]
            ]
            segments = [
            contour[index_list[0]:index_list[1]+1],
            contour[index_list[1]:index_list[2]+1],
            contour[index_list[2]:index_list[3]+1],
            np.vstack((contour[index_list[3]:], contour[:index_list[0]+1]))
        ]
            # 计算每个线段的周长
            segment_lengths = [cv2.arcLength(segment.reshape(-1, 1, 2), False) for segment in segments]

            # 打印每个线段的周长
            for i, length in enumerate(segment_lengths):
                print(f"Segment {i+1} length: {length}")

            if self.show_image:
                colors = [(0, 255, 0), (0, 0, 255), (255, 0, 0), (0, 255, 255)]
                image_show = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
                for i, segment in enumerate(segments):
                    cv2.polylines(image_show, [segment.reshape(-1, 1, 2)], False, colors[i], 2)
                
                cv2.namedWindow('Segments', cv2.WINDOW_NORMAL)
                cv2.imshow('Segments', image_show)
                cv2.waitKey(0)
                cv2.destroyAllWindows()

        sorted_segment_lengths = sorted(segment_lengths, reverse=True) # 降序排序
        perimeter = sorted_segment_lengths[0] + sorted_segment_lengths[1]
        neck_w = self.caluetation_w(image, contour)
        print('圆领宽度: ', neck_w)
        return perimeter, neck_w
    
    def calculate_neck_unsewn(self):
        if os.path.isfile(self.img):
            image = cv2.imread(self.img, 0)
        else:
            image = self.img
        
        # 查找轮廓
        contours, _ = cv2.findContours(image, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)
        contour = max(contours, key=cv2.contourArea)

        if self.unsewn_way:
            perimeter = cv2.arcLength(contour, True)
        else:
            # 轮廓逼近
            epsilon = 0.01 * cv2.arcLength(contour, True)
            approx = cv2.approxPolyDP(contour, epsilon, True)
            points = approx.reshape(-1,2)
            num_points = points.shape[0]

            angles_and_points = []
            for i in range(num_points):
                p1 = points[(i -1) % num_points]
                p2 = points[i]
                p3 = points[(i + 1) % num_points]

                angle = self.calculate_angle(p1,p2,p3)
                angles_and_points.append((abs(angle), p2))
            
            angles_and_points.sort(key=lambda x: x[0])
            index_1 = np.where((contour[:,0,0] == angles_and_points[0][0]) & (contour[:,0,1] == angles_and_points[0][1]))[0][0]
            index_2 = np.where((contour[:,0,0] == angles_and_points[1][0]) & (contour[:,0,1] == angles_and_points[1][1]))[0][0]

            leftmost = tuple(contour[contour[:, :, 0].argmin()][0])
            rightmost = tuple(contour[contour[:, :, 0].argmax()][0])
            topmost = tuple(contour[contour[:, :, 1].argmin()][0])
            bottommost = tuple(contour[contour[:, :, 1].argmax()][0])

            # 找到 leftmost 和 rightmost 在轮廓中的索引
            leftmost_index = np.where((contour[:, 0, 0] == leftmost[0]) & (contour[:, 0, 1] == leftmost[1]))[0][0]
            rightmost_index = np.where((contour[:, 0, 0] == rightmost[0]) & (contour[:, 0, 1] == rightmost[1]))[0][0]

            moments = cv2.moments(im)
            if moments["m00"] != 0:
                cX = int(moments["m10"] / moments["m00"])
                cY = int(moments["m01"] / moments["m00"])
            else:
                cX, cY = 0, 0
    

            if abs(cX - topmost[0]) > abs(cX - bottommost[0]):
                print('开口向上')
                # 尝试使用index_1和index_2来确定subcontour1 #########################
                if leftmost_index > rightmost_index:
                    leftmost_index, rightmost_index = rightmost_index, leftmost_index
                subcontour1 = contour[leftmost_index:rightmost_index+1] 
                perimeter = cv2.arcLength(subcontour1.reshape(-1, 1, 2), False)
            else:
                print('开口向下')
                subcontour1 = np.concatenate((contour[0:leftmost_index+1]))
                subcontour1_Length = cv2.arcLength(subcontour1.reshape(-1, 1, 2), False)
                subcontour2 = np.concatenate((contour[rightmost_index:]))
                subcontour2_Length = cv2.arcLength(subcontour2.reshape(-1, 1, 2), False)
                perimeter = subcontour1_Length + subcontour2_Length

        return perimeter


if __name__ == '__main__':


    img_dir = r'D:\rag_aug\cut_out\round_neck\0924-2592_1944\masks'
    for img_name in os.listdir(img_dir):
        im = cv2.imread(os.path.join(img_dir, img_name), 0)
        contours, _ = cv2.findContours(im, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
        contour = max(contours, key=cv2.contourArea)


        leftmost = tuple(contour[contour[:, :, 0].argmin()][0])
        rightmost = tuple(contour[contour[:, :, 0].argmax()][0])
        topmost = tuple(contour[contour[:, :, 1].argmin()][0])
        bottommost = tuple(contour[contour[:, :, 1].argmax()][0])


        # 找到 leftmost 和 rightmost 在轮廓中的索引
        leftmost_index = np.where((contour[:, 0, 0] == leftmost[0]) & (contour[:, 0, 1] == leftmost[1]))[0][0]
        rightmost_index = np.where((contour[:, 0, 0] == rightmost[0]) & (contour[:, 0, 1] == rightmost[1]))[0][0]

        moments = cv2.moments(im)
        if moments["m00"] != 0:
            cX = int(moments["m10"] / moments["m00"])
            cY = int(moments["m01"] / moments["m00"])
        else:
            cX, cY = 0, 0

        im_cp = im.copy()
        im_cp = cv2.cvtColor(im_cp, cv2.COLOR_GRAY2BGR) 

        if abs(cX - topmost[0]) > abs(cX - bottommost[0]):
            print('开口向上')
            if leftmost_index > rightmost_index:
                leftmost_index, rightmost_index = rightmost_index, leftmost_index
            subcontour1 = contour[leftmost_index:rightmost_index+1] 
        else:
            print('开口向下')
            subcontour1 = np.concatenate((contour[0:leftmost_index+1]))
            subcontour2 = np.concatenate((contour[rightmost_index:]))
            # subcontour1 = np.concatenate((contour[0:leftmost_index+1], contour[rightmost_index:]))
            cv2.polylines(im_cp, [subcontour2.reshape(-1, 1, 2)], False, (255, 0, 0), 5)
        cv2.circle(im_cp, leftmost, 5, (0, 0, 255), -1)
        cv2.circle(im_cp, rightmost, 5, (0, 0, 255), -1)
        cv2.circle(im_cp, topmost, 5, (0, 0, 255), -1)
        cv2.circle(im_cp, bottommost, 5, (0, 0, 255), -1)
        cv2.polylines(im_cp, [subcontour1.reshape(-1, 1, 2)], False, (0, 255, 0), 5)
  
            

        cv2.namedWindow('Subcontour1', cv2.WINDOW_NORMAL)
        cv2.imshow('Subcontour1', im_cp)
        cv2.waitKey(0)
