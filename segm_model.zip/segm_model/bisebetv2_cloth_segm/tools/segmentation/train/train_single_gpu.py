#!/usr/bin/python
# -*- encoding: utf-8 -*-
# PYTHON_ARGCOMPLETE_OK
import argparse
# import argcomplete
def parse_args():
    parse = argparse.ArgumentParser()
    parse.add_argument('--config', dest='config', type=str,
            default='bisebetv2_cloth_segm\\configs\\segmentation\\bisenetv2_syt_segm_edge_thor_1203.py',)
    # parse.add_argument('--finetune-from', type=str, default='output\\neck_2592-1944_ch4\\segmentation\\res\\2024-08-08_19-31-41\\model_69.pth',)
    parse.add_argument('--finetune-from', type=str, default=None,)
    # 在调用parse_args()函数前增加这一行
    # argcomplete.autocomplete(parse)
    return parse.parse_args()

args = parse_args()
import sys
sys.path.insert(0, '')
sys.path.insert(0, '../../../')
sys.path.append('bisebetv2_cloth_segm')
import os
import copy
import os.path as osp
import logging
import time
import json
from tabulate import tabulate
from tensorboardX import SummaryWriter
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
import torch.cuda.amp as amp

from models.segmentation import model_factory
from configs.segmentation import set_cfg_from_file
# from lib.segmentation.data import get_data_loader
from tools.segmentation.eval.evaluate import eval_model
from lib.segmentation.ohem_ce_loss import OhemCELoss, CustomLoss
from lib.segmentation.lr_scheduler import WarmupPolyLrScheduler
from lib.segmentation.meters import TimeMeter, AvgMeter
from lib.segmentation.logger import setup_logger, print_log_msg
from lib.segmentation.data.syt_segm_dataset import SytSegmDataset
import torch.nn.functional as F
import numpy as np
import random
# fix all random seeds
torch.manual_seed(123)
torch.cuda.manual_seed(123)
np.random.seed(123)
random.seed(123)
torch.backends.cudnn.deterministic = True
torch.backends.cudnn.benchmark = True
torch.multiprocessing.set_sharing_strategy('file_system')

# print(torch.version.cuda)  # 查看当前CUDA版本
# print(torch.backends.cudnn.version())  # 查看当前cuDNN版本
# torch.cuda.empty_cache()


cfg = set_cfg_from_file(args.config)
cfg_dict = dict(cfg.__dict__)
pretrained_weights_path = ''

def set_model(lb_ignore=0):
    logger = logging.getLogger()
    global pretrained_weights_path
    if not args.finetune_from is None:
        pretrained_weights_path = args.finetune_from
    if 'net_config' in cfg_dict:
        net = model_factory[cfg.model_type](cfg.n_cats, cfg.in_ch, net_config=cfg.net_config, pretrained_weights_path=pretrained_weights_path)
    else:
        net = model_factory[cfg.model_type](cfg.n_cats, cfg.in_ch)
    if not args.finetune_from is None:
        logger.info(f'load pretrained weights from {args.finetune_from}')
        check_point = torch.load(args.finetune_from, map_location='cpu')
        if 'model_state_dict' in check_point:
            msg = net.load_state_dict(check_point['model_state_dict'], strict=False)
        else:
           msg = net.load_state_dict(check_point, strict=False)
        # msg = net.load_state_dict(torch.load(args.finetune_from,
        #                                      map_location='cpu'), strict=False)
        logger.info('\tmissing keys: ' + json.dumps(msg.missing_keys))
        logger.info('\tunexpected keys: ' + json.dumps(msg.unexpected_keys))
    if cfg.use_sync_bn: net = nn.SyncBatchNorm.convert_sync_batchnorm(net)
    net.cuda()
    net.train()
    criteria_pre = OhemCELoss(0.7, lb_ignore)
    criteria_aux = [OhemCELoss(0.7, lb_ignore)
                    for _ in range(cfg.num_aux_heads)]
    return net, criteria_pre, criteria_aux


def set_optimizer(model):
    if hasattr(model, 'get_params'):
        wd_params, nowd_params, lr_mul_wd_params, lr_mul_nowd_params = model.get_params()
        #  wd_val = cfg.weight_decay
        wd_val = 0
        params_list = [
            {'params': wd_params, },
            {'params': nowd_params, 'weight_decay': wd_val},
            {'params': lr_mul_wd_params, 'lr': cfg.lr_start * 10},
            {'params': lr_mul_nowd_params, 'weight_decay': wd_val, 'lr': cfg.lr_start * 10},
        ]
    else:
        wd_params, non_wd_params = [], []
        for name, param in model.named_parameters():
            if param.dim() == 1:
                non_wd_params.append(param)
            elif param.dim() == 2 or param.dim() == 4:
                wd_params.append(param)
        params_list = [
            {'params': wd_params, },
            {'params': non_wd_params, 'weight_decay': 0},
        ]
    optim = torch.optim.SGD(
        params_list,
        lr=cfg.lr_start,
        momentum=0.9,
        weight_decay=cfg.weight_decay,
    )
    return optim

def set_meters():
    time_meter = TimeMeter(cfg.max_iter)
    loss_meter = AvgMeter('loss')
    loss_pre_meter = AvgMeter('loss_prem')
    loss_aux_meters = [AvgMeter('loss_aux{}'.format(i))
            for i in range(cfg.num_aux_heads)]
    return time_meter, loss_meter, loss_pre_meter, loss_aux_meters


EDGE_LOSS_FACTOR = 2.0


def compute_edge_weight_loss(logits, labels, edge_factor=EDGE_LOSS_FACTOR):
    with torch.no_grad():
        valid = labels != 255
        lb_bin = ((labels > 0) & valid).float().unsqueeze(1)
        if lb_bin.sum() == 0:
            return logits.new_tensor(0.0)
        kernel = torch.ones((1, 1, 3, 3), device=labels.device, dtype=lb_bin.dtype)
        neighbor_sum = F.conv2d(lb_bin, kernel, padding=1)
        edge_mask = (neighbor_sum > 0) & (neighbor_sum < 9) & (lb_bin == 1)
        edge_mask = edge_mask.squeeze(1)

        if edge_mask.sum() == 0:
            return logits.new_tensor(0.0)
    ce_per_pixel = F.cross_entropy(logits, labels, ignore_index=255, reduction='none')

    edge_losses = ce_per_pixel[edge_mask]
    if edge_losses.numel() == 0:
        return logits.new_tensor(0.0)

    return edge_factor * edge_losses.mean()

def train(local_time_str='', resume=None):
    if local_time_str == '':
        local_time_str = time.strftime('%Y-%m-%d_%H-%M-%S', time.localtime())
    log_path = cfg.respth.replace('res', 'log') + '/' + local_time_str
    if not os.path.exists(log_path):
        os.makedirs(log_path)
    logger = logging.getLogger()

    use_syt_dataset = False
    if 'use_syt_dataset' in cfg_dict:
        use_syt_dataset = cfg_dict['use_syt_dataset']

    ## dataset
    if use_syt_dataset:
        # dataset = SytSegmDataset("/home/syt/datasets/ClothSegment/augment/")
        dataset = SytSegmDataset(cfg.train_im_anns, cfg.class_mapping, cfg.class_colors, cfg.inv,
                                 cfg_dict['target_size'], cfg_dict['in_ch'])
        # dl = DataLoader(dataset, 16, True, num_workers=8)
        dl = DataLoader(dataset, cfg_dict['ims_per_gpu'], True, num_workers=4, drop_last=True)
        ## model
        net, criteria_pre, criteria_aux = set_model(255)

    else:
        pass
        # dl = get_data_loader(cfg, mode='train')
        # ## model
        # net, criteria_pre, criteria_aux = set_model(dl.dataset.lb_ignore)
    # # tensorboard model

    # writer = SummaryWriter(log_dir=log_path+'/model')
    # dummy_input = torch.rand(1, cfg_dict['in_ch'], cfg_dict['target_size'][1], cfg_dict['target_size'][0]).cuda()
    # writer.add_graph(net, dummy_input)
    # writer.close()


    ## optimizer
    optim = set_optimizer(net)

    ## mixed precision training
    scaler = amp.GradScaler()

    ## meters
    time_meter, loss_meter, loss_pre_meter, loss_aux_meters = set_meters()

    ## lr scheduler
    lr_schdr = WarmupPolyLrScheduler(optim, power=0.9,
        max_iter=cfg.max_iter, warmup_iter=cfg.warmup_iters,
        warmup_ratio=0.1, warmup='exp', last_epoch=-1,)

    if resume is not None:
        if os.path.isfile(resume):
            print(f'=> loading checkpoint {resume}')
            checkpoint = torch.load(resume)
            net.load_state_dict(checkpoint['model_state_dict'], map_location='cuda:0')

            if 'optimizer_state_dict' in checkpoint:
                optim.load_state_dict(checkpoint['optimizer_state_dict'], map_location='cuda:0')
            if 'lr_shceduler_state_dict' in checkpoint and lr_schdr is not None:
                lr_schdr.load_state_dict(checkpoint['lr_scheduler_state_dict'], map_location='cuda:0')
            
            start_epoch = checkpoint['epoch']
            print(f'=> loaded checkpoint {resume} (epoch {start_epoch})')
    else:
        start_epoch = 0

    ## train loop
    for epoch in range(start_epoch, cfg.epochs):
        dl_length = dl.__len__()
        for it, (im, lb) in enumerate(dl):
            print('\repoch:', epoch, '  it:', it, '/', dl_length-1, end="")

            im = im.cuda()
            lb = lb.cuda()
            # print(lb.shape)

            # lb = torch.squeeze(lb, 1)

            optim.zero_grad()
            with amp.autocast(enabled=cfg.use_fp16):
                logits, *logits_aux = net(im)
                base_loss_pre = criteria_pre(logits, lb)
                edge_loss = compute_edge_weight_loss(logits, lb)
                # 看一下这两个的损失是不是一个数量级
                print(f'base_loss_pre: {base_loss_pre.item()}')
                print('edge_loss', edge_loss.item())
                logger.info(f'\nbase_loss_pre: {base_loss_pre.item()}')
                logger.info(f'\edge_loss: {edge_loss.item()}')
                loss_pre = base_loss_pre + edge_loss
                loss_aux = [crit(lgt, lb) for crit, lgt in zip(criteria_aux, logits_aux)]

                loss = loss_pre + sum(loss_aux)
            scaler.scale(loss).backward()
            scaler.step(optim)
            scaler.update()
            torch.cuda.synchronize()

            time_meter.update()
            loss_meter.update(loss.item())
            loss_pre_meter.update(loss_pre.item())
            _ = [mter.update(lss.item()) for mter, lss in zip(loss_aux_meters, loss_aux)]

            ## print training log message
        if epoch % 1 == 0:
            print()
            lr = lr_schdr.get_lr()
            lr = sum(lr) / len(lr)

            loss_avg, _ = copy.deepcopy(loss_meter).get()
            loss_pre_avg, _ = copy.deepcopy(loss_pre_meter).get()
            writer = SummaryWriter(log_dir=log_path)
            writer.add_scalars('scalar/lr', {'lr': float(lr)}, epoch)

            loss_scalar = {'loss': loss_avg, 'loss_pre': loss_pre_avg}
            for el in copy.deepcopy(loss_aux_meters):
                # print(el.name, el.get()[0])
                loss_scalar[el.name] = el.get()[0]
            writer.add_scalars('scalar/loss', loss_scalar, epoch)
            writer.close()

            print_log_msg(
                epoch, cfg.max_iter, lr, time_meter, loss_meter,
                loss_pre_meter, loss_aux_meters)

            lr_schdr.step()

        if (epoch+1) % 5 == 0:
            ## dump the final model and evaluate the result
            save_pth = osp.join(cfg.respth+'/'+local_time_str, f'model_{epoch}.pth')
            logger.info('\nsave models to {}'.format(save_pth))
            # torch.save(net.state_dict(), save_pth)
            torch.save({
                'model_state_dict': net.state_dict(),
                'optimizer_state_dict': optim.state_dict(),
                'lr_scheduler_state_dict': lr_schdr.state_dict() if lr_schdr is not None else None,
                'epoch': epoch,
            }, save_pth) # 保存训练信息，防止突然中断训练

            logger.info('\nevaluating the final model')
            torch.cuda.empty_cache()
            iou_heads, iou_content, f1_heads, f1_content = eval_model(cfg, net, log_path=log_path, epoch=epoch)
            logger.info('\neval results of f1 score metric:')
            logger.info('\n' + tabulate(f1_content, headers=f1_heads, tablefmt='orgtbl'))
            logger.info('\neval results of miou metric:')
            logger.info('\n' + tabulate(iou_content, headers=iou_heads, tablefmt='orgtbl'))
    return


def main():
    local_time_str = time.strftime('%Y-%m-%d_%H-%M-%S', time.localtime())
    if not osp.exists(cfg.respth+'/'+local_time_str): os.makedirs(cfg.respth+'/'+local_time_str)
    setup_logger(f'{cfg.model_type}-{cfg.dataset.lower()}-train', cfg.respth+'/'+local_time_str)
    train(local_time_str, resume=None)


if __name__ == "__main__":
    main()

    # python.\segmentation\train_single_gpu.py - -config.\configs\bisenetv2_syt_segm_edge.py

