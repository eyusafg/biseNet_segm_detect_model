/*
#include <random>
#include <iostream>
#include <string>
#include <vector>
#include <chrono>
#include<dirent.h>
#include <opencv2/opencv.hpp>
#include <inference_engine.hpp>
#include <sys/time.h>
*/
#include <opencv2/opencv.hpp>
std::string mdpth("/home/syt/Documents/BiSeNet/model_329.onnx");
std::string impth("/home/syt/datasets/8_1-2/2023-08-01-21-13-39-right-machine-right-camera.png"); 
std::string savepth("res.jpg");
#include <random>
#include <assert.h>
#include <vector>
// #include <onnxruntime_cxx_api.h>
#include <onnxruntime_cxx_api.h>
#include<dirent.h>
#include <sys/time.h>
using namespace std;
struct timeval t_start;
float time_use=0;
struct timeval t_end;
void get_image(std::string impth, std::vector<unsigned long> insize, float* data) {
    int iH = insize[2];
    int iW = insize[3];
    cv::Mat im = cv::imread(impth);
    cv::imshow("im",im);
    gettimeofday(&t_start,NULL); //gettimeofday(&start,&tz);结果一样
    if (im.empty()) {
        std::cerr << "cv::imread failed: " << impth << std::endl;
        std::abort();
    }
    int orgH{im.rows}, orgW{im.cols};
    if ((orgH != iH) || orgW != iW) {
        std::cout << "resize orignal image of (" << orgH << "," << orgW 
            << ") to (" << iH << ", " << iW << ") according to model requirement\n";
        cv::resize(im, im, cv::Size(iW, iH), cv::INTER_CUBIC);
    }
    float mean[3] = {0.5, 0.5, 0.5};
    float var[3] = {0.5, 0.5, 0.5};
    float scale = 1.f / 255.f;
    for (float &el : var) el = 1.f / el;
    for (int h{0}; h < iH; ++h) {
        cv::Vec3b *p = im.ptr<cv::Vec3b>(h);
        for (int w{0}; w < iW; ++w) {
            for (int c{0}; c < 3; ++c) {
                int idx = (2 - c) * iH * iW + h * iW + w; // to rgb order
                data[idx] = (p[w][c] * scale - mean[c]) * var[c];
            }
        }
    }
}
std::vector<std::vector<uint8_t>> get_color_map() {
    std::vector<std::vector<uint8_t>> color_map(256, 
            std::vector<uint8_t>(3));
    std::minstd_rand rand_eng(123);
    std::uniform_int_distribution<uint8_t> u(0, 255);
    for (int i{0}; i < 256; ++i) {
        for (int j{0}; j < 3; ++j) {
            color_map[i][j] = u(rand_eng);
        }
    }
    return color_map;
}


void save_predict(std::string savename, int64* data, 
        std::vector<unsigned long> insize, 
        std::vector<unsigned long> outsize) {

    std::vector<std::vector<uint8_t>> color_map = get_color_map();
    int oH = outsize[1];
    int oW = outsize[2];
    cv::Mat pred(cv::Size(oW, oH), CV_8UC3);
    int idx{0};
    for (int i{0}; i < oH; ++i) {
        uint8_t *ptr = pred.ptr<uint8_t>(i);
        for (int j{0}; j < oW; ++j) {
            ptr[0] = color_map[data[idx]][0];
            ptr[1] = color_map[data[idx]][1];
            ptr[2] = color_map[data[idx]][2];
            // printf("%d %d %d\n",i,j,data[idx]);
            ptr += 3;
            // ptr++;
            ++idx;
        }
    }
    gettimeofday(&t_end,NULL);

    cv::imshow(savename,pred);
    // cv::imwrite(savename, pred);
}

int main()
{
    struct dirent *ptr;    
    DIR *dir;
    // std::string PATH = "/home/syt/test_data/20230510";
    // std::string PATH = "/home/syt/20230713";
    std::string PATH = "/home/syt/datasets/8_1-2/";
    // std::string PATH = "/home/syt/save_img/";
    dir=opendir(PATH.c_str()); 
    std::vector<std::string> files(0);
    std::cout << "文件列表: "<< std::endl;
    while((ptr=readdir(dir))!=NULL)
    {

        //跳过'.'和'..'两个目录
        if(ptr->d_name[0] == '.')
            continue;

        files.push_back(ptr->d_name);
    }
    
    for (size_t i = 0; i < files.size(); ++i)
    {
        std::cout << files[i] << std::endl;
    }

    closedir(dir);


    Ort::Env env(ORT_LOGGING_LEVEL_WARNING, "test");
    Ort::SessionOptions session_options;
 


    
    int width = 320;
    int height = 192;
    int len_arr = width*height*3;
    float virtual_image[len_arr];
    std::vector<unsigned long> insize = {1,3,192,320};


    const char* model_path = mdpth.c_str();
    Ort::Session session(env, model_path, session_options);
    // print model input layer (node names, types, shape etc.)
    Ort::AllocatorWithDefaultOptions allocator;

    // print number of model input nodes
    // size_t num_input_nodes = session.GetInputCount();
    std::vector<const char*> input_node_names = {"input"};
    std::vector<const char*> output_node_names = {"output"};

    std::vector<int64_t> input_node_dims = {1, 3, height, width};
    size_t input_tensor_size = height * width * 3;

    auto memory_info = Ort::MemoryInfo::CreateCpu(OrtArenaAllocator, OrtMemTypeDefault);

    for (size_t i = 0; i < files.size(); i++)
    {
      std::string file_path = PATH + "/" + files[i];
      impth = file_path;
      get_image(impth,insize, virtual_image);
      Ort::Value input_tensor = Ort::Value::CreateTensor<float>(memory_info, virtual_image,
                                                              input_tensor_size, input_node_dims.data(), 4);

      std::vector<Ort::Value> ort_inputs;
      ort_inputs.push_back(std::move(input_tensor));

      auto output_tensors = session.Run(Ort::RunOptions{nullptr}, input_node_names.data(), ort_inputs.data(),
                                      ort_inputs.size(), output_node_names.data(), 1);

      // float* floatarr = output_tensors[0].GetTensorMutableData<float>();
      int64* output = output_tensors[0].GetTensorMutableData<int64>();
      // int* floatarr = output_tensors[0].GetTensorMutableData<int>();
      // for (int i=0; i<256; i++)
      // {
      //     std::cout<<floatarr[i]<<std::endl;
      // }
      std::vector<unsigned long> outsize = {1,192,320};
      save_predict(savepth, output, insize, outsize);
      time_use=(t_end.tv_sec-t_start.tv_sec)*1000000+(t_end.tv_usec-t_start.tv_usec);//微秒
      printf("time_use is %.10f\n",time_use/1000.0);//ms
      cv::waitKey(1);

    }
    return 0;
}
