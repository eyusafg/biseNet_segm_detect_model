#!/usr/bin/env python
# coding=utf-8

import cv2
import numpy as np
import time
from copy import deepcopy
import argparse
import os
import openvino.runtime as ov

parser = argparse.ArgumentParser("Test")
parser.add_argument("--data_path", help="path to image file or directory", default='hulk_images')

def normalize(img, mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5]):
    # print(mean)
    # print(std)
    if not isinstance(mean, np.ndarray):
        mean = np.array(mean)
    if not isinstance(std, np.ndarray):
        std = np.array(std)

    _max = np.max(img)
    _min = np.min(img)
    _div = (img - _min) / _max
    _sub = _div - mean
    arrays = (_div - mean) / std

    return arrays

def infer_and_show(image_fname, infer_request):
    raw_img = cv2.imread(image_fname)
    img = cv2.resize(raw_img, (640, 480))
    img = img[:, :, ::-1]
    # img = normalize(img)

    img = img.transpose([2, 0, 1]).astype(np.float32)
    input_tensor = ov.Tensor(array=np.asarray([img]), shared_memory=True)
    infer_request.set_input_tensor(input_tensor)
    tm_begin = time.time()
    infer_request.start_async()
    infer_request.wait()
    tm_end = time.time()
    output = infer_request.get_output_tensor()
    # print(output.shape)
    pred_mask = np.asarray(output.data, dtype=np.float32).squeeze(0)
    pred_mask = cv2.normalize(pred_mask.astype(np.uint8), None, 0, 255, cv2.NORM_MINMAX)
    cv2.imshow("pred", pred_mask)
    cv2.waitKey(0)
    print("Time cost infer is %lf seconds" % (tm_end - tm_begin))

if __name__ == '__main__':
    # cv2.namedWindow("res", cv2.WINDOW_KEEPRATIO)
    ov_core = ov.Core()
    # compiled_model = ov_core.compile_model("./exported_models/0605/0605_cat_auged_posehr.onnx", "CPU")
    compiled_model = ov_core.compile_model("model.onnx", "CPU")
    infer_request = compiled_model.create_infer_request()

    args = parser.parse_args()
    data_path = args.data_path
    image_files = []
    if not os.path.exists(data_path):
        print("Specific path not exists.")
        exit(1)
    if os.path.isdir(data_path):
        image_fnames = os.listdir(data_path)
        for img_fname in image_fnames:
            image_files.append(os.path.join(data_path, img_fname))
    else:
        image_files.append(data_path)
    
    print(image_files)
    for image_file in image_files:
        infer_and_show(image_file, infer_request=infer_request)
