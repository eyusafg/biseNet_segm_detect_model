import cv2
import os
from pyModbusTCP.client import ModbusClient
import copy
import sys
# sys.path.insert(0, '')
# sys.path.insert(0, '../../../')
from os.path import dirname, abspath
currun_path = dirname(dirname(dirname(dirname(abspath(__file__)))))
# sys.path.insert(0, currun_path)
sys.path.append(currun_path)
import argparse
import torch
import torch.nn.functional as F
import numpy as np
import cv2
import os
import time
import openvino.runtime as ov


torch.set_grad_enabled(False)
np.random.seed(123)

# class OnnxInfer:
#     def __init__(self,onnx_model_path, image_path=None, camera_device=None,
#                  cut_h=None, target_size=(640, 480)):
#         self.ov_core = ov.Core()
#         self.compile_model = self.ov_core.compile_model(model=onnx_model_path, device_name='CPU')
#         self.infer_request = self.compile_model.create_infer_request()
#         self.image_path = image_path
#         self.camera_device = camera_device
#         self.cut_h= cut_h
#         self.target_size = target_size

    
#     def infer(self):
#         # if self.image_path is not None:
#         img = cv2.imread(self.image_path)
#         # else:
#         #     cap = cv2.VideoCapture(self.camera_device)
#         #     if not cap.isOpened():
#         #         print(f'Cannot open camera device {self.camera_device}')
#         #     ret, img = cap.read()

#         # if self.cut_h is not None:
#         #     img = img[0:self.cut_h, :, :]


#         self.infer_request.set_input_tensor(input_tensor)
#         self.infer_request.start_async()
#         self.infer_request.wait()
#         output = self.infer_request.get_output_tensor()

#         pred_mask = np.array(output.data, dtype=np.float32).squeeze()
#         pred = cv2.normalize(pred_mask.astype(np.uint8), None, 0, 255, cv2.NORM_MINMAX)

#         return pred

# def main():
#     parser = argparse.ArgumentParser(description='openvino infer demo')
#     parser.add_argument('--onnx_path', type=str, default='/home/lion/bisenet_v2/model.onnx')
#     parser.add_argument('--img_dir', type=str, default='/home/lion/bisenet_v2/hulk_images')
#     parser.add_argument('--save_dir', type=str, default='ov_output')
#     parser.add_argument('--device', type=str, default='cpu')
    
#     args = parser.parse_args()

#     target_size = (640, 480)

#     # if os.path.splitext(args.img_dir)[-1] == '.jpg' or os.path.splitext(args.img_dir)[-1] == '.png':
#     #     img_list = [args.img_dir]
#     # else:
#     #     img_list = [os.path.join(args.img_dir, img_name) for img_name in os.listdir(args.img_dir)]
#     for img_path in os.listdir(args.img_dir):
#         time_begin = time.time()
#         output = OnnxInfer(args.onnx_path, os.path.join(args.img_dir, img_path), args.device, target_size=target_size).infer()
#         time_end = time.time()
#         print('opvino infer time: ',time_end - time_begin)
#         # cv2.imshow('output', output)
#         # cv2.waitKey(0)

# if __name__ == '__main__':
#     main()


import os
import cv2
import time
import argparse
import numpy as np
from openvino.inference_engine import IECore

class OnnxInfer:
    def __init__(self, onnx_model_path, image_path, device, target_size=(640, 480)):
        self.ie = IECore()
        self.net = self.ie.read_network(model=onnx_model_path)
        self.exec_net = self.ie.load_network(network=self.net, device_name=device)
        self.image_path = image_path
        self.target_size = target_size
    
    def infer(self):
        img = cv2.imread(self.image_path)
        if img is None:
            print("无法读取图像")
            return
        
        # 图像预处理
        processed_img = self.preprocess(img, self.target_size)

        # 设置输入数据
        input_blob = next(iter(self.net.input_info))
        self.exec_net.start_async(request_id=0, inputs={input_blob: processed_img})
        if self.exec_net.requests[0].wait(-1) == 0:
            # 获取输出数据
            output_blob = next(iter(self.net.outputs))
            output = self.exec_net.requests[0].output_blobs[output_blob].buffer
            output = np.squeeze(output).astype(np.uint8)
            output = np.where(output > 0, 255, 0).astype(np.uint8)

    def preprocess(self, img):
        
        img = cv2.resize(img, self.target_size)
        img = img[:, :, ::-1].astype(np.float32) / 255.0
        img = np.ascontiguousarray(img.transpose([2,0,1]).astype(np.float32),dtype=np.float32)
        img = np.expand_dims(img, axis=0)
        # input_tensor = ov.Tensor(array=np.asarray([img]), shared_memory=True)
        return img

    # def process_output(self, output):
    # 
    #     processed_output = output
    #     return processed_output

def xml_infer(xml_path, img_path, device):
    raw_img = cv2.imread(img_path)
    img = cv2.resize(raw_img, (640, 480))
    img = img[:, :, ::-1]

    # mean = np.array([0.5,0.5,0.5])
    # std = np.array([0.5,0.5,0.5])
    # img = (img - mean[None, None, :]) / std[None, None, :]
    img = np.transpose(img, (2, 0, 1)).astype(np.float32)
    # img = np.expand_dims(img, axis=0).astype(np.float32)
    core = ov.Core()
    compiled_model = core.compile_model(model=xml_path, device_name=device)
    infer_request = compiled_model.create_infer_request()
    input_tensor = ov.Tensor(array=np.asarray([img]), shared_memory=True)

    infer_request.set_input_tensor(input_tensor)
    # infer_request.start_async()
    # infer_request.wait()
    output_tensor = infer_request.get_output_tensor()
    output_buffer = output_tensor.data
    output = np.squeeze(output_buffer).astype(np.uint8)
    output = np.where(output > 0, 255, 0).astype(np.uint8)
    return output



def main():
    parser = argparse.ArgumentParser(description='openvino infer demo')
    parser.add_argument('--onnx_path', type=str, default='/home/lion/bisenet_v2/model.onnx')
    parser.add_argument('--img_dir', type=str, default='/home/lion/bisenet_v2/hulk_images')
    parser.add_argument('--device', type=str, default='cuda')
    args = parser.parse_args()

    target_size = (640, 480)
    
    # 获取图像路径列表
    img_list = [os.path.join(args.img_dir, img_name) for img_name in os.listdir(args.img_dir)]

    for img_path in img_list:
        time_begin = time.time()
        onnx_infer = OnnxInfer(args.onnx_path, img_path, args.device, target_size)
        onnx_infer.infer()
        time_end = time.time()
        print('opvino infer time: ', time_end - time_begin)

if __name__ == '__main__':
    # main()
    time_begin = time.time()
    output = xml_infer('openvino_ir/distilbert.xml', '/home/lion/bisenet_v2/hulk_images/0_.jpg', 'CPU')
    print('xml infer time: ', time.time() - time_begin)
    # cv2.imshow('output', output)
    # cv2.waitKey(0)
 