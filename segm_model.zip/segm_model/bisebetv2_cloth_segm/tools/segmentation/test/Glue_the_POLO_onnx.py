import sys
sys.path.insert(0, '')
import numpy as np
import cv2
import time
import onnxruntime as rt
import os
from corner_detector_rect import find_fabric_corners_rect
from calculate_angle import analyze_angle
# from serial_test import find_serial_port, build_frame, send_frame
import serial
from pixel_to_real import PixelToWorldConverter
from protocol_handler import ProtocolHandler


def init_model(model_path):
    rt_infer = rt.InferenceSession(model_path)
    input_name = rt_infer.get_inputs()[0].name
    outputs = rt_infer.get_outputs()
    outputs_names = list(map(lambda output: output.name, outputs))
    return rt_infer, input_name, outputs_names




if __name__ == '__main__':


    # 加载单应性矩阵
    H_path = r'camera_parames_DH\_20250915164723435_homography.npy'
    camera_matrix_path = r"camera_parames_DH\glue_DH_camera_matrix.npz"
    dist_coeffs_path = r"camera_parames_DH\glue_DH_dist_coeffs.npz"

    H = np.load(H_path)
    converter = PixelToWorldConverter(H)

    camera_matrix = np.load(camera_matrix_path)['camera_matrix']
    dist_coeffs = np.load(dist_coeffs_path)['dist_coeffs']



    model_path = 'Glue_the_hem_segm_20250909_model_19.onnx'
    rt_infer, input_name, outputs_names = init_model(model_path)

    # 串口初始化
    # ports = find_serial_port()
    # if ports:
    #     port = ports[0].device
    #     ser = serial.Serial(port, baudrate=115200, bytesize=serial.EIGHTBITS, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE, timeout=0.01)


    # 新的通信协议
    protocol = ProtocolHandler()
    if not protocol.connect():
        print('串口连接失败')
        exit(1)


    verticla_line_distance = 0
    im_dir = r'Glue_0910_im\bgr'
    # for im in os.listdir(im_dir):
    #     img = cv2.imread(os.path.join(im_dir, im))

    cap = cv2.VideoCapture(1, cv2.CAP_DSHOW)
    cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*'MJPG'))
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1920)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 1080)
    ret, im = cap.read()
    while ret:
        time_start = time.time()

        ret, im = cap.read()
        print('im.shape:', im.shape)
        im = im[400:1000, 400:1000]
        img = cv2.resize(im, (384, 384))
        im_cp = img.copy()
        img = np.ascontiguousarray(img[:, :, ::-1].transpose(2, 0, 1))
        img = np.expand_dims(img, axis=0).astype(np.float32)
    
        infer_img = rt_infer.run(['preds'], {input_name: img})[0]
        infer_img = np.array(infer_img[0,:,:]).astype(np.uint8) 

        pred1 = (infer_img == 1).astype(np.uint8) * 255
        pred_bgr = cv2.cvtColor(pred1, cv2.COLOR_GRAY2BGR)

        # pred2 = (infer_img == 2).astype(np.uint8) * 255
        # infer_img = np.where(infer_img > 0, 255, 0).astype(np.uint8)
        
        # 识别角度和x, y距离
        corners, segment_points, contour_points, rect_box, rect_bottom_left, rect_bottom_right = find_fabric_corners_rect(pred1)
        if corners is None:
            continue 

        # 设置虚拟线
        img_height, img_width = pred1.shape[:2]
        virtual_horizontal_line_y = img_height - 188
        # 2. 将图像宽度分为4段
        segment_index = 2
        segment_width = img_width / 4
        x_start = segment_index * segment_width
        # x_start = 0
        x_end = (segment_index + 1) * segment_width + 20
        # x_end = img_width
        print(f"图像宽度: {img_width}, 每段宽度: {segment_width:.1f}")
        print(f"截取第{segment_index + 1}段: x范围 [{x_start:.1f}, {x_end:.1f}]")
        x_mid = int((x_start + x_end) / 2)
        if len(corners) == 2:
            bottom_left_point, bottom_right_point = corners[0], corners[1]
        else:
            continue

        '''
        事先判断右角点的位置， 分四种情况
        1. 右角点在左垂直虚拟线左边   这种情况y和角度都无效， 需要计算角点到右垂直虚拟线的距离
        2. 右角点在两条虚拟线中间     y和角度有效， 需要计算
        3. 右角点在右垂直虚拟线右边   这种情况y和角度都无效， 需要计算角点到右垂直虚拟线的距离
        4. 右角点到达图像右边界       角点无效
        '''

        x_invalid = False
        y_invalid = False
        distance_to_horizontal = 0
        start_point = np.array([0, 0])
        end_point = np.array([0, 0])
        angle_deg = 0
        mid_point = np.array([0, 0])
        avg_y = 0

        if bottom_right_point[0] < x_start:
            '''
            右角点在左垂直虚拟线左边   这种情况y和角度都无效， 需要计算角点到右垂直虚拟线的距离
            '''
            verticla_line_distance = bottom_right_point[0] - x_end  # 角点的距离最远端垂直虚拟线的距离
            x_invalid = True
        elif bottom_right_point[0] > x_end and bottom_right_point[0] < img_width - 10:
            '''
            右角点在右垂直虚拟线右边   这种情况y和角度都无效， 需要计算角点到右垂直虚拟线的距离
            '''
            verticla_line_distance = bottom_right_point[0] - x_end  # 角点的距离最远端垂直虚拟线的距离
            x_invalid = True
        elif bottom_right_point[0] > img_width - 10:
            '''
            右角点到达图像右边界  角点无效
            '''
            verticla_line_distance = 0
            x_invalid = False
        else:
            '''
            右角点在两条虚拟线中间  y和角度有效， 需要计算
            '''
            x_invalid = True
            y_invalid = True

            verticla_line_distance = bottom_right_point[0] - x_end  # 角点的距离最远端垂直虚拟线的距离

            filtered_points, angle_deg, distance_to_horizontal, mid_point, avg_y, start_point, end_point = analyze_angle(virtual_horizontal_line_y, segment_points, x_start, x_end)
            print('线段起始点： ', start_point)
            print('线段结束点： ', end_point)
            print('角度： ', angle_deg)
            if filtered_points is None:
                '''
                发送信号， 数据无效
                '''   
                continue

        # 需要发送的信息有： 角度： angle_deg， 距离水平虚拟线的距离： distance_to_horizontal, 角点距离垂直虚拟线的距离： verticla_line_distance
        # 384to600
        distance_to_horizontal = distance_to_horizontal * 600 / 384  # y距离
        verticla_line_distance = verticla_line_distance * 600 / 384  # x距离

        # 转为实际距离
        distance_to_horizontal = round(distance_to_horizontal * 0.07552, 2)
        verticla_line_distance = round(verticla_line_distance * 0.07552, 2)
    
        print('距离水平虚拟线的距离： ', distance_to_horizontal)
        print('角点距离垂直虚拟线的距离： ', verticla_line_distance)

        # 发送信号， 数据有效
        protocol.send_glue_task(
            x=verticla_line_distance,
            y=distance_to_horizontal,
            angle=angle_deg,
            x_invalid=x_invalid,
            y_invalid=y_invalid
        )

        print('+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++')
        print('init model cost time {} s'.format(time.time() - time_start))
        print('+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++')


        cv2.circle(pred_bgr, bottom_left_point, 8, (255, 0, 255), -1)  
        cv2.circle(pred_bgr, bottom_right_point, 8, (255, 0, 255), -1)  
        cv2.line(pred_bgr, tuple(np.array(bottom_right_point).astype(int)), (int(x_end), int(bottom_right_point[1])), (0, 144, 144), 3)  # 黄色：边界线
        cv2.circle(pred_bgr, (int(mid_point[0]), int(mid_point[1])), 5, (255, 0, 0), -1)  # 蓝色：中点
        cv2.line(pred_bgr, (int(x_start), 0), (int(x_start), img_height), (0, 255, 0), 2)
        cv2.line(pred_bgr, (int(x_end), 0), (int(x_end), img_height), (0, 255, 0), 2)
        # cv2.line(pred_bgr, (int(x_end), 0), (int(x_end), img_height), (0, 255, 0), 2)
        for p in segment_points:
            cv2.circle(pred_bgr, (int(p[0]), int(p[1])), 2, (0, 0, 255), -1)  # 红色：轮廓点
        cv2.line(pred_bgr, (0, int(virtual_horizontal_line_y)), (img_width, int(virtual_horizontal_line_y)), (0, 255, 0), 2)
        cv2.line(pred_bgr, (x_mid, int(avg_y)), (x_mid, virtual_horizontal_line_y), (0, 255, 255), 2)
        cv2.line(pred_bgr, tuple(start_point.astype(int)), tuple(end_point.astype(int)), (255, 255, 0), 2)
        cv2.putText(pred_bgr, f"angle: {angle_deg:.2f}", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)
        cv2.putText(pred_bgr, f"Y distance: {distance_to_horizontal:.2f}mm", (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)
        cv2.putText(pred_bgr, f"X distance: {verticla_line_distance:.2f}mm", (10, 90), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)
        cv2.imshow('pred_bgr', pred_bgr)

        cv2.imshow('pred1', pred1)
        # cv2.imshow('pred2', pred2)
        cv2.imshow('im_cp', im_cp)
        cv2.waitKey(1)
    
    cv2.destroyAllWindows()


