import copy
import sys
sys.path.insert(0, '')
sys.path.insert(0, '../../../')
sys.path.append('bisebetv2_cloth_segm')
import argparse
import math
import torch
import torch.nn.functional as F
import numpy as np
import cv2
import os
import lib.segmentation.data.transform_cv2 as T
from models.segmentation import model_factory
from configs.segmentation import set_cfg_from_file
import time
import logging
from calculate_angle import analyze_angle, get_bottom_contour_segment
from corner_detector_rect import find_fabric_corners_rect, visualize_rect_corners

# uncomment the following line if you want to reduce cpu usage, see issue #231
#  torch.set_num_threads(4)

torch.set_grad_enabled(False)
np.random.seed(123)

'''
D:\data_colloection\images\image23B3ML.jpg
D:\data_colloection\images\image246Q4U.jpg
'''

def visualize_prediction(output, class_colors):
    
    h, w = output.shape
    color_output = np.zeros((h, w, 3), dtype=np.uint8)
    
    for class_index, color in class_colors.items():
        color_output[output == class_index] = color
    
    return color_output

class_colors = {
    0: (0, 0, 0),       
    1: (0, 255, 0),     
    2: (0, 0, 255),     
    3: (255, 0, 0),    
    # Add more classes and colors as needed 
}


def find_corner_points(mask, angle_threshold=30):

    # 1. 先进行形态学操作去除锯齿
    kernel = np.ones((3,3), np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
    
    # 2. 轮廓提取和平滑
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        raise ValueError("未找到有效轮廓")
    
    contour = max(contours, key=cv2.contourArea)
    
    # 3. 使用Douglas-Peucker算法简化轮廓
    epsilon = 0.005 * cv2.arcLength(contour, True)
    approx_contour = cv2.approxPolyDP(contour, epsilon, True)
    
    
    # 5. 角点检测
    corner_points = []
    min_distance = 10  # 最小角点间距
    angels = []
    
    for i in range(1, len(approx_contour)):
        prev_point = approx_contour[i - 1].flatten()
        curr_point = approx_contour[i].flatten()
        next_point = approx_contour[(i + 1) % len(approx_contour)].flatten()
        
        # 计算向量
        vec1 = prev_point - curr_point
        vec2 = next_point - curr_point
        
        # 计算角度
        cos_angle = np.dot(vec1, vec2) / (np.linalg.norm(vec1) * np.linalg.norm(vec2))
        cos_angle = np.clip(cos_angle, -1.0, 1.0)  # 防止数值误差
        angle = np.degrees(np.arccos(cos_angle))
        angels.append(angle)
        
        # 检查是否为角点
        if angle < angle_threshold:
            # 检查与已有角点的距离
            if  all(np.linalg.norm(curr_point - np.array(p)) > min_distance for p in corner_points):
                # 根据向量方向判断是否为有效角点
                vec_angle = np.degrees(np.arctan2(vec1[1], vec1[0])) % 360
                # 只选择接近水平或垂直的角点
                if (vec_angle < 95 or vec_angle > 315 or 
                    (135 < vec_angle < 225)):         
                    corner_points.append(tuple(curr_point.astype(int)))
    
    # 6. 按x坐标排序
    corner_points = sorted(corner_points, key=lambda x: x[0])
    
    return corner_points, approx_contour, angels


# args
parse = argparse.ArgumentParser() 
parse.add_argument('--config', dest='config', type=str, default=r'bisebetv2_cloth_segm\configs\segmentation\bisenetv2_syt_segm_edge_Glue_the_hem_0909.py',)  
# parse.add_argument('--weight-path', type=str, default=r'0910_bgr_models\model_19.pth',)  # bgr 
parse.add_argument('--weight-path', type=str, default=r'glue_gray_model\model_34.pth',)    # gray
args = parse.parse_args()
cfg = set_cfg_from_file(args.config)
                                      

palette = np.random.randint(0, 256, (256, 3), dtype=np.uint8)              
cfg_dict = dict(cfg.__dict__)
in_channel = cfg_dict['in_ch']
# define model

if 'net_config' in cfg_dict:
    net = model_factory[cfg.model_type](cfg.n_cats,in_ch=in_channel, aux_mode='eval', net_config=cfg.net_config)
else:
    net = model_factory[cfg.model_type](cfg.n_cats,in_ch=in_channel, aux_mode='eval')

check_point = torch.load(args.weight_path, map_location='cpu')
if 'model_state_dict' in check_point:
    net.load_state_dict(check_point['model_state_dict'], strict=False)
else:
    net.load_state_dict(check_point, strict=False)

net.eval()
# net.cuda()

## dataset
# to_tensor = T.ToTensor(
#     mean=(0.3257, 0.3690, 0.3223), # city, rgb
#     std=(0.2112, 0.2148, 0.2115),
# )

to_tensor = T.ToTensor(
    mean=(0.5, 0.5, 0.5), 
    std=(0.5, 0.5, 0.5),
)

forbidden_combinations = [{1, 3}, {2, 3}, {1, 2, 3}]

img_dir = r'glue_1126'

img_list = os.listdir(img_dir)
target_size = (640, 480)           
if 'target_size' in cfg_dict:
    target_size = cfg_dict['target_size']
cv2.namedWindow('pred1',cv2.WINDOW_KEEPRATIO)
cv2.namedWindow('pred1',cv2.WINDOW_KEEPRATIO)
cv2.namedWindow('pred',cv2.WINDOW_KEEPRATIO)
# cv2.namedWindow('dst',cv2.WINDOW_KEEPRATIO)
cv2.namedWindow('img',cv2.WINDOW_KEEPRATIO)
cv2.namedWindow('mask', cv2.WINDOW_NORMAL)

for img_path in img_list:
    print(img_dir + img_path)
    if os.path.isdir(os.path.join(img_dir, img_path)):
        continue
    # if img_path[:3]=='img':
    #     continue
    if img_path[-3:] !='png':
        continue
    im = cv2.imread(img_dir + '/' + img_path)

# cap = cv2.VideoCapture(1, cv2.CAP_DSHOW)
# cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*'MJPG'))
# cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1920)
# cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 1080)
# ret, im = cap.read()
# while ret:
#     ret, im = cap.read()
#     print('im.shape:', im.shape)
    im = im[400:1000, 400:1000]

    orgin_img = copy.deepcopy(im)
    im = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY)
    im = cv2.cvtColor(im, cv2.COLOR_GRAY2BGR)
    im = cv2.resize(im, target_size)
    im = im[:, :, ::-1]  # bge to rgb
    im = np.ascontiguousarray(im)
    
    # im = to_tensor(dict(im=im, lb=None))['im'].unsqueeze(0).cuda()
    im = to_tensor(dict(im=im, lb=None))['im'].unsqueeze(0)

    # shape divisor
    org_size = im.size()[2:]
    # new_size = [math.ceil(el / 32) * 32 for el in im.size()[2:]]
 
    # inference
    # im = F.interpolate(im, size=new_size, align_corners=False, mode='bilinear')
    tm_begin = time.time()
    # out = net(im)[0]
    out = net(im)
    out = out[0]

    tm_end = time.time()
    print("Time cost infer is %lf seconds" % (tm_end - tm_begin))
    # out = F.interpolate(out, size=org_size, align_corners=False, mode='bilinear')
    out = out.argmax(dim=1)

    # visualize
    out = out.squeeze().detach().cpu().numpy()
    # 两个类
    pred1 = (out == 1).astype(np.uint8) * 255
    pred2 = (out == 2).astype(np.uint8) * 255
    pred_bgr = cv2.cvtColor(pred1, cv2.COLOR_GRAY2BGR)

    # 一个类
    # pred = np.where(out > 0, 255, 0).astype(np.uint8)
    # pred = cv2.resize(pred, (img_shape[1], img_shape[0]), interpolation=cv2.INTER_NEAREST)

    # 头尾边缘角点
    corners, segment_points, contour_points, rect_box, rect_bottom_left, rect_bottom_right = find_fabric_corners_rect(pred1)
    if corners is None:
        continue
    # visualize_rect_corners(pred_bgr, corners, contour_points, rect_box, rect_bottom_left, rect_bottom_right,
    #                       f"矩形角点检测 - {os.path.basename(img_path)}")

    img_height, img_width = pred_bgr.shape[:2]
    # 先设置虚拟线
    virtual_horizontal_line_y = img_height - 188

    # 在宽度方向分为4段
    segment_index = 2
    # 2. 将图像宽度分为4段
    segment_width = img_width / 4
    x_start = segment_index * segment_width
    x_end = (segment_index + 1) * segment_width
    print(f"图像宽度: {img_width}, 每段宽度: {segment_width:.1f}")
    print(f"截取第{segment_index + 1}段: x范围 [{x_start:.1f}, {x_end:.1f}]")
    x_mid = int((x_start + x_end) / 2)

    # contours, _ = cv2.findContours(pred1, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    # if len(contours) == 0:
    #     print('未找到轮廓')
    #     exit()
    
    # # 选择最大轮廓
    # max_contour = max(contours, key=cv2.contourArea)
    # bottom_left_point, bottom_right_point, bottom_segment = get_bottom_contour_segment(max_contour)


    # 上述已经找到底部得两个点， 需要获取它们之间的轮廓点
    bottom_left_point, bottom_right_point = corners[0], corners[1]

    # contour_points = max_contour.reshape(-1, 2)
    filtered_points, angle_deg, distance_to_horizontal, mid_point, avg_y, start_point, end_point = analyze_angle(virtual_horizontal_line_y, segment_points, x_start, x_end)
    if filtered_points is None:
        continue
    cv2.circle(pred_bgr, bottom_left_point, 8, (255, 0, 255), -1)  
    cv2.circle(pred_bgr, bottom_right_point, 8, (255, 0, 255), -1)  
    cv2.circle(pred_bgr, (int(mid_point[0]), int(mid_point[1])), 5, (255, 0, 0), -1)  # 蓝色：中点
    cv2.line(pred_bgr, (int(x_start), 0), (int(x_start), img_height), (0, 255, 0), 2)
    cv2.line(pred_bgr, (int(x_end), 0), (int(x_end), img_height), (0, 255, 0), 2)
    for p in segment_points:
        cv2.circle(pred_bgr, (int(p[0]), int(p[1])), 2, (0, 0, 255), -1)  # 红色：轮廓点
    cv2.line(pred_bgr, (0, int(virtual_horizontal_line_y)), (img_width, int(virtual_horizontal_line_y)), (0, 255, 0), 2)
    cv2.line(pred_bgr, (x_mid, int(avg_y)), (x_mid, virtual_horizontal_line_y), (0, 255, 255), 2)
    cv2.line(pred_bgr, tuple(start_point.astype(int)), tuple(end_point.astype(int)), (255, 255, 0), 2)
    cv2.putText(pred_bgr, f"angle: {angle_deg:.2f}", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)
    cv2.putText(pred_bgr, f"distance: {distance_to_horizontal:.2f}px", (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)
    cv2.imshow('mask', pred_bgr)



    # 找角点
    # corner_points, contour_points, angels = find_corner_points(pred1, 95)
    # if corner_points:
    #     for i in range(len(corner_points)):
    #         cv2.circle(pred, tuple(np.array(corner_points[i]).astype(int)), 2, (0, 0, 255), -1)
    # for i in range(len(contour_points)):
    #     cv2.circle(pred, tuple(np.array(contour_points[i][0]).astype(int)), 2, (255, 0, 0), -1)
        
    # dst = cv2.addWeighted(orgin_img, 0.8, pred, 0.5, 0)

    # out_result_path = 'out_result'
    # os.makedirs(out_result_path, exist_ok=True)
    # cv2.imwrite(os.path.join(out_result_path, img_path), dst)
  
    cv2.imshow('pred1', pred1)     
    # cv2.imshow('pred', pred)     
    cv2.imshow('pred2', pred2)

    # cv2.imshow('dst', dst)
    cv2.imshow('img', orgin_img)
    cv2.waitKey(1)
    time_str = time.strftime("%Y-%m-%d_%H-%M-%S", time.localtime())
    # cv2.imwrite(time_str + '.png', orgin_img)
    key = cv2.waitKey(0)
    # if ord('q') == key:
    #     break

cap.release()
cv2.destroyAllWindows()
