import cv2
import os
from pyModbusTCP.client import ModbusClient
import copy
import sys
# sys.path.insert(0, '')
# sys.path.insert(0, '../../../')
from os.path import dirname, abspath
currun_path = dirname(dirname(dirname(dirname(abspath(__file__)))))
# sys.path.insert(0, currun_path)
sys.path.append(currun_path)
import argparse
import math
import torch
import torch.nn.functional as F
import numpy as np
import cv2
import os
import lib.segmentation.data.transform_cv2 as T
from models.segmentation import model_factory
from configs.segmentation import set_cfg_from_file
import time


torch.set_grad_enabled(False)
np.random.seed(123)

              

# args
parse = argparse.ArgumentParser() 
parse.add_argument('--config', dest='config', type=str, default='configs/segmentation/bisenetv2_syt_segm_edge_hulk_0529.py',) 
parse.add_argument('--weight-path', type=str, default='model_10.pth',)  
parse.add_argument('--img_dir', dest='img_path', type=str, default='./example.png',)
args = parse.parse_args()
cfg = set_cfg_from_file(args.config)


palette = np.random.randint(0, 256, (256, 3), dtype=np.uint8)
cfg_dict = dict(cfg.__dict__)
in_channel = cfg_dict['in_ch']
# define model

net = model_factory[cfg.model_type](cfg.n_cats,in_ch=in_channel, aux_mode='eval', net_config=cfg.net_config)
net.load_state_dict(torch.load(args.weight_path, map_location='cpu'), strict=False)
net.eval()
# net.cuda()

# prepare data
if in_channel == 4:
    to_tensor = T.ToTensor(
        mean=(0.5, 0.5, 0.5, 0.0),  # city, rgb
        std=(0.5, 0.5, 0.5, 1.0),
    )
else:
    to_tensor = T.ToTensor(
        mean=(0.5, 0.5, 0.5),  # city, rgb
        std=(0.5, 0.5, 0.5),
    )

if 'target_size' in cfg_dict:
    target_size = cfg_dict['target_size']

# 创建 Modbus TCP 客户端
SERVER_HOST = '192.168.1.5'  # Modbus TCP 设备的 IP 地址
SERVER_PORT = 502  # Modbus TCP 设备的端口号
client = ModbusClient(host=SERVER_HOST, port=SERVER_PORT)

recording = False

cap = cv2.VideoCapture('/dev/video3') 
if not cap.isOpened():
    print("无法打开摄像头")
    exit()  
cap.set(cv2.CAP_PROP_EXPOSURE, 10)
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

# if not client.open():
#     print("无法连接到 Modbus TCP 服务器")
#     exit()

OFFSET = 50  # 640像素 等于5cm
i = 0
while True:
    # 读取寄存器中的数据
    client.open()
    if client.is_open:
        
        regs = client.read_holding_registers(320,1) # 读取第90个寄存器
        # print("布尔值为:", bool_value_1, bool_value_2, bool_value_2, bool_value_3)
        # data = regs
        data = regs[0]
        # print(data)

        # 在接收到指定的通信数据后开启或关闭录制
        if data == 1001:   
            print(data)         
            recording = True
        elif data == 0:
            recording = False
        
        if recording: 

            tm_begin = time.time()

            ret, frame = cap.read()
            frame = frame[0:240, :]

        # cv2.namedWindow('pred',cv2.WINDOW_KEEPRATIO)
        # cv2.namedWindow('dst',cv2.WINDOW_KEEPRATIO)
        # cv2.namedWindow('img',cv2.WINDOW_KEEPRATIO)

        #     cv2.imshow('img', im)
            img_shape = frame.shape
            origin_img = copy.deepcopy(frame)
            im = cv2.resize(frame, target_size)
            im = im[:, :, ::-1]  # bge to rgb
            im = np.ascontiguousarray(im)

            # im = to_tensor(dict(im=im, lb=None))['im'].unsqueeze(0).cuda()
            im = to_tensor(dict(im=im, lb=None))['im'].unsqueeze(0)
            # shape divisor
            org_size = im.size()[2:]
            # new_size = [math.ceil(el / 32) * 32 for el in im.size()[2:]]

            # inference
            # im = F.interpolate(im, size=new_size, align_corners=False, mode='bilinear')
            out = net(im)[0]
            # out = net(im)
            # out = out[0]

            tm_end = time.time()
            print("Time cost infer is %lf seconds" % (tm_end - tm_begin))
            # out = F.interpolate(out, size=org_size, align_corners=False, mode='bilinear')
            tm_begin_vis = time.time()

            out = out.argmax(dim=1)

            # visualize
            out = out.squeeze().detach().cpu().numpy()
            pred = np.where(out > 0, 255, 0).astype(np.uint8)

            contours, _ = cv2.findContours(pred, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            max_area = 0
            for cnt in contours:
                area = cv2.contourArea(cnt)
                if area > max_area:
                    max_area = area
                    # max_cnt = cnt
            print('max_area:', max_area)  
            if max_area > 27011 * 0.25:
                row, col = np.nonzero(pred)
                min_row = min(row)
                max_col = max(col[row == min_row])
                min_col = min(col[row == min_row])
                # cv2.circle(origin_img, (min_col, min_row), 10, (0, 0, 255), -1)
                # cv2.circle(origin_img, (max_col, min_row), 10, (0, 255, 0), -1)
                print('max_col:', max_col)
                offset = OFFSET / 640 * max_col
                offset = round(offset, 2) * 100
                print('offset:', offset)
                client.write_single_register(322, int(offset))
                tm_end_vis = time.time()
                print("Time cost vis is %lf seconds" % (tm_end_vis - tm_begin_vis))
                # with open('offsets.txt', 'a') as file:    
                #     file.write(f"{offset}\n")
                time_str = time.strftime(f'%Y-%m-%d_%H-%M-%S_{i}', time.localtime(time.time()))
                with open('offsets.txt', 'a') as file:
                    file.write(f"{time_str}: {offset}\n")
                

                # pred = cv2.resize(pred, (img_shape[1], img_shape[0]), interpolation=cv2.INTER_NEAREST)
                # pred = cv2.cvtColor(pred, cv2.COLOR_GRAY2BGR)
                # dst = cv2.addWeighted(origin_img, 0.8, pred, 0.5, 0)
                dst = cv2.circle(origin_img, (max_col, 1), 3, (0, 255, 0), -1)

                # time_str = time.strftime('%Y-%m-%d_%H-%M-%S', time.localtime(time.time()))
                out_result_path = 'out_result'
                # # os.makedirs(out_result_path, exist_ok=True)
                cv2.imwrite(os.path.join(out_result_path, time_str + '.png'), dst)
                i += 1

            # cv2.imshow('pred', pred)     
            # cv2.imshow('dst', dst)
            # key = cv2.waitKey(0)
            # if ord('q') == key:
            #     break
        else:
            client.write_single_register(322, int(0))


    else:
        print("无法连接到 Modbus TCP 服务器")