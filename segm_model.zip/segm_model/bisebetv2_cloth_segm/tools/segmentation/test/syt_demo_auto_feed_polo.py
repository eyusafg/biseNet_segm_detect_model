import copy
import sys
sys.path.insert(0, '')
sys.path.insert(0, '../../../')
sys.path.append('bisebetv2_cloth_segm')
import argparse
import math
import torch
import torch.nn.functional as F
import numpy as np
import cv2
import os
import lib.segmentation.data.transform_cv2 as T
from models.segmentation import model_factory
from configs.segmentation import set_cfg_from_file
import time
import logging
from calculate_angle import analyze_angle, get_bottom_contour_segment
from corner_detector_rect import find_fabric_corners_rect, visualize_rect_corners
from DHCaptureRag.new_camera import UsbCaptureSystem
from lib.segmentation.data.generate_boxes_along_contour import get_max_contour, generate_boxes_along_contour

# uncomment the following line if you want to reduce cpu usage, see issue #231
#  torch.set_num_threads(4)


to_tensor_second = T.ToTensor(
        mean=(0.5, 0.5, 0.5, 0.0),  # city, rgb
        std=(0.5, 0.5, 0.5, 1.0),
    )
to_tensor_first = T.ToTensor(
    mean=(0.5, 0.5, 0.5),  # city, rgb
    std=(0.5, 0.5, 0.5),
)

def enhance_contrast_and_sharpness(img: np.ndarray) -> np.ndarray:
    """
    对比度+锐化预处理，与数据增强时保持一致
    使用CLAHE增强L通道对比度，然后做轻度Unsharp Mask锐化
    """
    if img.dtype != np.uint8:
        img = np.clip(img, 0, 255).astype(np.uint8)
    
    # 转LAB空间，对L通道做CLAHE
    lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
    l, a, b = cv2.split(lab)
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    l_enhanced = clahe.apply(l)
    lab_enhanced = cv2.merge([l_enhanced, a, b])
    img_enhanced = cv2.cvtColor(lab_enhanced, cv2.COLOR_LAB2BGR)
    
    # Unsharp Mask锐化
    blurred = cv2.GaussianBlur(img_enhanced, (0, 0), sigmaX=1.0, sigmaY=1.0)
    alpha = 0.7
    sharp = cv2.addWeighted(img_enhanced, 1.0 + alpha, blurred, -alpha, 0)
    
    return sharp

def infer(net, im, to_tensor):

    im = to_tensor(dict(im=im, lb=None))['im'].unsqueeze(0)
    # im = to_tensor(dict(im=im, lb=None))['im'].unsqueeze(0)
    # shape divisor
    org_size = im.size()[2:]
    new_size = [math.ceil(el / 32) * 32 for el in im.size()[2:]]

    # inference
    im = F.interpolate(im, size=new_size, align_corners=False, mode='bilinear')
    tm_begin = time.time()
    out = net(im)[0]
    tm_end = time.time()
    print("Time cost infer is %lf seconds" % (tm_end - tm_begin))
    out = F.interpolate(out, size=org_size, align_corners=False, mode='bilinear')
    out = out.argmax(dim=1)

    # visualize
    out = out.squeeze().detach().cpu().numpy()
    pred = np.where(out > 0, 255, 0).astype(np.uint8)
    return pred
def predict(im, net_first, net_second, target_size = (384, 384), box_size = (352, 352), shift_size=16, box_step=1.0):
    img_shape = im.shape
    orgin_img = copy.deepcopy(im)
    
    # 应用对比度+锐化预处理（与数据增强保持一致）
    im = enhance_contrast_and_sharpness(im)
    
    im = cv2.resize(im, target_size)
    im = im[:, :, ::-1]  # bge to rgb
    im = np.ascontiguousarray(im)
    # first stage
    mask_first = infer(net_first, im, to_tensor_first)
    mask_first = cv2.resize(mask_first, (img_shape[1], img_shape[0]), interpolation=cv2.INTER_NEAREST)

    # second stage
    contours, _ = cv2.findContours(mask_first, cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE)  # 将所有轮廓点保存下来，不做近似处理
    cloth_contour = get_max_contour(contours)  # 最大轮廓 contur.shape= (n,1,2) n个轮廓，1个维度，2（x，y坐标）
    # contour = contours[0].astype(np.int32)
    cloth_contour = cloth_contour.reshape(cloth_contour.shape[0], cloth_contour.shape[2])
    # point_arr = np.array(cloth_contour, dtype=np.float32)
    # point_arr[:, 0] *= x_scale
    # point_arr[:, 1] *= y_scale
    boxes = generate_boxes_along_contour(cloth_contour, image_size=(img_shape[1], img_shape[0]),
                                         box_size=box_size, shift_size=shift_size, box_step=box_step)

    # roi_list_image = []
    # roi_list_mask = []
    mask_second_orgin = np.zeros([img_shape[0], img_shape[1]], np.uint8)
    for box in boxes: 
        x_tl = box['x']
        y_tl = box['y']
        x_br = box['x'] + box['width']
        y_br = box['y'] + box['height']

        # roi = image[y_tl : y_br, x_tl: x_br] # 原图上取roi
        x_tl, y_tl, x_br, y_br = int(x_tl), int(y_tl), int(x_br), int(y_br)
        # pt1 = (x_tl, y_tl)
        # pt2 = (x_br, y_br)
        # cv2.rectangle(image, pt1, pt2, (0, 255, 127), 4)
        # cv2.rectangle(mask, (x_tl, y_tl), (x_br, y_br), 255, 4)
        roi_image = orgin_img[y_tl:y_br, x_tl:x_br]
        roi_shape = roi_image.shape
        roi_mask = mask_first[y_tl:y_br, x_tl:x_br]

        # 对ROI也应用对比度+锐化预处理
        roi_image = enhance_contrast_and_sharpness(roi_image)
        
        roi_mask = cv2.resize(roi_mask, target_size, interpolation=cv2.INTER_NEAREST)
        roi_image = cv2.resize(roi_image, target_size, interpolation=cv2.INTER_NEAREST)
        roi_image = roi_image[:, :, ::-1]  # bge to rgb
        roi_image = np.ascontiguousarray(roi_image)
        roi_mask = np.where(roi_mask > 0, 255, 0).astype(np.uint8)
        if not len(roi_mask.shape) == 3:
            second_img = np.dstack((roi_image, np.expand_dims(roi_mask, axis=-1)))
        else:
            second_img = np.dstack((roi_image, roi_mask))
        roi_pred = infer(net_second, second_img, to_tensor_second)
        roi_pred = cv2.resize(roi_pred, (roi_shape[1], roi_shape[0]), interpolation=cv2.INTER_NEAREST)

        # roi_output = mask_second[y_tl:y_br, x_tl:x_br]
        mask_second_orgin[y_tl:y_br, x_tl:x_br] += roi_pred
        # cv2.imshow('roi_image', roi_image)
        # cv2.imshow('roi_mask', roi_mask)
        # cv2.imshow('roi_pred', roi_pred)

        # key = cv2.waitKey(0)
        # if ord('q') == key:
        #     break
    mask_second = np.zeros([img_shape[0], img_shape[1]], np.uint8)

    contours, _ = cv2.findContours(mask_second_orgin, cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE)  # 将所有轮廓点保存下来，不做近似处理
    cloth_contour = get_max_contour(contours)  # 最大轮廓 contur.shape= (n,1,2) n个轮廓，1个维度，2（x，y坐标）
    cv2.drawContours(mask_second, [cloth_contour], -1, 255, -1)
    cv2.drawContours(orgin_img, [cloth_contour], -1, (200, 50, 200), 8)
    return orgin_img, mask_first, mask_second

torch.set_grad_enabled(False)
np.random.seed(123)

def visualize_prediction(output, class_colors):
    
    h, w = output.shape
    color_output = np.zeros((h, w, 3), dtype=np.uint8)
    
    for class_index, color in class_colors.items():
        color_output[output == class_index] = color
    
    return color_output

class_colors = {
    0: (0, 0, 0),       
    1: (0, 255, 0),     
    2: (0, 0, 255),     
    3: (255, 0, 0),    
    # Add more classes and colors as needed 
}


def find_corner_points(mask, angle_threshold=30):

    # 1. 先进行形态学操作去除锯齿
    kernel = np.ones((3,3), np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
    
    # 2. 轮廓提取和平滑
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        raise ValueError("未找到有效轮廓")
    
    contour = max(contours, key=cv2.contourArea)
    
    # 3. 使用Douglas-Peucker算法简化轮廓
    epsilon = 0.005 * cv2.arcLength(contour, True)
    approx_contour = cv2.approxPolyDP(contour, epsilon, True)
    
    
    # 5. 角点检测
    corner_points = []
    min_distance = 10  # 最小角点间距
    angels = []
    
    for i in range(1, len(approx_contour)):
        prev_point = approx_contour[i - 1].flatten()
        curr_point = approx_contour[i].flatten()
        next_point = approx_contour[(i + 1) % len(approx_contour)].flatten()
        
        # 计算向量
        vec1 = prev_point - curr_point
        vec2 = next_point - curr_point
        
        # 计算角度
        cos_angle = np.dot(vec1, vec2) / (np.linalg.norm(vec1) * np.linalg.norm(vec2))
        cos_angle = np.clip(cos_angle, -1.0, 1.0)  # 防止数值误差
        angle = np.degrees(np.arccos(cos_angle))
        angels.append(angle)
        
        # 检查是否为角点
        if angle < angle_threshold:
            # 检查与已有角点的距离
            if  all(np.linalg.norm(curr_point - np.array(p)) > min_distance for p in corner_points):
                # 根据向量方向判断是否为有效角点
                vec_angle = np.degrees(np.arctan2(vec1[1], vec1[0])) % 360
                # 只选择接近水平或垂直的角点
                if (vec_angle < 95 or vec_angle > 315 or 
                    (135 < vec_angle < 225)):         
                    corner_points.append(tuple(curr_point.astype(int)))
    
    # 6. 按x坐标排序
    corner_points = sorted(corner_points, key=lambda x: x[0])
    
    return corner_points, approx_contour, angels


# args
parse = argparse.ArgumentParser() 
parse.add_argument('--config1', type=str, default=r'bisebetv2_cloth_segm\configs\segmentation\bisenetv2_syt_segm_edge_Glue_polo_auto_feed_0917_bgr_384.py',)  
parse.add_argument('--config2', type=str, default=r'bisebetv2_cloth_segm\configs\segmentation\bisenetv2_syt_segm_edge_Glue_polo_auto_feed_0917_bgr_384_ch4.py',)  
# parse.add_argument('--weight-path', type=str, default=r'0910_bgr_models\model_19.pth',)  # bgr 
parse.add_argument('--weight-path1', type=str, default=r'1023_model_polo\ch3\model_24.pth',)    # gray
parse.add_argument('--weight-path2', type=str, default=r'1023_model_polo\ch4\model_4.pth',)    # gray



args = parse.parse_args()
cfg1 = set_cfg_from_file(args.config1)
cfg2 = set_cfg_from_file(args.config2)
                                      

palette = np.random.randint(0, 256, (256, 3), dtype=np.uint8)              
cfg_dict1 = dict(cfg1.__dict__)
cfg_dict2 = dict(cfg2.__dict__)
in_channel1 = cfg_dict1['in_ch']
in_channel2 = cfg_dict2['in_ch']
# define model

if 'net_config' in cfg_dict1:
    net_first = model_factory[cfg1.model_type](cfg1.n_cats,in_ch=in_channel1, aux_mode='eval', net_config=cfg1.net_config)
    net_second = model_factory[cfg2.model_type](cfg2.n_cats,in_ch=in_channel2, aux_mode='eval', net_config=cfg2.net_config)
else:
    net_first = model_factory[cfg1.model_type](cfg1.n_cats,in_ch=in_channel1, aux_mode='eval')
    net_second = model_factory[cfg2.model_type](cfg2.n_cats,in_ch=in_channel2, aux_mode='eval')

check_point1 = torch.load(args.weight_path1, map_location='cpu')
check_point2 = torch.load(args.weight_path2, map_location='cpu')
if 'model_state_dict' in check_point1:
    net_first.load_state_dict(check_point1['model_state_dict'], strict=False)
    net_second.load_state_dict(check_point2['model_state_dict'], strict=False)
else:
    net_first.load_state_dict(check_point1, strict=False)
    net_second.load_state_dict(check_point2, strict=False)

net_first.eval()
net_second.eval()

## dataset
# to_tensor = T.ToTensor(
#     mean=(0.3257, 0.3690, 0.3223), # city, rgb
#     std=(0.2112, 0.2148, 0.2115),
# )

to_tensor = T.ToTensor(
    mean=(0.5, 0.5, 0.5), 
    std=(0.5, 0.5, 0.5),
)

forbidden_combinations = [{1, 3}, {2, 3}, {1, 2, 3}]

img_dir = r'C:\polo_auto_feeding\origin_imgs'
img_list = os.listdir(img_dir)
target_size = (640, 480)           
if 'target_size' in cfg_dict1:
    target_size = cfg_dict1['target_size']

# cv2.namedWindow('pred1',cv2.WINDOW_KEEPRATIO)
# cv2.namedWindow('pred1',cv2.WINDOW_KEEPRATIO)
# cv2.namedWindow('dst',cv2.WINDOW_KEEPRATIO)
# cv2.namedWindow('img',cv2.WINDOW_KEEPRATIO)
# cv2.namedWindow('mask', cv2.WINDOW_NORMAL)


# camera = UsbCaptureSystem()
# while True:
#     frame = camera.get_image()
#     if frame is None:
#         continue
#     im = frame[700:2200, 300:3900] 
    

for img_path in img_list:
    print(img_dir + img_path)
    if os.path.isdir(os.path.join(img_dir, img_path)):
        # continue
        # if img_path[:3]=='img':
        #     continue
        if '20251111' not in img_path:
            continue

        for sub_dir in os.listdir(os.path.join(img_dir, img_path)):
            print('img name: ', sub_dir)
            if os.path.isdir(os.path.join(img_dir, img_path, sub_dir)):
                continue

            if sub_dir[-3:] !='png':
                continue
            if 'circle' in sub_dir:
                continue

            im = cv2.imread(os.path.join(img_dir, img_path, sub_dir))
            # im = im[700:2500, 300:3950]
            im = im[200:2000, 500:3900]
            # im = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY)
            # im = cv2.cvtColor(im, cv2.COLOR_GRAY2BGR)
            orgin_img = copy.deepcopy(im)

            # im = im[700:2500, 300:3950]
            # im = im[700:2500, 300:3950]

            # im = cv2.resize(im, target_size)
            # im = im[:, :, ::-1]  # bge to rgb
            # im = np.ascontiguousarray(im)
            # im = to_tensor(dict(im=im, lb=None))['im'].unsqueeze(0)

            origin_img, mask_first, mask_second = predict(im, net_first, net_second, target_size)

            # 获取最小外接矩形
            mask_second_255 = np.where(mask_second > 0, 255, 0).astype(np.uint8)
            contours, _ = cv2.findContours(mask_second_255, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            max_contour = max(contours, key=cv2.contourArea)
            rect = cv2.minAreaRect(max_contour)
            box = cv2.boxPoints(rect)
            box = np.intp(box)
            # 输出外接矩形的w, h
            print('w, h: ', rect[1])

            # 将box外扩30
            center = rect[0]
            size = (rect[1][0] + 20, rect[1][1] + 20)
            angle = rect[2]
            expanded_rect = (center, size, angle)
            expanded_box = cv2.boxPoints(expanded_rect)
            expanded_box = np.intp(expanded_box)
            # 在原图上绘制最小外接矩形
            cv2.drawContours(origin_img, [expanded_box], 0, (0, 255, 255), 4)
        
            pred = cv2.cvtColor(mask_second, cv2.COLOR_GRAY2BGR)
            pred_mask_first = cv2.cvtColor(mask_first, cv2.COLOR_GRAY2BGR)
            dst = cv2.addWeighted(orgin_img, 0.8, pred, 0.2, 0)

            # 将mask_second直接显示在原图的红色通道上
            red_channel_result = orgin_img.copy()
            # 直接将mask区域的红色通道值设置为255
            red_channel_result = orgin_img.copy()
            # 直接将mask区域的红色通道值设置为255
            red_channel_result[mask_second > 0, 2] = 255  # OpenCV中索引2代表红色通道(BGR格式)
            # 与原图相减看看检测误差有多少
            mask_second_1 = np.where(mask_second > 0, 1, 0).astype(np.uint8)
            origin_img_gray = cv2.cvtColor(orgin_img, cv2.COLOR_BGR2GRAY)
            # 图像相乘
            target_cloth = mask_second_1 * origin_img_gray

            # dst_mask_first = cv2.addWeighted(orgin_img, 0.8, pred_mask_first, 0.5, 0)
            cv2.namedWindow('img',cv2.WINDOW_NORMAL)
            cv2.namedWindow('origin_img',cv2.WINDOW_NORMAL)
            cv2.namedWindow('dst',cv2.WINDOW_NORMAL)
            # cv2.namedWindow('dst_mask_first',cv2.WINDOW_NORMAL)
            cv2.namedWindow('mask_first',cv2.WINDOW_NORMAL)
            cv2.namedWindow('mask_second',cv2.WINDOW_NORMAL)
            cv2.namedWindow('red_channel_result',cv2.WINDOW_NORMAL)
            cv2.namedWindow('diff',cv2.WINDOW_NORMAL)

            cv2.imshow('img', orgin_img)
            cv2.imshow('origin_img', origin_img)
            cv2.imshow('mask_first', mask_first)
            cv2.imshow('mask_second', mask_second)
            cv2.imshow('dst', dst)
            cv2.imshow('red_channel_result', red_channel_result)
            cv2.imshow('diff', target_cloth)
            # cv2.imshow('dst_mask_first', dst_mask_first)

            # pad_mask_second = cv2.copyMakeBorder(mask_second, 200, 3672 - 2000, 500, 5496 - 3900, cv2.BORDER_CONSTANT, value=0)
            # cv2.imwrite('mask_second.png', pad_mask_second)

            # # shape divisor
            # org_size = im.size()[2:]
            # # new_size = [math.ceil(el / 32) * 32 for el in im.size()[2:]]
            # # inference
            # tm_begin = time.time()
            # # out = net(im)[0]
            # out = net(im)
            # out = out[0]
            # tm_end = time.time()
            # print("Time cost infer is %lf seconds" % (tm_end - tm_begin))
            # # out = F.interpolate(out, size=org_size, align_corners=False, mode='bilinear')
            # out = out.argmax(dim=1)
            # # visualize
            # out = out.squeeze().detach().cpu().numpy()
            # # 两个类
            # pred1 = (out == 1).astype(np.uint8) * 255
            # pred_bgr = cv2.cvtColor(pred1, cv2.COLOR_GRAY2BGR)
            # # 头尾边缘角点
            # corners, segment_points, contour_points, rect_box, rect_bottom_left, rect_bottom_right = find_fabric_corners_rect(pred1)
            # if corners is None:
            #     continue
            # # visualize_rect_corners(pred_bgr, corners, contour_points, rect_box, rect_bottom_left, rect_bottom_right,
            # #                       f"矩形角点检测 - {os.path.basename(img_path)}")
            # img_height, img_width = pred_bgr.shape[:2]
            # # 先设置虚拟线
            # virtual_horizontal_line_y = img_height - 188
            # # 在宽度方向分为4段
            # segment_index = 2
            # # 2. 将图像宽度分为4段
            # segment_width = img_width / 4
            # x_start = segment_index * segment_width
            # x_end = (segment_index + 1) * segment_width
            # print(f"图像宽度: {img_width}, 每段宽度: {segment_width:.1f}")
            # print(f"截取第{segment_index + 1}段: x范围 [{x_start:.1f}, {x_end:.1f}]")
            # x_mid = int((x_start + x_end) / 2)

            # # 上述已经找到底部得两个点， 需要获取它们之间的轮廓点
            # bottom_left_point, bottom_right_point = corners[0], corners[1]
            # # contour_points = max_contour.reshape(-1, 2)
            # filtered_points, angle_deg, distance_to_horizontal, mid_point, avg_y, start_point, end_point = analyze_angle(virtual_horizontal_line_y, segment_points, x_start, x_end)
            # if filtered_points is None:
            #     continue
            # cv2.circle(pred_bgr, bottom_left_point, 8, (255, 0, 255), -1)  
            # cv2.circle(pred_bgr, bottom_right_point, 8, (255, 0, 255), -1)  
            # cv2.circle(pred_bgr, (int(mid_point[0]), int(mid_point[1])), 5, (255, 0, 0), -1)  # 蓝色：中点
            # cv2.line(pred_bgr, (int(x_start), 0), (int(x_start), img_height), (0, 255, 0), 2)
            # cv2.line(pred_bgr, (int(x_end), 0), (int(x_end), img_height), (0, 255, 0), 2)
            # for p in segment_points:
            #     cv2.circle(pred_bgr, (int(p[0]), int(p[1])), 2, (0, 0, 255), -1)  # 红色：轮廓点
            # cv2.line(pred_bgr, (0, int(virtual_horizontal_line_y)), (img_width, int(virtual_horizontal_line_y)), (0, 255, 0), 2)
            # cv2.line(pred_bgr, (x_mid, int(avg_y)), (x_mid, virtual_horizontal_line_y), (0, 255, 255), 2)
            # cv2.line(pred_bgr, tuple(start_point.astype(int)), tuple(end_point.astype(int)), (255, 255, 0), 2)
            # cv2.putText(pred_bgr, f"angle: {angle_deg:.2f}", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)
            # cv2.putText(pred_bgr, f"distance: {distance_to_horizontal:.2f}px", (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)
            # cv2.imshow('mask', pred_bgr)

            # pred_resize = cv2.resize(pred1, (orgin_img.shape[1], orgin_img.shape[0]), interpolation=cv2.INTER_NEAREST)
            # pred_resize_bgr = cv2.cvtColor(pred_resize, cv2.COLOR_GRAY2BGR)
            # dst = cv2.addWeighted(orgin_img, 0.8, pred_resize_bgr, 0.5, 0)
            # cv2.imshow('pred1', pred1)         
            # cv2.imshow('dst', dst)
            # cv2.imshow('img', orgin_img)
            # cv2.waitKey(0)
            # time_str = time.strftime("%Y-%m-%d_%H-%M-%S", time.localtime())
            # # cv2.imwrite(time_str + '.png', orgin_img)
            key = cv2.waitKey(0)
            if ord('q') == key:
                break
        # camera.close()
        cv2.destroyAllWindows()
