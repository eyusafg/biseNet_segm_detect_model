import copy
import sys
sys.path.insert(0, '')
sys.path.insert(0, '../../../')
sys.path.append('bisebetv2_cloth_segm')
import argparse
import math
import torch
import torch.nn.functional as F
import numpy as np
import cv2
import os
import lib.segmentation.data.transform_cv2 as T
from models.segmentation import model_factory
from configs.segmentation import set_cfg_from_file
import time
from lib.segmentation.data.generate_boxes_along_contour import get_max_contour, generate_boxes_along_contour
from tools.segmentation.corner_detect.calcelate_real_size import calculate_real_size
from tools.segmentation.corner_detect.measure_neck import MeasureNeck
# uncomment the following line if you want to reduce cpu usage, see issue #231
#  torch.set_num_threads(4)

# torch.set_grad_enabled(False)
np.random.seed(123)


# args
parse = argparse.ArgumentParser()
# parse.add_argument('--config', dest='config', type=str, default='configs/bisenetv2.py',)
parse.add_argument('--img_dir', type=str, default=r'C:\measure_size_gui\Data\sweater_data\20250731_dahuo\images',)
parse.add_argument('--use_camera', type=bool, default=False,)
parse.add_argument('--weight-path1', type=str, default=r'sweater_segm_model\model_24.pth',)
parse.add_argument('--weight-path2', type=str, default=r'sweater_segm_model\model_4_second.pth',)
parse.add_argument('--cfg1', type=str, default=r'bisebetv2_cloth_segm\configs\segmentation\bisenetv2_syt_segm_edge_sweater_0821.py',)
parse.add_argument('--cfg2', type=str, default=r'bisebetv2_cloth_segm\configs\segmentation\bisenetv2_syt_segm_edge_sweater_ch4.py',)
args = parse.parse_args()
# cfg = set_cfg_from_file(args.config)
cfg_first = set_cfg_from_file(args.cfg1)
cfg_second = set_cfg_from_file(args.cfg2)

cfg_first_dict = dict(cfg_first.__dict__)
cfg_second_dict = dict(cfg_second.__dict__)
in_channel = cfg_first_dict['in_ch']
to_tensor_second = T.ToTensor(
        mean=(0.5, 0.5, 0.5, 0.0),  # city, rgb
        std=(0.5, 0.5, 0.5, 1.0),
    )
to_tensor_first = T.ToTensor(
    mean=(0.5, 0.5, 0.5),  # city, rgb
    std=(0.5, 0.5, 0.5),
)

def infer(net, im, to_tensor):

    im = to_tensor(dict(im=im, lb=None))['im'].unsqueeze(0).cuda()
    # im = to_tensor(dict(im=im, lb=None))['im'].unsqueeze(0)
    # shape divisor
    org_size = im.size()[2:]
    new_size = [math.ceil(el / 32) * 32 for el in im.size()[2:]]

    # inference
    im = F.interpolate(im, size=new_size, align_corners=False, mode='bilinear')
    tm_begin = time.time()
    out = net(im)[0]
    tm_end = time.time()
    print("Time cost infer is %lf seconds" % (tm_end - tm_begin))
    out = F.interpolate(out, size=org_size, align_corners=False, mode='bilinear')
    out = out.argmax(dim=1)

    # visualize
    out = out.squeeze().detach().cpu().numpy()
    pred = np.where(out > 0, 255, 0).astype(np.uint8)
    return pred
def predict(im, net_first, net_second, target_size = (384, 384), box_size = (352, 352), shift_size=16, box_step=1.0):
    img_shape = im.shape
    orgin_img = copy.deepcopy(im)
    im = cv2.resize(im, target_size)
    im = im[:, :, ::-1]  # bge to rgb

    # first stage
    mask_first = infer(net_first, im, to_tensor_first)
    mask_first = cv2.resize(mask_first, (img_shape[1], img_shape[0]), interpolation=cv2.INTER_NEAREST)

    # second stage
    contours, _ = cv2.findContours(mask_first, cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE)  # 将所有轮廓点保存下来，不做近似处理
    cloth_contour = get_max_contour(contours)  # 最大轮廓 contur.shape= (n,1,2) n个轮廓，1个维度，2（x，y坐标）
    # contour = contours[0].astype(np.int32)
    cloth_contour = cloth_contour.reshape(cloth_contour.shape[0], cloth_contour.shape[2])
    # point_arr = np.array(cloth_contour, dtype=np.float32)
    # point_arr[:, 0] *= x_scale
    # point_arr[:, 1] *= y_scale
    boxes = generate_boxes_along_contour(cloth_contour, image_size=(img_shape[1], img_shape[0]),
                                         box_size=box_size, shift_size=shift_size, box_step=box_step)

    # roi_list_image = []
    # roi_list_mask = []
    mask_second_orgin = np.zeros([img_shape[0], img_shape[1]], np.uint8)
    for box in boxes:
        x_tl = box['x']
        y_tl = box['y']
        x_br = box['x'] + box['width']
        y_br = box['y'] + box['height']

        # roi = image[y_tl : y_br, x_tl: x_br] # 原图上取roi
        x_tl, y_tl, x_br, y_br = int(x_tl), int(y_tl), int(x_br), int(y_br)
        # pt1 = (x_tl, y_tl)
        # pt2 = (x_br, y_br)
        # cv2.rectangle(image, pt1, pt2, (0, 255, 127), 4)
        # cv2.rectangle(mask, (x_tl, y_tl), (x_br, y_br), 255, 4)
        roi_image = orgin_img[y_tl:y_br, x_tl:x_br]
        roi_shape = roi_image.shape
        roi_mask = mask_first[y_tl:y_br, x_tl:x_br]

        roi_mask = cv2.resize(roi_mask, target_size, interpolation=cv2.INTER_NEAREST)
        roi_image = cv2.resize(roi_image, target_size, interpolation=cv2.INTER_NEAREST)
        roi_mask = np.where(roi_mask > 0, 255, 0).astype(np.uint8)
        if not len(roi_mask.shape) == 3:
            second_img = np.dstack((roi_image, np.expand_dims(roi_mask, axis=-1)))
        else:
            second_img = np.dstack((roi_image, roi_mask))
        roi_pred = infer(net_second, second_img, to_tensor_second)
        roi_pred = cv2.resize(roi_pred, (roi_shape[1], roi_shape[0]), interpolation=cv2.INTER_NEAREST)

        # roi_output = mask_second[y_tl:y_br, x_tl:x_br]
        mask_second_orgin[y_tl:y_br, x_tl:x_br] += roi_pred
        # cv2.imshow('roi_image', roi_image)
        # cv2.imshow('roi_mask', roi_mask)
        # cv2.imshow('roi_pred', roi_pred)

        # key = cv2.waitKey(0)
        # if ord('q') == key:
        #     break
    mask_second = np.zeros([img_shape[0], img_shape[1]], np.uint8)

    contours, _ = cv2.findContours(mask_second_orgin, cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE)  # 将所有轮廓点保存下来，不做近似处理
    cloth_contour = get_max_contour(contours)  # 最大轮廓 contur.shape= (n,1,2) n个轮廓，1个维度，2（x，y坐标）
    cv2.drawContours(mask_second, [cloth_contour], -1, 255, -1)
    cv2.drawContours(orgin_img, [cloth_contour], -1, (200, 50, 200), 8)
    return orgin_img, mask_first, mask_second

def test():



    # define model

    if 'net_config' in cfg_first_dict:
        net_first = model_factory[cfg_first.model_type](cfg_first.n_cats,in_ch=in_channel, aux_mode='eval', net_config=cfg_first.net_config)
        net_second = model_factory[cfg_second.model_type](cfg_second.n_cats,in_ch=4, aux_mode='eval', net_config=cfg_second.net_config)
    else:
        net_first = model_factory[cfg_first.model_type](cfg_first.n_cats,in_ch=in_channel, aux_mode='eval')
        net_second = model_factory[cfg_second.model_type](cfg_second.n_cats,in_ch=4, aux_mode='eval')
    # net_first = model_factory[cfg.model_type](cfg.n_cats, aux_mode='eval')
    check_point1 = torch.load(args.weight_path1, map_location='cpu')
    check_point2 = torch.load(args.weight_path2, map_location='cpu')
    if 'model_state_dict' in check_point1 and 'model_state_dict' in check_point2:
        net_first.load_state_dict(check_point1['model_state_dict'], strict=False)
        net_second.load_state_dict(check_point2['model_state_dict'], strict=False)
    else:
        net_first.load_state_dict(check_point1, strict=False)
        net_first.load_state_dict(check_point2, strict=False)

    # net_first.load_state_dict(torch.load(args.weight_path1, map_location='cpu'), strict=False)
    # net_second.load_state_dict(torch.load(args.weight_path2, map_location='cpu'), strict=False)
    net_first.eval()
    net_second.eval()
    net_first.cuda()
    net_second.cuda()

    ## dataset
    # to_tensor = T.ToTensor(
    #     mean=(0.3257, 0.3690, 0.3223), # city, rgb
    #     std=(0.2112, 0.2148, 0.2115),
    # )
    # prepare data


    # img_dir = '/home/syt/datasets/segm/2023-07-31/'
    # img_dir = '/home/syt/datasets/ClothEdgeErrorLogs/'


    # img_dir = '/home/syt/datasets/8_1-2/'
    # img_dir = '/home/syt/datasets/images/images (copy)/'
    # img_dir = '/home/syt/datasets/cloth_segment/ClothSegment/train/images/'
    img_dir = args.img_dir
    # img_dir = 'C:/Users/Administrator/dataset/20230713/'

    # img_dir = '/home/syt/datasets/cloth_segment/second_stage/train/images/'

    # 读取文件夹中的图片
    target_size = (384, 384)
    if 'target_size' in cfg_first_dict:
        target_size = cfg_first_dict['target_size']



    if args.use_camera:

        cap = cv2.VideoCapture(1, cv2.CAP_DSHOW)
        cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc('M', 'J', 'P', 'G'))
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, 3840)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 2880)
        ret, frame = cap.read()

        if ret:
            print('no camera')
        
        while True:
            ret, im = cap.read() 
            im = im[530:2130, 1400:2200]
            im = cv2.copyMakeBorder(im, 0, 0, 800,0, cv2.BORDER_CONSTANT, value=[0, 0, 0])
            if not ret:
                print('no camera')
                break
    else:
        img_list = os.listdir(img_dir)
        cv2.namedWindow('mask_first',cv2.WINDOW_NORMAL)
        cv2.namedWindow('mask_second',cv2.WINDOW_NORMAL)
        cv2.namedWindow('dst',cv2.WINDOW_KEEPRATIO)
        cv2.namedWindow('img',cv2.WINDOW_NORMAL)
        for img_path in img_list:
            print(img_dir + img_path)
            if img_path[:3]=='img':
                continue
            if 'xml' in img_path:
                continue
            # im = cv2.imread(args.img_path)

            # im = cv2.imdecode(np.fromfile(img_dir + '/' + img_path,dtype=np.uint8),-1)
            im = cv2.imread(img_dir + '/' + img_path)
        # 读取文件夹中的图片

        # # im = im[:,im.shape[1]//2:]
        # if img_path.find('left') == -1:
        #     im = im[:, im.shape[1]//2:]
        # else:
        #     im = im[:, :im.shape[1]//2:]
        # # im = cv2.imread('/home/syt/datasets/ClothEdgeErrorLogs/2023-08-01-23-26-30-right-machine-right-camera.png')

            orgin_img, mask_first, mask_second = predict(im, net_first, net_second, target_size)
            # contours, _ = cv2.findContours(mask_second, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)
            # contour = max(contours, key=cv2.contourArea)
           
            # pred = cv2.cvtColor(pred, cv2.COLOR_GRAY2BGR)
            # dst = cv2.addWeighted(orgin_img, 0.8, pred, 0.5, 0)

            cv2.imshow('img', orgin_img)
            cv2.imshow('mask_first', mask_first)
            cv2.imshow('mask_second', mask_second)
            cv2.imshow('dst', im)
            key = cv2.waitKey(0)
            if ord('q') == key:
                
                break
if __name__ == '__main__':
    test()

