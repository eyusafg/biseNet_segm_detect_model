
#include <random>
#include <iostream>
#include <string>
#include <vector>
#include <chrono>
#include<dirent.h>
#include <opencv2/opencv.hpp>
#include <inference_engine.hpp>
#include <sys/time.h>



std::string device("CPU"); // GNA does not support argmax, my cpu does not has integrated gpu


class ClothSegmInfer
{
private:
    float* p_inp_ = NULL;
    std::vector<unsigned long> insize_;
    InferenceEngine::InferRequest infer_request_;
    InferenceEngine::CNNNetwork model_;
    InferenceEngine::DataPtr output_info_;
    std::vector<cv::Mat> get_predict(int* data,std::vector<unsigned long> outsize, int input_imgs_num=1);
public:
    ClothSegmInfer(std::string model_pth,unsigned int batch_size = 1U);
    unsigned int batch_size_;
    std::vector<cv::Mat> infer(int input_imgs_num=1);
    void setInputData(const cv::Mat input_img);
    void setInputData(const cv::Mat input_img, const cv::Mat input_mask);
    void setInputData(std::vector<cv::Mat> input_img, std::vector<cv::Mat> input_mask);
};
class ClothSegmentDL
{
private:
    std::shared_ptr<ClothSegmInfer> cloth_segm_one_;
    std::shared_ptr<ClothSegmInfer> cloth_segm_two_;
    cv::Mat inferTwoStage(cv::Mat& input_img,const cv::Mat input_mask);
    int generateBoxesAlongContour(
      const std::vector<cv::Point2i> &contour, std::vector<cv::Rect2i> &boxes, 
      cv::Point& out_boxs_lt, cv::Point& out_boxs_br,
      const cv::Size &box_size,const int shift_size, const cv::Size &image_size);
public:
    ClothSegmentDL(std::string model_path1,std::string model_pth2);
    cv::Mat segment(cv::Mat input_img);

};

ClothSegmentDL::ClothSegmentDL(std::string model_path1,std::string model_path2)
{
    this->cloth_segm_one_ = std::make_shared<ClothSegmInfer>(model_path1);
    this->cloth_segm_two_ = std::make_shared<ClothSegmInfer>(model_path2,4U);
}
cv::Mat ClothSegmentDL::segment(cv::Mat input_img)
{

    // one stage
    this->cloth_segm_one_->setInputData(input_img);
    cv::Mat mask_one_stage_orgin = this->cloth_segm_one_->infer()[0];
    cv::resize(mask_one_stage_orgin,mask_one_stage_orgin,input_img.size());
    // cv::Mat img_show;
    // cv::resize(mask_one_stage_orgin,img_show,mask_one_stage_orgin.size()/4);
    // cv::imshow("mask_one_stage_orgin",img_show);
    // two stage
    return inferTwoStage(input_img,mask_one_stage_orgin);;
}


ClothSegmInfer::ClothSegmInfer(std::string model_pth,unsigned int batch_size)
{
    std::string device("CPU"); // GNA does not support argmax, my cpu does not has integrated gpu
    // model setup
    InferenceEngine::Core ie;
    this->model_ = ie.ReadNetwork(model_pth);
    this->batch_size_ = batch_size;
    this->model_.setBatchSize(batch_size);
    InferenceEngine::InputsDataMap inputs(this->model_.getInputsInfo());
    InferenceEngine::InputInfo::Ptr input_info = inputs.begin()->second;
    input_info->setPrecision(InferenceEngine::Precision::FP32);
    input_info->setLayout(InferenceEngine::Layout::NCHW);
    this->output_info_ = this->model_.getOutputsInfo().begin()->second;
    this->output_info_->setPrecision(InferenceEngine::Precision::I32);
    InferenceEngine::ExecutableNetwork network = ie.LoadNetwork(this->model_, device);
    this->infer_request_ = network.CreateInferRequest();
    std::string in_name = inputs.begin()->first;
    this->insize_ = input_info->getTensorDesc().getDims();
    InferenceEngine::Blob::Ptr inblob = this->infer_request_.GetBlob(in_name);
    InferenceEngine::MemoryBlob::Ptr minput = InferenceEngine::as<InferenceEngine::MemoryBlob>(inblob);
    if (!minput) {
        std::cerr << "We expect MemoryBlob from inferRequest, but by fact we "
                            "were not able to cast inputBlob to MemoryBlob"
                        << std::endl;
        std::abort();
    }
    auto minputHolder = minput->wmap();
    this->p_inp_ = minputHolder.as<float*>();
}
std::vector<cv::Mat> ClothSegmInfer::infer(int input_imgs_num)
{
    this->infer_request_.Infer();
    std::string out_name = this->model_.getOutputsInfo().begin()->first;
    auto outsize = this->output_info_->getTensorDesc().getDims();
    InferenceEngine::Blob::Ptr outblob = this->infer_request_.GetBlob(out_name);
    InferenceEngine::MemoryBlob::Ptr moutput = InferenceEngine::as<InferenceEngine::MemoryBlob>(outblob);
    auto moutputHolder = moutput->rmap();
    int* p_outp = moutputHolder.as<int*>();
    return get_predict(p_outp,outsize,input_imgs_num);;

}
void ClothSegmInfer::setInputData(cv::Mat input_img) 
{
    int iH = this->insize_[2];
    int iW = this->insize_[3];
    cv::Mat im = input_img.clone();
    int orgH{im.rows}, orgW{im.cols};
    if ((orgH != iH) || orgW != iW) {
        std::cout << "resize orignal image of (" << orgH << "," << orgW 
            << ") to (" << iH << ", " << iW << ") according to model requirement\n";
        cv::resize(im, im, cv::Size(iW, iH), cv::INTER_CUBIC);
    }
    float scale = 1.f / 255.f;
    for (int h{0}; h < iH; ++h) {
        cv::Vec3b *p = im.ptr<cv::Vec3b>(h);
        for (int w{0}; w < iW; ++w) {
            for (int c{0}; c < 3; ++c) {
                int idx = (2 - c) * iH * iW + h * iW + w; // to rgb order
                this->p_inp_[idx] = (p[w][c] * scale);
            }
        }
    }
}
void ClothSegmInfer::setInputData(cv::Mat input_img, cv::Mat input_mask) 
{
    int iH = this->insize_[2];
    int iW = this->insize_[3];
    // cv::Mat im = input_img.clone();
    int orgH{input_img.rows}, orgW{input_img.cols};
    if ((orgH != iH) || orgW != iW) {
        std::cout << "resize orignal image of (" << orgH << "," << orgW 
            << ") to (" << iH << ", " << iW << ") according to model requirement\n";
        cv::resize(input_img, input_img, cv::Size(iW, iH), cv::INTER_CUBIC);
    }
    float scale = 1.f / 255.f;
    for (int h{0}; h < iH; ++h) {
        cv::Vec3b *p = input_img.ptr<cv::Vec3b>(h);
        uchar *p_mask = input_mask.ptr<uchar>(h);
        for (int w{0}; w < iW; ++w) {
            for (int c{0}; c < 4; ++c) {
                if(c<3)
                {
                    int idx = (2 - c) * iH * iW + h * iW + w; // to rgb order
                    this->p_inp_[idx] = (p[w][c] * scale);                   
                }
                else
                {
                    int idx = c * iH * iW + h * iW + w;
                    this->p_inp_[idx] = (p_mask[w] * scale);        
                }
            }
        }
    }
}
void ClothSegmInfer::setInputData(std::vector<cv::Mat> input_img_vec, std::vector<cv::Mat> input_mask_vec) 
{
    // int iN = insize[0];
    int iH = this->insize_[2];
    int iW = this->insize_[3];
    if(input_img_vec.size() != input_mask_vec.size())
        printf("error: set input data!\n");
    // cv::Mat im = input_img.clone();
    for (size_t n=0;n<input_img_vec.size();n++)
    {
        int orgH{input_img_vec[n].rows}, orgW{input_img_vec[n].cols};
        if ((orgH != iH) || orgW != iW) {
            std::cout << "resize orignal image of (" << orgH << "," << orgW 
                << ") to (" << iH << ", " << iW << ") according to model requirement\n";
            cv::resize(input_img_vec[n], input_img_vec[n], cv::Size(iW, iH), cv::INTER_CUBIC);
        }
        float scale = 1.f / 255.f;
        for (int h{0}; h < iH; ++h) {
            cv::Vec3b *p = input_img_vec[n].ptr<cv::Vec3b>(h);
            uchar *p_mask = input_mask_vec[n].ptr<uchar>(h);
            for (int w{0}; w < iW; ++w) {
                for (int c{0}; c < 4; ++c) {
                    if(c<3)
                    {
                        int idx = (2 - c) * iH * iW + h * iW + w; // to rgb order
                        idx += n * iH * iW * 4;
                        this->p_inp_[idx] = (p[w][c] * scale);                   
                    }
                    else
                    {
                        int idx = c * iH * iW + h * iW + w;
                        idx += n * iH * iW * 4;
                        this->p_inp_[idx] = (p_mask[w] * scale);        
                    }
                }
            }
        }

    }
}
std::vector<cv::Mat> ClothSegmInfer::get_predict(int* data, std::vector<unsigned long> outsize, int input_imgs_num)
{

    std::vector<cv::Mat> predict_vec;
    // int oN = outsize[0];
    int oH = outsize[1];
    int oW = outsize[2];
    cv::Mat pred(cv::Size(oW, oH), CV_8UC1);
    for (int n{0}; n < input_imgs_num; ++n) { 
        int idx{n * oH * oW};
        for (int i{0}; i < oH; ++i) {
            uint8_t *ptr = pred.ptr<uint8_t>(i);
            for (int j{0}; j < oW; ++j) {
                *ptr = uint8_t(data[idx]==0?0:255);
                ptr++;
                ++idx;
            }
        }
        predict_vec.push_back(pred.clone());
    }
    return predict_vec;
}



struct timeval t_start;
float time_use=0;
struct timeval t_end;
int main() {

    struct dirent *ptr;    
    DIR *dir;
    // std::string PATH = "/home/syt/test_data/20230510";
    // std::string PATH = "/home/syt/20230713";
    // std::string PATH = "/home/syt/datasets/8_1-2/";
    // std::string PATH = "/home/syt/save_img/";
    std::string PATH = "/home/syt/datasets/20230713/";
    dir=opendir(PATH.c_str()); 
    std::vector<std::string> files(0);
    std::cout << "文件列表: "<< std::endl;
    while((ptr=readdir(dir))!=NULL)
    {

        //跳过'.'和'..'两个目录
        if(ptr->d_name[0] == '.')
            continue;

        files.push_back(ptr->d_name);
    }
    
    for (size_t i = 0; i < files.size(); ++i)
    {
        std::cout << files[i] << std::endl;
    }

    closedir(dir);

    // xzh
    ClothSegmentDL cloth_segm(
        "/home/syt/Documents/BiSeNet/openvino/model_onestage.onnx",
        "/home/syt/Documents/BiSeNet/openvino/model_twostage.onnx"
    );

    for (size_t i = 0; i < files.size(); i++)
    {
        std::string file_path = PATH + "/" + files[i];
        // file_path = "/home/syt/datasets/20230713//2023-07-13_21_21_51_420.bmp";
        // set input data    
        std::cout << "set input data from: " << file_path << std::endl;
        // cv::Mat img = get_image(impth, insize, p_inp);
        cv::Mat img = cv::imread(file_path);
        int img_w = img.size().width;
        int img_h = img.size().height;
        if (false) 
        {
            img = img(cv::Range(0, img_h), cv::Range(0, img_w / 2));
        } else {
            img = img(cv::Range(0, img_h), cv::Range(img_w / 2, img_w));
        }      
        // gettimeofday(&t_start,NULL); //gettimeofday(&start,&tz);结果一样
        if (img.empty()) {
            std::cerr << "cv::imread failed: " << file_path << std::endl;
            std::abort();
        }
        cv::cvtColor(img,img,cv::COLOR_BGR2RGB);

        gettimeofday(&t_start,NULL);

        // xzh
        cv::Mat mask_two_stage = cloth_segm.segment(img);
   
        gettimeofday(&t_end,NULL);
        time_use=(t_end.tv_sec-t_start.tv_sec)*1000000+(t_end.tv_usec-t_start.tv_usec);//微秒
        printf("time_use is %.10f\n",time_use/1000.0);//ms

        cv::Mat img_show;
        cv::resize(mask_two_stage,img_show,mask_two_stage.size()/4);
        cv::imshow("mask_two_stage",img_show);

        cv::cvtColor(img,img,cv::COLOR_RGB2BGR);
        cv::resize(img,img_show,img.size()/4);
        cv::imshow("img",img_show);

        cv::waitKey(0);
    }
    return 0;
}
cv::Mat ClothSegmentDL::inferTwoStage(cv::Mat& input_img,const cv::Mat input_mask)
{

    std::vector<std::vector<cv::Point2i>> contours;
    std::vector<cv::Vec4i> hierarchy;
    cv::findContours(input_mask, contours, hierarchy, cv::RETR_TREE,cv::CHAIN_APPROX_NONE);
    float max_area = 0;
    std::vector<cv::Point> max_contour;
    for(auto& contour:contours)
    {
        float curr_area = cv::contourArea(contour);
        if(curr_area>max_area)
        {
            max_area = curr_area;
            max_contour = contour;
        }
    }
    std::vector<std::vector<cv::Point>> contour_vector;
    contour_vector.push_back(max_contour);
    cv::Mat mask_one_stage = cv::Mat::zeros(input_mask.size(),CV_8UC1);
    cv::drawContours(mask_one_stage,contour_vector,0,cv::Scalar(255),-1);
    std::vector<cv::Rect2i> boxes(0);
    cv::Point boxs_lt, boxs_br;
    cv::Size box_size = cv::Size(352,352);
    int shift_size = 16;
    generateBoxesAlongContour(max_contour,boxes,boxs_lt,boxs_br,box_size,shift_size,input_mask.size());
    cv::Mat mask_two_stage_orgin = cv::Mat::zeros(input_img.size(),CV_8UC1);

    cv::Mat img_show = mask_one_stage.clone();
    std::vector<cv::Mat> input_img_roi_vec;
    std::vector<cv::Mat> input_mask_roi_vec;
    

    for (size_t i = 0; i < boxes.size(); i++)
    {
        // boxes[i].x -= boxs_lt.x;
        // boxes[i].y -= boxs_lt.y;
        cv::Mat roi_1 = input_img(cv::Range(boxes[i].y, boxes[i].y + boxes[i].height), cv::Range(boxes[i].x, boxes[i].x + boxes[i].width));
        cv::Mat roi_2 = input_mask(cv::Range(boxes[i].y, boxes[i].y + boxes[i].height), cv::Range(boxes[i].x, boxes[i].x + boxes[i].width));
        input_img_roi_vec.push_back(roi_1);
        input_mask_roi_vec.push_back(roi_2);
        if(input_img_roi_vec.size()== this->cloth_segm_two_->batch_size_ || i==boxes.size()-1)
        {
            this->cloth_segm_two_->setInputData(input_img_roi_vec,input_mask_roi_vec);
            std::vector<cv::Mat> output_roi_vec = this->cloth_segm_two_->infer(input_img_roi_vec.size());
            
            for (size_t n = 0; n < input_img_roi_vec.size(); n++)
            {
                int box_idx = i-input_img_roi_vec.size()+1+n;
                cv::Mat mask_two_stage_orgin_roi = mask_two_stage_orgin(cv::Range(boxes[box_idx].y, boxes[box_idx].y + boxes[box_idx].height), cv::Range(boxes[box_idx].x, boxes[box_idx].x + boxes[box_idx].width));
                cv::Mat output_mask_roi = output_roi_vec[n];
                mask_two_stage_orgin_roi = output_mask_roi | mask_two_stage_orgin_roi;
                // cv::imshow("output_mask_roi",output_mask_roi);
                // cv::waitKey(0);
                
            }
            input_img_roi_vec.resize(0);
            input_mask_roi_vec.resize(0);
        }
        
        cv::rectangle(img_show,boxes[i],cv::Scalar(128),5);  

        // if(cv::waitKey(0) == 'q')
        //   break;
    }
    cv::resize(img_show,img_show,input_mask.size()/4);
    cv::imshow("mask_one_stage",img_show);
    // cv::resize(mask_two_stage_orgin,img_show,cv::Size(mask_two_stage_orgin.cols/4,mask_two_stage_orgin.rows/4)); 
    // cv::imshow("mask_two_stage_orgin",img_show);

    cv::findContours(mask_two_stage_orgin, contours, hierarchy, cv::RETR_TREE,cv::CHAIN_APPROX_NONE);
     max_area = 0;
    for(auto& contour:contours)
    {
        float curr_area = cv::contourArea(contour);
        if(curr_area>max_area)
        {
            max_area = curr_area;
            max_contour = contour;
        }
    }
    contour_vector.clear();
    contour_vector.push_back(max_contour);
    cv::Mat mask_two_stage = cv::Mat::zeros(input_mask.size(),CV_8UC1);
    cv::drawContours(mask_two_stage,contour_vector,0,cv::Scalar(255),-1);
    cv::drawContours(input_img,contour_vector,0,cv::Scalar(100,0,200),5);
    return mask_two_stage;
}
int ClothSegmentDL::generateBoxesAlongContour(
      const std::vector<cv::Point2i> &contour, std::vector<cv::Rect2i> &boxes, 
      cv::Point& out_boxs_lt, cv::Point& out_boxs_br,
      const cv::Size &box_size, const int shift_size, const cv::Size &image_size) 
{
    // 沿着轮廓寻找合适的box，用于roi
 
    out_boxs_lt = cv::Point(10000000,10000000);
    out_boxs_br = cv::Point(0,0);
    // if (image_size == cv::Size(0, 0)) {
    //   error("Unexpected image size when generating boxes");
    //   return -1;
    // }
    int i = 0;
    int j = 1;
    int point_num = contour.size();
    int min_x_diff = 0;
    int min_y_diff = 0;
    int max_x_diff = 0;
    int max_y_diff = 0;
    boxes.resize(0);
    while (j < point_num) {
      cv::Point vec_ij = contour[j] - contour[i];
      min_x_diff = vec_ij.x < min_x_diff ? vec_ij.x : min_x_diff;
      min_y_diff = vec_ij.y < min_y_diff ? vec_ij.y : min_y_diff;
      max_x_diff = vec_ij.x > max_x_diff ? vec_ij.x : max_x_diff;
      max_y_diff = vec_ij.y > max_y_diff ? vec_ij.y : max_y_diff;
      if (std::abs(vec_ij.x) >= 0.9 * box_size.width ||
          std::abs(vec_ij.y) >= 0.9 * box_size.height) {
        // 如果i和j的欧氏距离超过阈值，就画一个框，
        // 其包络i和j之间的所有轮廓点。
        cv::Rect2d box;
        box.x = contour[i].x + min_x_diff;
        box.y = contour[i].y + min_y_diff;
        box.width = (max_x_diff - min_x_diff);
        box.height = (max_y_diff - min_y_diff);
        float offset_w = box_size.width- box.width;
        float offset_h = box_size.height- box.height;
        // 将框增大一圈，确保囊括目标。
        box.x -= offset_w / 2.0f + shift_size;
        box.y -= offset_h / 2.0f + shift_size;
        box.width += 2 * shift_size + offset_w;
        box.height += 2 * shift_size + offset_h;
        
        if(box.height>box.width)
        {
            box.x -= (box.height - box.width)/2.0;
            box.width = box.height;
        }
        else
        {
            box.y -= (box.width - box.height)/2.0;
            box.height = box.width;
        }
        if(box.x + box.width >= image_size.width)
          box.x -= (box.x + box.width - image_size.width) + 1; 
        if(box.y + box.height >= image_size.height)
          box.y -= (box.y + box.height - image_size.height) + 1; 
        // printf("%f %f\n",box.width,box.height);

        box.x = box.x < 0 ? 0 : box.x;
        box.y = box.y < 0 ? 0 : box.y;
        // box.width = box.x + box.width >= image_size.width ? image_size.width - box.x - 1: box.width;
        // box.height = box.y + box.height >= image_size.height? image_size.height - box.y - 1: box.height;
        //   printf("%d %d\n\n",box.x + box.width >= image_size.width,box.y + box.height >= image_size.height);
        
        if(out_boxs_lt.x > box.x)
          out_boxs_lt.x = box.x;
        if(out_boxs_lt.y > box.y)
          out_boxs_lt.y = box.y;
        if(out_boxs_br.x < box.x + box.width)
          out_boxs_br.x = box.x + box.width;
        if(out_boxs_br.y < box.y + box.height)
          out_boxs_br.y = box.y + box.height;
        boxes.push_back(box);
        // reset最大最小差值
        min_x_diff = min_y_diff = max_x_diff = max_y_diff = 0;
        i = j;
        j = i + 1;
      } else {
        j++;
      }
    }
    // 如果j - i大于1，说明还有一段轮廓没被框选。
    if (j - i > 1) {
        j--;
        cv::Rect2d box;
        box.x = contour[i].x + min_x_diff;
        box.y = contour[i].y + min_y_diff;
        box.width = max_x_diff - min_x_diff;
        box.height = max_y_diff - min_y_diff;
        float offset_w = box_size.width- box.width;
        float offset_h = box_size.height- box.height;
        // 将框增大一圈，确保囊括目标。
        box.x -= offset_w / 2.0f + shift_size;
        box.y -= offset_h / 2.0f + shift_size;
        box.width += 2 * shift_size + offset_w;
        box.height += 2 * shift_size + offset_h;
        
        if(box.height>box.width)
        {
            box.x -= (box.height - box.width)/2.0;
            box.width = box.height;
        }
        else
        {
            box.y -= (box.width - box.height)/2.0;
            box.height = box.width;
        }
        if(box.x + box.width >= image_size.width)
          box.x -= (box.x + box.width - image_size.width) + 1; 
        if(box.y + box.height >= image_size.height)
          box.y -= (box.y + box.height - image_size.height) + 1; 
      box.x = box.x < 0 ? 0 : box.x;
      box.y = box.y < 0 ? 0 : box.y;
    //   box.width = box.x + box.width >= image_size.width ? image_size.width - box.x -1: box.width;
    //   box.height = box.y + box.height >= image_size.height ? image_size.height - box.y -1 : box.height;
      if(out_boxs_lt.x > box.x)
        out_boxs_lt.x = box.x;
      if(out_boxs_lt.y > box.y)
        out_boxs_lt.y = box.y;
      if(out_boxs_br.x < box.x + box.width)
        out_boxs_br.x = box.x + box.width;
      if(out_boxs_br.y < box.y + box.height)
        out_boxs_br.y = box.y + box.height;
      boxes.push_back(box);
    }

    // 最后一个轮廓点到最开始轮廓点之间没有画框，需要补上
    j = contour.size() - 1;
    if (boxes.size() == 0)
        return 0;
    if (contour[j].x > boxes[0].x && 
        contour[j].x < boxes[0].x + boxes[0].width &&
        contour[j].y > boxes[0].y &&
        contour[j].y < boxes[0].y + boxes[0].height)
    {
        return 0;
    }
    if (contour[j].x > boxes[boxes.size()-1].x && 
        contour[j].x < boxes[boxes.size()-1].x + boxes[boxes.size()-1].width &&
        contour[j].y > boxes[boxes.size()-1].y &&
        contour[j].y < boxes[boxes.size()-1].y + boxes[boxes.size()-1].height)
    {
        return 0;
    }
    min_x_diff = min_y_diff = max_x_diff = max_y_diff = 0;
    cv::Point vec_ij = contour[j] - contour[0];
    min_x_diff = vec_ij.x < min_x_diff ? vec_ij.x : min_x_diff;
    min_y_diff = vec_ij.y < min_y_diff ? vec_ij.y : min_y_diff;
    max_x_diff = vec_ij.x > max_x_diff ? vec_ij.x : max_x_diff;
    max_y_diff = vec_ij.y > max_y_diff ? vec_ij.y : max_y_diff;
    if(abs(max_x_diff - min_x_diff) > 1.5 * box_size.width || abs(max_y_diff - min_y_diff) > 1.5 * box_size.height)
      return 0;
    cv::Rect2d box;
    box.x = contour[0].x + min_x_diff;
    box.y = contour[0].y + min_y_diff;
    box.width = max_x_diff - min_x_diff;
    box.height = max_y_diff - min_y_diff;
    float offset_w = box_size.width- box.width;
        float offset_h = box_size.height- box.height;
        // 将框增大一圈，确保囊括目标。
        box.x -= offset_w / 2.0f + shift_size;
        box.y -= offset_h / 2.0f + shift_size;
        box.width += 2 * shift_size + offset_w;
        box.height += 2 * shift_size + offset_h;
        
        if(box.height>box.width)
        {
            box.x -= (box.height - box.width)/2.0;
            box.width = box.height;
        }
        else
        {
            box.y -= (box.width - box.height)/2.0;
            box.height = box.width;
        }
        if(box.x + box.width >= image_size.width)
          box.x -= (box.x + box.width - image_size.width) + 1; 
        if(box.y + box.height >= image_size.height)
          box.y -= (box.y + box.height - image_size.height) + 1; 
    box.x = box.x < 0 ? 0 : box.x;
    box.y = box.y < 0 ? 0 : box.y;
    // box.width = box.x + box.width >= image_size.width ? image_size.width - box.x -1 : box.width;
    // box.height = box.y + box.height >= image_size.height ? image_size.height - box.y -1 : box.height;
    if(out_boxs_lt.x > box.x)
      out_boxs_lt.x = box.x;
    if(out_boxs_lt.y > box.y)
      out_boxs_lt.y = box.y;
    if(out_boxs_br.x < box.x + box.width)
      out_boxs_br.x = box.x + box.width;
    if(out_boxs_br.y < box.y + box.height)
      out_boxs_br.y = box.y + box.height;
    boxes.push_back(box);

    // debug("Time cost ms in generate boxes is " + std::to_string(time_cost_ms));
    return 0;
}
