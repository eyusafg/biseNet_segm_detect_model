
#include <chrono>
#include <cstdio>
#include <dirent.h>
#include <iostream>
#include <opencv2/core/types.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/opencv.hpp>
#include <openvino/openvino.hpp>
#include <random>
#include <string>
#include <vector>
// #include <inference_engine.hpp>
#include <sys/time.h>

namespace { // 一些固定好的值
constexpr int model_input_height = 384;
constexpr int model_input_width = 384;
constexpr int model_output_height = 384;
constexpr int model_output_width = 384;
} // namespace

class ClothDLSegment {
private:
  class ClothSegmInfer {
  private:
    std::shared_ptr<ov::Model> model_;
    ov::CompiledModel compiled_model_;
    ov::InferRequest infer_request_;
    cv::Mat getPredict(int64 *data);
    uint8_t *p_inp_;

  public:
    ClothSegmInfer(std::string model_pth, unsigned int channel = 3U);
    unsigned int channel_;
    cv::Mat infer();
    void setInputData(const cv::Mat input_img);
    // void setInputData(const cv::Mat input_img, const cv::Mat input_mask);
  };
  std::shared_ptr<ClothSegmInfer> cloth_segm_one_;
  std::shared_ptr<ClothSegmInfer> cloth_segm_two_;
  cv::Mat makeTwoStage(cv::Mat &input_img, cv::Mat input_mask,
                       cv::Mat orgin_mask);
  int generateBoxesAlongContour(const std::vector<cv::Point2i> &contour,
                                std::vector<cv::Rect2i> &boxes,
                                cv::Point &out_boxs_lt, cv::Point &out_boxs_br,
                                const cv::Size &box_size, const int shift_size,
                                const cv::Size &image_size);

public:
  ClothDLSegment(std::string model_path1);
  cv::Mat segment(cv::Mat input_img, cv::Mat orgin_mask);
};

ClothDLSegment::ClothDLSegment(std::string model_path1) {
  this->cloth_segm_one_ = std::make_shared<ClothSegmInfer>(model_path1);
  // this->cloth_segm_two_ = std::make_shared<ClothSegmInfer>(model_path2, 4U);
}
cv::Mat ClothDLSegment::segment(cv::Mat input_img, cv::Mat orgin_mask) {

  // one stage
  this->cloth_segm_one_->setInputData(input_img);
  cv::Mat mask_one_stage_orgin = this->cloth_segm_one_->infer();
  cv::resize(mask_one_stage_orgin, mask_one_stage_orgin, input_img.size());
  // cv::Mat img_show;
  // cv::resize(mask_one_stage_orgin,img_show,mask_one_stage_orgin.size()/4);
  // cv::imshow("mask_one_stage_orgin",img_show);
  // two stage
  return makeTwoStage(input_img, mask_one_stage_orgin, orgin_mask);
  ;
  // return mask_one_stage_orgin;
}

ClothDLSegment::ClothSegmInfer::ClothSegmInfer(std::string model_pth,
                                               unsigned int channel) {
  this->channel_ = channel;
  p_inp_ = (uint8_t *)malloc(sizeof(uint8_t) * model_input_height *
                             model_input_width * 4);

  std::string device(
      "CPU"); // GNA does not support argmax, my cpu does not has integrated gpu
  // model setup
  ov::Core core;
  this->model_ = core.read_model(model_pth);
  // model前处理配置
  ov::preprocess::PrePostProcessor ppp(model_);
  ov::preprocess::InputInfo &input_info = ppp.input();
  ov::element::Type input_data_type = ov::element::u8;
  input_info.tensor()
      .set_element_type(input_data_type)
      .set_shape({1, model_input_height, model_input_width, this->channel_})
      .set_layout("NHWC");
  // .set_color_format(ov::preprocess::ColorFormat::RGB);
  input_info.model().set_layout("NCHW");
  input_info.preprocess().convert_element_type(ov::element::f32);
  model_ = ppp.build();
  compiled_model_ = core.compile_model(model_, device);
  infer_request_ = compiled_model_.create_infer_request();
}
cv::Mat ClothDLSegment::ClothSegmInfer::infer() {

  infer_request_.infer();
  ov::Tensor output_tensor = infer_request_.get_output_tensor();
  int64 *data_ptr = (int64 *)(output_tensor.data(ov::element::i64));
  return getPredict(data_ptr);
  ;
}
void ClothDLSegment::ClothSegmInfer::setInputData(const cv::Mat input_img) {
  int iH = model_input_height;
  int iW = model_input_width;
  cv::Mat im = input_img.clone();
  int orgH{im.rows}, orgW{im.cols};
  if ((orgH != iH) || orgW != iW) {
    std::cout << "resize orignal image of (" << orgH << "," << orgW << ") to ("
              << iH << ", " << iW << ") according to model requirement\n";
    cv::resize(im, im, cv::Size(iW, iH), cv::INTER_CUBIC);
  }
  ov::Tensor input_tensor(
      ov::element::u8,
      ov::Shape{1, model_input_height, model_input_width, this->channel_},
      (void *)(im.data));
  infer_request_.set_input_tensor(input_tensor);
}

cv::Mat ClothDLSegment::ClothSegmInfer::getPredict(int64 *data) {

  // int oN = outsize[0];
  int oH = model_output_height;
  int oW = model_output_width;
  cv::Mat pred(cv::Size(oW, oH), CV_8UC1);
  int idx{0};
  for (int i{0}; i < oH; ++i) {
    uint8_t *ptr = pred.ptr<uint8_t>(i);
    for (int j{0}; j < oW; ++j) {
      *ptr = uint8_t(data[idx] == 0 ? 0 : 255);
      ptr++;
      ++idx;
    }
  }
  return pred;
}

class SytDataset {
private:
  /* data */
public:
  std::vector<std::string> image_list_;
  std::vector<std::string> label_list_;
  SytDataset(std::string img_path, std::string label_path) {
    std::vector<std::string> img_file_path(0);
    std::vector<std::string> label_file_path(0);

    struct dirent *ptr;
    DIR *dir;
    dir = opendir(img_path.c_str());
    std::cout << "文件列表: " << std::endl;
    while ((ptr = readdir(dir)) != NULL) {

      //跳过'.'和'..'两个目录
      if (ptr->d_name[0] == '.')
        continue;

      img_file_path.push_back(ptr->d_name);
    }
    sort(img_file_path.begin(), img_file_path.end());
    closedir(dir);
    dir = opendir(label_path.c_str());
    std::cout << "文件列表: " << std::endl;
    while ((ptr = readdir(dir)) != NULL) {

      //跳过'.'和'..'两个目录
      if (ptr->d_name[0] == '.')
        continue;

      label_file_path.push_back(ptr->d_name);
    }
    sort(label_file_path.begin(), label_file_path.end());

    int label_file_size = label_file_path.size();
    int img_file_size = img_file_path.size();
    int curr_img_idx_start = 0;
    int fail_count = 0;
    int img_idx = 0;
    bool found_flag;
    std::string img_prefix;
    std::string label_prefix;
    for (int label_idx = 0; label_idx < label_file_size; label_idx++) {
      // printf("prefix  %s  %d\n",label_file_path[label_idx].substr(0,
      // 4).c_str(), label_file_path[label_idx].substr(0, 4)=="mask");
      // // printf("prefix  %s\n",label_file_path[label_idx].substr(4,
      // label_file_path[label_idx].size()-1).c_str()); label_prefix =
      // label_file_path[label_idx].substr(0,
      // label_file_path[label_idx].rfind("."));
      // printf("%s\n",label_prefix.c_str());

      curr_img_idx_start = img_idx;
      found_flag = false;
      printf("load img list: %d/%d   fail:%d\n", label_idx, img_file_size - 1,
             fail_count);
      while (img_idx < img_file_size) {
        img_prefix =
            img_file_path[img_idx].substr(0, img_file_path[img_idx].rfind("."));
        label_prefix = label_file_path[label_idx].substr(
            0, label_file_path[label_idx].rfind("."));
        if ((img_prefix == label_prefix) ||
            (img_prefix.substr(0, 5) == "image" &&
             label_prefix.substr(0, 4) == "mask" &&
             img_prefix.substr(5, img_prefix.length() - 1) ==
                 label_prefix.substr(4, label_prefix.length() - 1))) {

          this->image_list_.push_back(img_file_path[img_idx]);
          this->label_list_.push_back(label_file_path[label_idx]);
          img_idx = img_idx + 1;
          found_flag = true;
          break;
        }
        img_idx = img_idx + 1;
      }
      if (found_flag)
        continue;
      img_idx = curr_img_idx_start;
      while (img_idx > 0) {
        img_prefix =
            img_file_path[img_idx].substr(0, img_file_path[img_idx].rfind("."));
        label_prefix = label_file_path[label_idx].substr(
            0, label_file_path[label_idx].rfind("."));
        if ((img_prefix == label_prefix) ||
            (img_prefix.substr(0, 5) == "image" &&
             label_prefix.substr(0, 4) == "mask" &&
             img_prefix.substr(5, img_prefix.length() - 1) ==
                 label_prefix.substr(4, label_prefix.length() - 1))) {

          this->image_list_.push_back(img_file_path[img_idx]);
          this->label_list_.push_back(label_file_path[label_idx]);
          img_idx = img_idx - 1;
          found_flag = true;
          break;
        }
        img_idx = img_idx - 1;
      }
      if (found_flag)
        continue;
      fail_count = fail_count + 1;
      printf("cant not find <%s> data in images dir\n",
             label_file_path[label_idx].c_str());
      img_idx = curr_img_idx_start;
    }
    img_file_path.resize(0);
    label_file_path.resize(0);
  }
  ~SytDataset() {
    std::vector<std::string>(0).swap(image_list_);
    std::vector<std::string>(0).swap(label_list_);
  }
};

struct timeval t_start;
float time_use = 0;
struct timeval t_end;

std::string PATH = "/home/syt/datasets/cloth_segment/ClothSegment/train/images";

// std::string PATH =
// "/home/syt/datasets/cloth_segment/auged_seg/aug_out/images/";
std::string LABEL_PATH =
    "/home/syt/datasets/cloth_segment/ClothSegment/train/labels/";

int image_idx = 0;
int main() {

  // std::string PATH = "/home/syt/datasets/20230713/";

  SytDataset syt_dataset(PATH, LABEL_PATH);

  // xzh
  ClothDLSegment cloth_segm(
      // "../model/model_cloth_segm_first_8_17_5.onnx",
      // "/home/syt/Documents/syt_bisenet/model_cloth_segm_first_8_22_97.onnx",
      // "../model/model_cloth_segm_first_9_8_128.onnx",
      "../model/model_cloth_segm_first_8_22_97.onnx");
  for (size_t i = 0; i < syt_dataset.image_list_.size(); i++) {
    image_idx = i;
    std::string file_path = PATH + "/" + syt_dataset.image_list_[i];

    // set input data
    std::cout << "set input data from: " << file_path << std::endl;
    // file_path = "/home/syt/datasets/20230713//2023-07-13_22_31_39_749.bmp";
    cv::Mat img = cv::imread(file_path);
    cv::Mat orgin_mask =
        cv::imread(LABEL_PATH + "/" + syt_dataset.label_list_[i]);
    // int img_w = img.size().width;
    // int img_h = img.size().height;
    // if (false)
    // {
    //     img = img(cv::Range(0, img_h), cv::Range(0, img_w / 2));
    // } else {
    /* img = img(cv::Range(0, img_h), cv::Range(img_w / 2, img_w)); */
    // }
    if (img.empty()) {
      std::cerr << "cv::imread failed: " << file_path << std::endl;
      std::abort();
    }
    cv::cvtColor(img, img, cv::COLOR_BGR2RGB);

    gettimeofday(&t_start, NULL);

    cv::Mat mask_two_stage = cloth_segm.segment(img, orgin_mask);

    gettimeofday(&t_end, NULL);
    time_use = (t_end.tv_sec - t_start.tv_sec) * 1000000 +
               (t_end.tv_usec - t_start.tv_usec);     //微秒
    printf("time_use is %.10f\n", time_use / 1000.0); // ms

    cv::Mat img_show;
    // cv::resize(mask_two_stage,img_show,mask_two_stage.size()/4);
    // cv::imshow("mask_two_stage",img_show);

    cv::cvtColor(img, img, cv::COLOR_RGB2BGR);
    // time_t timer;
    // time(&timer);
    // std::string img_file_name = std::to_string(timer) + ".jpg";
    // cv::imwrite("../save_img/"+img_file_name,img);
    // cv::imwrite("../save_img/" + syt_dataset.img_file_path[i],img);
    printf("%ld/%ld\n", i, syt_dataset.image_list_.size());
    // cv::resize(img,img_show,img.size()/4);
    // cv::imshow("img",img_show);

    // cv::waitKey(1);
  }
  return 0;
}
cv::Mat ClothDLSegment::makeTwoStage(cv::Mat &input_img, cv::Mat input_mask,
                                     cv::Mat orgin_mask) {

  std::vector<std::vector<cv::Point2i>> contours;
  std::vector<cv::Vec4i> hierarchy;
  std::vector<std::vector<cv::Point2i>> contours2;
  std::vector<cv::Vec4i> hierarchy2;
  /* printf("orgin mask channel %d\n",orgin_mask.channels()); */

  // cv::resize(orgin_mask, input_mask, cv::Size(384, 384), 0, 0,
  //            cv::INTER_NEAREST);
  // cv::cvtColor(input_mask, input_mask, cv::COLOR_RGB2GRAY);
  // cv::resize(input_mask, input_mask, orgin_mask.size(), 0, 0,
  //            cv::INTER_NEAREST);

  cv::findContours(input_mask, contours, hierarchy, cv::RETR_TREE,
                   cv::CHAIN_APPROX_NONE);

  cv::cvtColor(orgin_mask, orgin_mask, cv::COLOR_RGB2GRAY);

  cv::findContours(orgin_mask, contours2, hierarchy2, cv::RETR_TREE,
                   cv::CHAIN_APPROX_NONE);

  if (contours.size() == 0)
    return cv::Mat::zeros(input_mask.size(), CV_8UC1);
  ;
  float max_area = 0;
  std::vector<cv::Point> max_contour;
  for (auto &contour : contours) {
    float curr_area = cv::contourArea(contour);
    if (curr_area > max_area) {
      max_area = curr_area;
      max_contour = contour;
    }
  }
  std::vector<std::vector<cv::Point>> contour_vector;
  contour_vector.push_back(max_contour);
  cv::Mat mask_one_stage = cv::Mat::zeros(input_mask.size(), CV_8UC1);
  cv::drawContours(mask_one_stage, contour_vector, 0, cv::Scalar(255), -1);
  std::vector<cv::Rect2i> boxes(0);
  cv::Point boxs_lt, boxs_br;
  cv::Size box_size = cv::Size(352, 352);
  int shift_size = 16;
  // generateBoxesAlongContour(max_contour, boxes, boxs_lt, boxs_br, box_size,
  // shift_size, input_mask.size());
  generateBoxesAlongContour(contours2[0], boxes, boxs_lt, boxs_br, box_size,
                            shift_size, input_mask.size());
  cv::Mat mask_two_stage_orgin = cv::Mat::zeros(input_img.size(), CV_8UC1);
  cv::Mat img_show = mask_one_stage.clone();
  // std::vector<cv::Mat> input_img_roi_vec;
  // std::vector<cv::Mat> input_mask_roi_vec;

  cv::cvtColor(input_img, input_img, cv::COLOR_RGB2BGR);
  printf("box size %ld\n", boxes.size());
  for (size_t i = 0; i < boxes.size(); i++) {
    // boxes[i].x -= boxs_lt.x;
    // boxes[i].y -= boxs_lt.y;
    cv::Mat roi_1 =
        input_img(cv::Range(boxes[i].y, boxes[i].y + boxes[i].height),
                  cv::Range(boxes[i].x, boxes[i].x + boxes[i].width));
    cv::Mat roi_2 =
        input_mask(cv::Range(boxes[i].y, boxes[i].y + boxes[i].height),
                   cv::Range(boxes[i].x, boxes[i].x + boxes[i].width));
    cv::Mat roi_3 =
        orgin_mask(cv::Range(boxes[i].y, boxes[i].y + boxes[i].height),
                   cv::Range(boxes[i].x, boxes[i].x + boxes[i].width));
    /*
    cv::imwrite("/home/syt/datasets/cloth_segment/一阶段生成/train/images/infer_"
    + std::to_string(image_idx) + "_2_" + std::to_string(i) +
                    ".jpg",
                roi_1);
    cv::imwrite("/home/syt/datasets/cloth_segment/一阶段生成/train/masks/infer_"
    + std::to_string(image_idx) + "_2_" + std::to_string(i) +
                    ".png",
                roi_2);
    cv::imwrite("/home/syt/datasets/cloth_segment/一阶段生成/train/labels/infer_"
    + std::to_string(image_idx) + "_2_" + std::to_string(i) +
                    ".png",
                roi_3);
    */
    cv::imshow("roi_1", roi_1);
    cv::imshow("roi_2", roi_2);
    cv::imshow("roi_3", roi_3);
    cv::waitKey(0);

    // this->cloth_segm_two_->setInputData(roi_1,roi_2);
    // cv::Mat mask_two_stage_orgin_roi =
    // mask_two_stage_orgin(cv::Range(boxes[i].y, boxes[i].y + boxes[i].height),
    // cv::Range(boxes[i].x, boxes[i].x + boxes[i].width)); cv::Mat
    // output_mask_roi = this->cloth_segm_two_->infer();
    // mask_two_stage_orgin_roi = output_mask_roi | mask_two_stage_orgin_roi;
    // cv::rectangle(img_show,boxes[i],cv::Scalar(128),5);
    // cv::imshow("output_mask_roi",output_mask_roi);
    /* if(cv::waitKey(0) == 'q') */
    /* break; */
  }
  /* cv::resize(img_show,img_show,input_mask.size()/4); */
  /* cv::imshow("mask_one_stage",img_show); */
  // //
  // cv::resize(mask_two_stage_orgin,img_show,cv::Size(mask_two_stage_orgin.cols/4,mask_two_stage_orgin.rows/4));
  // // cv::imshow("mask_two_stage_orgin",img_show);
  /* cv::waitKey(0); */
  // cv::findContours(mask_two_stage_orgin, contours, hierarchy,
  // cv::RETR_TREE,cv::CHAIN_APPROX_NONE); if(contours.size()==0)
  //     return cv::Mat::zeros(input_mask.size(),CV_8UC1);;
  //  max_area = 0;
  // for(auto& contour:contours)
  // {
  //     float curr_area = cv::contourArea(contour);
  //     if(curr_area>max_area)
  //     {
  //         max_area = curr_area;
  //         max_contour = contour;
  //     }
  // }
  // contour_vector.clear();
  // contour_vector.push_back(max_contour);
  cv::Mat mask_two_stage = cv::Mat::zeros(input_mask.size(), CV_8UC1);

  // cv::drawContours(mask_two_stage,contour_vector,0,cv::Scalar(255),-1);
  // cv::drawContours(input_img,contour_vector,0,cv::Scalar(100,0,200),1);
  return mask_two_stage;
}
int ClothDLSegment::generateBoxesAlongContour(
    const std::vector<cv::Point2i> &contour, std::vector<cv::Rect2i> &boxes,
    cv::Point &out_boxs_lt, cv::Point &out_boxs_br, const cv::Size &box_size,
    const int shift_size, const cv::Size &image_size) {
  // 沿着轮廓寻找合适的box，用于roi
  out_boxs_lt = cv::Point(10000000, 10000000);
  out_boxs_br = cv::Point(0, 0);
  // if (image_size == cv::Size(0, 0)) {
  //   error("Unexpected image size when generating boxes");
  //   return -1;
  // }
  // cv::Mat img_show = cv::Mat::zeros(image_size,CV_8UC1);
  int i = 0;
  int j = 1;
  int point_num = contour.size();
  int min_x_diff = 0;
  int min_y_diff = 0;
  int max_x_diff = 0;
  int max_y_diff = 0;
  boxes.resize(0);
  cv::Point lt, rb;
  lt = rb = contour[0];
  while (j < point_num) {
    if (lt.x > contour[j].x)
      lt.x = contour[j].x;
    if (lt.y > contour[j].y)
      lt.y = contour[j].y;
    if (rb.x < contour[j].x)
      rb.x = contour[j].x;
    if (rb.y < contour[j].y)
      rb.y = contour[j].y;
    // cv::Point vec_ij = contour[j] - contour[i];
    cv::Point vec_ij = rb - lt;
    min_x_diff = vec_ij.x < min_x_diff ? vec_ij.x : min_x_diff;
    min_y_diff = vec_ij.y < min_y_diff ? vec_ij.y : min_y_diff;
    max_x_diff = vec_ij.x > max_x_diff ? vec_ij.x : max_x_diff;
    max_y_diff = vec_ij.y > max_y_diff ? vec_ij.y : max_y_diff;

    if (std::abs(vec_ij.x) >= 0.1 * box_size.width ||
        std::abs(vec_ij.y) >= 0.1 * box_size.height) { // 0.1 1.0
      // 如果i和j的欧氏距离超过阈值，就画一个框，
      // 其包络i和j之间的所有轮廓点。
      cv::Rect2d box;
      box.x = lt.x + min_x_diff;
      box.y = lt.y + min_y_diff;
      box.width = (max_x_diff - min_x_diff);
      box.height = (max_y_diff - min_y_diff);
      float offset_w = box_size.width - box.width;
      float offset_h = box_size.height - box.height;
      // 将框增大一圈，确保囊括目标。
      box.x -= offset_w / 2.0f + shift_size;
      box.y -= offset_h / 2.0f + shift_size;
      box.width += 2 * shift_size + offset_w;
      box.height += 2 * shift_size + offset_h;

      if (box.height > box.width) {
        box.x -= (box.height - box.width) / 2.0;
        box.width = box.height;
      } else {
        box.y -= (box.width - box.height) / 2.0;
        box.height = box.width;
      }
      if (box.x + box.width >= image_size.width)
        box.x -= (box.x + box.width - image_size.width) + 1;
      if (box.y + box.height >= image_size.height)
        box.y -= (box.y + box.height - image_size.height) + 1;
      // printf("%f %f\n",box.width,box.height);

      box.x = box.x < 0 ? 0 : box.x;
      box.y = box.y < 0 ? 0 : box.y;
      // box.width = box.x + box.width >= image_size.width ? image_size.width -
      // box.x - 1: box.width; box.height = box.y + box.height >=
      // image_size.height? image_size.height - box.y - 1: box.height;
      // printf("%d %d\n\n",box.x + box.width >= image_size.width,box.y +
      // box.height >= image_size.height);

      if (out_boxs_lt.x > box.x)
        out_boxs_lt.x = box.x;
      if (out_boxs_lt.y > box.y)
        out_boxs_lt.y = box.y;
      if (out_boxs_br.x < box.x + box.width)
        out_boxs_br.x = box.x + box.width;
      if (out_boxs_br.y < box.y + box.height)
        out_boxs_br.y = box.y + box.height;
      boxes.push_back(box);
      // reset最大最小差值
      min_x_diff = min_y_diff = max_x_diff = max_y_diff = 0;
      i = j;
      j = i + 1;
      lt = rb = contour[i];
      // cv::circle(img_show,contour[i],20,cv::Scalar(255),-1);
      // cv::rectangle(img_show,boxes[boxes.size()-1],cv::Scalar(128),5);
      // cv::Mat temp;
      // cv::resize(img_show,temp,img_show.size()/4);
      // cv::imshow("img_show",temp);
      // cv::waitKey(0);
    } else {
      j++;
      // cv::circle(img_show,contour[j],10,cv::Scalar(180),-1);
    }
  }

  // 如果j - i大于1，说明还有一段轮廓没被框选。
  if (j - i > 1) {
    j--;
    cv::Rect2d box;
    box.x = lt.x + min_x_diff;
    box.y = lt.y + min_y_diff;
    box.width = max_x_diff - min_x_diff;
    box.height = max_y_diff - min_y_diff;
    float offset_w = box_size.width - box.width;
    float offset_h = box_size.height - box.height;
    // 将框增大一圈，确保囊括目标。
    box.x -= offset_w / 2.0f + shift_size;
    box.y -= offset_h / 2.0f + shift_size;
    box.width += 2 * shift_size + offset_w;
    box.height += 2 * shift_size + offset_h;

    if (box.height > box.width) {
      box.x -= (box.height - box.width) / 2.0;
      box.width = box.height;
    } else {
      box.y -= (box.width - box.height) / 2.0;
      box.height = box.width;
    }
    if (box.x + box.width >= image_size.width)
      box.x -= (box.x + box.width - image_size.width) + 1;
    if (box.y + box.height >= image_size.height)
      box.y -= (box.y + box.height - image_size.height) + 1;
    box.x = box.x < 0 ? 0 : box.x;
    box.y = box.y < 0 ? 0 : box.y;
    //   box.width = box.x + box.width >= image_size.width ? image_size.width -
    //   box.x -1: box.width; box.height = box.y + box.height >=
    //   image_size.height ? image_size.height - box.y -1 : box.height;
    if (out_boxs_lt.x > box.x)
      out_boxs_lt.x = box.x;
    if (out_boxs_lt.y > box.y)
      out_boxs_lt.y = box.y;
    if (out_boxs_br.x < box.x + box.width)
      out_boxs_br.x = box.x + box.width;
    if (out_boxs_br.y < box.y + box.height)
      out_boxs_br.y = box.y + box.height;
    boxes.push_back(box);
  }

  // 最后一个轮廓点到最开始轮廓点之间没有画框，需要补上
  j = contour.size() - 1;
  if (boxes.size() == 0)
    return 0;
  if (contour[i].x > boxes[0].x && contour[i].x < boxes[0].x + boxes[0].width &&
      contour[i].y > boxes[0].y &&
      contour[i].y < boxes[0].y + boxes[0].height) {
    return 0;
  }
  if (contour[j].x > boxes[boxes.size() - 1].x &&
      contour[j].x <
          boxes[boxes.size() - 1].x + boxes[boxes.size() - 1].width &&
      contour[j].y > boxes[boxes.size() - 1].y &&
      contour[j].y <
          boxes[boxes.size() - 1].y + boxes[boxes.size() - 1].height) {
    return 0;
  }
  min_x_diff = min_y_diff = max_x_diff = max_y_diff = 0;
  cv::Point vec_ij = contour[j] - contour[0];
  min_x_diff = vec_ij.x < min_x_diff ? vec_ij.x : min_x_diff;
  min_y_diff = vec_ij.y < min_y_diff ? vec_ij.y : min_y_diff;
  max_x_diff = vec_ij.x > max_x_diff ? vec_ij.x : max_x_diff;
  max_y_diff = vec_ij.y > max_y_diff ? vec_ij.y : max_y_diff;
  if (abs(max_x_diff - min_x_diff) > 1.5 * box_size.width ||
      abs(max_y_diff - min_y_diff) > 1.5 * box_size.height)
    return 0;
  cv::Rect2d box;
  box.x = lt.x + min_x_diff;
  box.y = lt.y + min_y_diff;
  box.width = max_x_diff - min_x_diff;
  box.height = max_y_diff - min_y_diff;
  float offset_w = box_size.width - box.width;
  float offset_h = box_size.height - box.height;
  // 将框增大一圈，确保囊括目标。
  box.x -= offset_w / 2.0f + shift_size;
  box.y -= offset_h / 2.0f + shift_size;
  box.width += 2 * shift_size + offset_w;
  box.height += 2 * shift_size + offset_h;

  if (box.height > box.width) {
    box.x -= (box.height - box.width) / 2.0;
    box.width = box.height;
  } else {
    box.y -= (box.width - box.height) / 2.0;
    box.height = box.width;
  }
  if (box.x + box.width >= image_size.width)
    box.x -= (box.x + box.width - image_size.width) + 1;
  if (box.y + box.height >= image_size.height)
    box.y -= (box.y + box.height - image_size.height) + 1;
  box.x = box.x < 0 ? 0 : box.x;
  box.y = box.y < 0 ? 0 : box.y;
  // box.width = box.x + box.width >= image_size.width ? image_size.width -
  // box.x -1 : box.width; box.height = box.y + box.height >= image_size.height
  // ? image_size.height - box.y -1 : box.height;
  if (out_boxs_lt.x > box.x)
    out_boxs_lt.x = box.x;
  if (out_boxs_lt.y > box.y)
    out_boxs_lt.y = box.y;
  if (out_boxs_br.x < box.x + box.width)
    out_boxs_br.x = box.x + box.width;
  if (out_boxs_br.y < box.y + box.height)
    out_boxs_br.y = box.y + box.height;
  boxes.push_back(box);

  // debug("Time cost ms in generate boxes is " + std::to_string(time_cost_ms));
  return 0;
}
