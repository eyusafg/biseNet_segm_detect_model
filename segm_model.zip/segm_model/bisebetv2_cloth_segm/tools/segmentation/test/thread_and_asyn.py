import cv2
import threading
import numpy as np
import time
import asyncio
import aiohttp
import sys
sys.path.insert(0, '')
sys.path.insert(0, '../../../')
sys.path.append('bisebetv2_cloth_segm')
import argparse
import math
import torch
import torch.nn.functional as F
import numpy as np
import cv2
import os
import lib.segmentation.data.transform_cv2 as T
from models.segmentation import model_factory
from configs.segmentation import set_cfg_from_file
import logging
import keyboard
import datetime


torch.set_grad_enabled(False)

parse = argparse.ArgumentParser() 
parse.add_argument('--config', dest='config', type=str, default='bisebetv2_cloth_segm\\configs\\segmentation\\bisenetv2_syt_segm_edge_black_widow_0703.py',) 
# parse.add_argument('--weight-path', type=str, default='bisebetv2_cloth_segm\\output\widow\\segmentation\\res\\2024-07-02_17-37-08\\model_19.pth',)  
parse.add_argument('--weight-path', type=str, default='bisebetv2_cloth_segm\\output\\widow\\segmentation\\res\\2024-07-03_19-58-34\\model_104.pth',)  
args = parse.parse_args()
cfg = set_cfg_from_file(args.config)
 
palette = np.random.randint(0, 256, (256, 3), dtype=np.uint8)
cfg_dict = dict(cfg.__dict__)
in_channel = cfg_dict['in_ch']

net = model_factory[cfg.model_type](cfg.n_cats,in_ch=in_channel, aux_mode='eval', net_config=cfg.net_config)
check_point = torch.load(args.weight_path, map_location='cpu')
if 'model_state_dict' in check_point:
    net.load_state_dict(check_point['model_state_dict'], strict=False)
else:
    net.load_state_dict(check_point, strict=False)
net.eval()

to_tensor = T.ToTensor(mean=(0.5, 0.5, 0.5), std=(0.5, 0.5, 0.5),)

target_size = cfg_dict['target_size']


def dummy_segmentation_model(frame, model):
    h, w = frame.shape[:2]
    image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    im = cv2.resize(image, target_size, interpolation=cv2.INTER_LINEAR)
    im = np.ascontiguousarray(im)
    im = to_tensor(dict(im=im, lb=None))['im'].unsqueeze(0)

    out = model(im)
    out = out[0].argmax(dim=1).cpu().numpy()

    out = np.where(out == 1, 0, out).astype(np.uint8)
    out = out.squeeze(0)
    out = np.where(out > 0, 255, out).astype(np.uint8)

    return frame

def read_camera(camera_id, cap, queue, stop_event):
    # cap = cv2.VideoCapture(camera_id)
    while not stop_event.is_set():
        ret, frame = cap.read()
        if ret:
            queue[camera_id+1] = frame
        else:
            print(f"Failed to read from camera {camera_id}")
    cap.release()

async def process_and_display(camera_queues, stop_event, model):
    while not stop_event.is_set():
        if 1 in camera_queues and 2 in camera_queues:

            image1 = camera_queues[1]
            image2 = camera_queues[2]
            
            result1 = dummy_segmentation_model(image1, model)
            result2 = dummy_segmentation_model(image2, model)
            
            cv2.imshow('Camera 0 - Processed', result1)
            cv2.imshow('Camera 1 - Processed', result2)
            
            if cv2.waitKey(1) & 0xFF == ord('q'):
                stop_event.set()
                break
        # await asyncio.sleep(0.01)  # 短暂休眠以避免高CPU占用

# 主函数
def main():
    camera_queues = {}
    stop_event = threading.Event()
    cap1 = cv2.VideoCapture(1)
    cap2 = cv2.VideoCapture(2)
    if cap1.isOpened() and cap2.isOpened():
        cap1.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*'MJPG'))
        cap2.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*'MJPG'))
        cap1.set(cv2.CAP_PROP_FRAME_WIDTH, 800)
        cap1.set(cv2.CAP_PROP_FRAME_HEIGHT, 600)
        cap2.set(cv2.CAP_PROP_FRAME_WIDTH, 800)
        cap2.set(cv2.CAP_PROP_FRAME_HEIGHT, 600)
        cap1.set(cv2.CAP_PROP_FPS, 30)
        cap2.set(cv2.CAP_PROP_FPS, 30)
        ret1, frameq = cap1.read()
        ret2, framea = cap2.read()
        print('camera init success')

    camera_threads = []
    for camera_id,cap in enumerate([cap1, cap2]):
        thread = threading.Thread(target=read_camera, args=(camera_id, cap, camera_queues, stop_event))
        thread.start()
        camera_threads.append(thread)
    
    # 启动异步事件循环处理推理和显示
    loop = asyncio.get_event_loop()
    try:
        loop.run_until_complete(process_and_display(camera_queues, stop_event, net))
    finally:
        stop_event.set()
        for thread in camera_threads:
            thread.join()
        cv2.destroyAllWindows()

if __name__ == '__main__':
    main()
