import sys
sys.path.insert(0, '')
sys.path.insert(0, '../../../')
sys.path.append('bisebetv2_cloth_segm')
import numpy as np
import cv2
import time
import onnxruntime as rt
from queue import Queue
from copy import deepcopy
import shutil
from lib.segmentation.data.generate_boxes_along_contour import get_max_contour, generate_boxes_along_contour


        


def process_image(image):
    image_copy = image.copy()
    image_copy = cv2.resize(image_copy, (640, 480))
    image_copy = cv2.cvtColor(image_copy, cv2.COLOR_BGR2RGB)
    mean = np.array([0.5,0.5,0.5])
    std = np.array([0.5,0.5,0.5])
    image_copy = (image_copy - mean[None, None, :]) / std[None, None, :]
    image_copy = np.transpose(image_copy, (2, 0, 1))
    image_copy = np.expand_dims(image_copy, axis=0).astype(np.float32)

    return image_copy

def init_onnx_model(model_path):
    rt_infer = rt.InferenceSession(model_path)
    input_name = rt_infer.get_inputs()[0].name
    outputs = rt_infer.get_outputs()
    outputs_names = list(map(lambda output: output.name, outputs))
    return rt_infer, input_name, outputs_names


if __name__ == '__main__':
    import os

    onnx_model1_path = r'auto_feed_model\first_model_1023_ch3.onnx'
    onnx_model2_path = r'auto_feed_model\second_model_1023_ch4.onnx'
    is_second_infer = True

    rt_infer1, input_name1, outputs_names1 = init_onnx_model(onnx_model1_path)
    if is_second_infer:
        rt_infer2, input_name2, outputs_names2 = init_onnx_model(onnx_model2_path)

    im_dir =  r'1107_pressure_img'
    for im in os.listdir(im_dir):
        img = cv2.imread(os.path.join(im_dir, im))
        im_cp = img.copy()

        img = cv2.resize(img, (384, 384))
        # image_copy = np.transpose(img, (2, 0, 1))
        img = np.ascontiguousarray(img[:, :, ::-1].transpose(2, 0, 1))
        img = np.expand_dims(img, axis=0).astype(np.float32)
        # img = process_image(cv2.imread('hulk_images/0_.jpg'))

        time_start = time.time()
        infer_img = rt_infer1.run(outputs_names1, {input_name1: img})[0]
        first_mask = np.array(infer_img[0,:,:]).astype(np.uint8) 
        first_mask = np.where(first_mask > 0, 255, 0).astype(np.uint8)
        first_mask = cv2.resize(first_mask, (im_cp.shape[1], im_cp.shape[0]))
        first_mask_contours, _  = cv2.findContours(first_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
        first_max_contour = max(first_mask_contours, key=cv2.contourArea)
        first_max_contour = first_max_contour.reshape(-1, 2)


        # # 在第二个推理部分修改为：
        # if is_second_infer:
        #     batch_inputs = []
        #     box_coords = []
            
        #     # 收集所有ROI数据
        #     for box in boxes:
        #         # ...原有处理逻辑...
        #         # 替换最后一步的堆叠方式：
        #         second_img = np.concatenate([roi_image, roi_mask[..., None]], axis=2)
        #         batch_inputs.append(second_img.transpose(2, 0, 1))
        #         box_coords.append((y, y_br, x, x_br))
            
        #     # 批量推理
        #     if batch_inputs:
        #         batch_data = np.stack(batch_inputs).astype(np.float32)
        #         batch_preds = rt_infer2.run(outputs_names2, {input_name2: batch_data})[0]
                
        #         # 处理批量结果
        #         for pred, (y, y_br, x, x_br) in zip(batch_preds, box_coords):
        #             roi_pred = cv2.resize(pred[0], (roi_shape[1], roi_shape[0]))
        #             mask_second[y:y_br, x:x_br] += roi_pred


        if is_second_infer:
            boxes = generate_boxes_along_contour(first_max_contour, image_size=(im_cp.shape[1], im_cp.shape[0]),
                                        box_size=(352, 352), shift_size=16.0, box_step=1)
            mask_second = np.zeros([im_cp.shape[0], im_cp.shape[1]], np.uint8)
            for box in boxes:
                x, y = int(box['x']), int(box['y'])
                x_br = int(x + box['width'])
                y_br = int(y + box['height'])
                roi_image = im_cp[y:y_br, x:x_br]
                roi_shape = roi_image.shape
                print('roi_shape', roi_shape)
                roi_mask = first_mask[y:y_br, x:x_br]

                roi_image = cv2.resize(roi_image, (384, 384))
                roi_mask = cv2.resize(roi_mask, (384, 384))
                roi_mask = np.where(roi_mask > 0, 255, 0).astype(np.uint8)

                # roi_image = np.ascontiguousarray(roi_image[:, :, ::-1])
                if not len(roi_mask.shape) == 3:
                    second_img = np.dstack((roi_image, np.expand_dims(roi_mask, axis=-1)))
                else:
                    second_img = np.dstack((roi_image, roi_mask))

                second_img = np.expand_dims(second_img.transpose(2, 0, 1), axis=0).astype(np.float32)
                roi_pred = rt_infer2.run(outputs_names2, {input_name2: second_img})[0]
                roi_pred = np.array(roi_pred[0,:,:]).astype(np.uint8) 

                roi_pred = np.where(roi_pred > 0, 255, 0).astype(np.uint8)
                roi_pred = cv2.resize(roi_pred, (roi_shape[1], roi_shape[0]))
                mask_second[y:y_br, x:x_br] += roi_pred
            print('+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++')
            print('init model cost time {} s'.format(time.time() - time_start))
            print('+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++')
            mask_second = np.where(mask_second > 0, 255, 0).astype(np.uint8)
            cv2.namedWindow('mask_second', cv2.WINDOW_NORMAL)
            cv2.imshow('mask_second', mask_second)
        cv2.imwrite(f'{im}_mask.png', mask_second)
        cv2.namedWindow('first_mask', cv2.WINDOW_NORMAL)
        cv2.imshow('first_mask', first_mask)
        cv2.imshow('im_cp', im_cp)
        cv2.waitKey(0)

