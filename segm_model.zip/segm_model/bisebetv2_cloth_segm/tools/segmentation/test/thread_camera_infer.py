import cv2
import numpy as np
import os
import threading
import time
import queue
import copy
import sys
sys.path.insert(0, '')
sys.path.insert(0, '../../../')
sys.path.append('bisebetv2_cloth_segm')
import argparse
import math
import torch
import torch.nn.functional as F
import numpy as np
import cv2
import os
import lib.segmentation.data.transform_cv2 as T
from models.segmentation import model_factory
from configs.segmentation import set_cfg_from_file
import logging
import keyboard
import datetime
from monitor_frame import CameraMonitor 
from threading import Event



"""
在使用多线程时， 虽然是同时运行的，但是因为cpu占用，系统， 或者硬件调用的各种问题
会影响到两个线程的运行速度，执行时间不一致， 一个线程快， 一个线程慢， 
因此可能会捕捉到不同帧的图像 

或者尝试 使用单线程， 两个摄像头的响应可能会存在延迟，但是时间应该基本相似（一帧的时间？？？） batch_size=2的推理？？？"""


parse = argparse.ArgumentParser() 
parse.add_argument('--config', dest='config', type=str, default='bisebetv2_cloth_segm\\configs\\segmentation\\bisenetv2_syt_segm_edge_black_widow_0703.py',) 
# parse.add_argument('--weight-path', type=str, default='bisebetv2_cloth_segm\\output\widow\\segmentation\\res\\2024-07-02_17-37-08\\model_19.pth',)  
parse.add_argument('--weight-path', type=str, default='bisebetv2_cloth_segm\\output\\widow\\segmentation\\res\\2024-07-03_19-58-34\\model_104.pth',)  
args = parse.parse_args()
cfg = set_cfg_from_file(args.config)
palette = np.random.randint(0, 256, (256, 3), dtype=np.uint8)
cfg_dict = dict(cfg.__dict__)
in_channel = cfg_dict['in_ch']
net = model_factory[cfg.model_type](cfg.n_cats,in_ch=in_channel, aux_mode='eval', net_config=cfg.net_config)
check_point = torch.load(args.weight_path, map_location='cpu')
if 'model_state_dict' in check_point:
    net.load_state_dict(check_point['model_state_dict'], strict=False)
else:
    net.load_state_dict(check_point, strict=False)
net.eval()
to_tensor = T.ToTensor(mean=(0.5, 0.5, 0.5), std=(0.5, 0.5, 0.5),)
target_size = cfg_dict['target_size']


lock = threading.Lock()
event = threading.Event()
stop_event = threading.Event()
forbidden_combinations = [{1, 3}, {2, 3}, {1, 2, 3}]

def thread_capture_frames(capture, save_path, frame_queue):
    global lock, event, stop_event, forbidden_combinations
    while not stop_event.is_set():
        try:
            # with lock:
            if not event.is_set():
                event.wait()
                print(capture.get(cv2.CAP_PROP_FPS))
            ret, frame = capture.read()
            if ret:
            
                # curre_time = datetime.datetime.now().strftime('%Y%m%d%H%M%S%f')[:-1]
                # cv2.imwrite(os.path.join(save_path, f'{curre_time}.png'), frame)

                # ori_img = copy.deepcopy(frame)
                # h, w = frame.shape[:2]
                # image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                # im = cv2.resize(image, target_size, interpolation=cv2.INTER_LINEAR)
                # im = np.ascontiguousarray(im)
                # im = to_tensor(dict(im=im, lb=None))['im'].unsqueeze(0)
                # with torch.no_grad():
                #     out = net(im)
                # out = out[0].argmax(dim=1).cpu().numpy()

                # out = np.where(out == 1, 0, out).astype(np.uint8)
                # out = out.squeeze(0)
                # out = np.where(out > 0, 255, out).astype(np.uint8)

                # unique_list = np.unique(out)
                # for forbidden_combination in forbidden_combinations:
                #     if forbidden_combination.issubset(set(unique_list)):
                #         logging.error('Error: segment result Error')
                frame_queue.put((frame))
                # cv2.imshow(name, frame)
                # if len(unique_list) > 2:
                #     out = np.where(out == 1, 0, out).astype(np.uint8)
                #     out = cv2.resize(out, (w, h), interpolation=cv2.INTER_NEAREST)
                #     heights = np.sum(out != 0, axis=0)
                #     for height in heights:
                #         print(height)

                # frame_queue.put((frame, out))
            # cv2.waitKey(1)
          
        except Exception as e:
            logging.error(f"Exception occurred in capture_frames_safe: {str(e)}")
            capture.release()  
            cv2.destroyAllWindows()
            break  



# def main():
#     counter = 0
#     cap1 = cv2.VideoCapture(1)
#     cap2 = cv2.VideoCapture(2)


#     frame_queue1 = queue.Queue()
#     frame_queue2 = queue.Queue()
#     save_path = 'D:\\data_colloection\\images\\images5_20240701'
#     if cap1.isOpened() and cap2.isOpened():
#         cap1.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*'MJPG'))
#         cap2.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*'MJPG'))
#         cap1.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
#         cap1.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
#         cap2.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
#         cap2.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
#         cap1.set(cv2.CAP_PROP_FPS, 30)
#         cap2.set(cv2.CAP_PROP_FPS, 30)
#         print(cap1.get(cv2.CAP_PROP_FPS))
#         print(cap2.get(cv2.CAP_PROP_FPS))
#         ret1, frameq = cap1.read()
#         ret2, framea = cap2.read()
#         print('camera init success')
#         thread1 = threading.Thread(target=thread_capture_frames, args=(cap1, save_path,frame_queue1))
#         thread2 = threading.Thread(target=thread_capture_frames, args=(cap2, save_path,frame_queue2))

#         thread1.start()
#         thread2.start()

#         try:
#             while True:
#                 if keyboard.is_pressed('q'):  
#                     stop_event.set()  
#                     event.set()  
#                     print("Stop event set")
#                     break
#                 elif keyboard.is_pressed('s'):  # 按s开始
#                     event.set()
#                     print("Start event set")
#                 elif keyboard.is_pressed('p'):  # 按p暂停
#                     event.clear()  
#                     print("Pause event cleared") 

#                 if not frame_queue1.empty() and not frame_queue2.empty():
#                     # frame1, out1 = frame_queue1.get()
#                     # frame2, out2 = frame_queue2.get()
#                     frame1 = frame_queue1.get()
#                     frame2 = frame_queue2.get()    
#                     counter += 1     

#                     current_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
#                     cv2.putText(frame1, f'Frame {counter}', (10, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
#                     cv2.putText(frame1, f'time {current_time}', (10, 80), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)  
#                     cv2.putText(frame2, f'Frame {counter}', (10, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
#                     cv2.putText(frame2, f'time {current_time}', (10, 80), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)               
#                     h,w,c = frame1.shape

#                     frame2 = cv2.resize(frame2, (w, h))
#                     # out1 = cv2.resize(out1, (w, h))
#                     # out2 = cv2.resize(out2, (w, h))
#                     # out1 = cv2.cvtColor(out1, cv2.COLOR_GRAY2BGR)
#                     # out2 = cv2.cvtColor(out2, cv2.COLOR_GRAY2BGR)
#                     # dst1 = cv2.addWeighted(frame1, 0.8, out1, 0.5, 0)
#                     # dst2 = cv2.addWeighted(frame2, 0.8, out2, 0.5, 0)
#                     cv2.imshow('dst1 Image', frame1)
#                     cv2.imshow('dst2 Image', frame2)
#                 cv2.waitKey(1)
#         finally:
#             stop_event.set()
#             event.set()  
#             thread1.join()
#             thread2.join()

#     cap1.release()
#     cap2.release()
#     cv2.destroyAllWindows()

# if __name__ == "__main__":
#     main()

def main():
    counter = 0
    expected_fps = 30
    resolution = (640, 480)
    frame_queue1 = queue.Queue()
    frame_queue2 = queue.Queue()
    cam1 = CameraMonitor(1, expected_fps, resolution, frame_queue1, use_thread=True)
    cam2 = CameraMonitor(2, expected_fps, resolution, frame_queue2, use_thread=True)

    stop_event = Event()
    event = Event()

    cam1.start(stop_event, event)
    cam2.start(stop_event, event)

    try:
        while True:
            if keyboard.is_pressed('q'):  
                stop_event.set()  
                event.set()  
                print("Stop event set")
                break
            elif keyboard.is_pressed('s'):  # 按s开始
                event.set()
                print("Start event set")
            elif keyboard.is_pressed('p'):  # 按p暂停
                event.clear()
                # cam1.stop()
                # cam2.stop()  
                print("Pause event cleared")

            if not frame_queue1.empty() and not frame_queue2.empty():
                # frame1, out1 = frame_queue1.get()
                # frame2, out2 = frame_queue2.get()
                frame1 = frame_queue1.get()
                frame2 = frame_queue2.get()    
                counter += 1     

                current_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                cv2.putText(frame1, f'Frame {counter}', (10, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
                cv2.putText(frame1, f'time {current_time}', (10, 80), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)  
                cv2.putText(frame2, f'Frame {counter}', (10, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
                cv2.putText(frame2, f'time {current_time}', (10, 80), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)               
                h,w,c = frame1.shape

                frame2 = cv2.resize(frame2, (w, h))
                # out1 = cv2.resize(out1, (w, h))
                # out2 = cv2.resize(out2, (w, h))
                # out1 = cv2.cvtColor(out1, cv2.COLOR_GRAY2BGR)
                # out2 = cv2.cvtColor(out2, cv2.COLOR_GRAY2BGR)
                # dst1 = cv2.addWeighted(frame1, 0.8, out1, 0.5, 0)
                # dst2 = cv2.addWeighted(frame2, 0.8, out2, 0.5, 0)
                cv2.imshow('dst1 Image', frame1)
                cv2.imshow('dst2 Image', frame2)
            cv2.waitKey(1)

    except KeyboardInterrupt:
        stop_event.set()
        event.set()
        cam1.stop()
        cam2.stop()
        print("监测结束")

    # finally:
    #     stop_event.set()
    #     event.set()  
    #     cam1.stop()
    #     cam2.stop()
    #     print("监测结束")

    cv2.destroyAllWindows()
if __name__ == "__main__":
    main()