import cv2
import time
import psutil
import logging
from threading import Thread, Lock, Event
from collections import deque
import queue
import keyboard
import datetime
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import tkinter as tk
from tkinter import ttk

logging.basicConfig(level=logging.INFO, handlers=[
logging.FileHandler('frame_drop.log', 'w', 'utf-8'),
logging.FileHandler('cpu_usage.log', 'w', 'utf-8')
])

frame_drop_logger = logging.getLogger('FrameDropLogger')
cpu_usage_logger = logging.getLogger('CPUUsageLogger')


class CameraMonitor:
    def __init__(self, camera_id, expected_fps, resolution=(640, 480), frame_queue=None, use_thread=None):
        self.camera_id = camera_id
        self.expected_fps = expected_fps
        self.frame_interval = 1 / expected_fps
        self.cap = cv2.VideoCapture(camera_id)
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, resolution[0])
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, resolution[1])
        self.cap.set(cv2.CAP_PROP_FPS, expected_fps)
        self.cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc('M', 'J', 'P', 'G'))
        self.time_queue = deque(maxlen=expected_fps)
        self.lock = Lock()
        self.running = False
        self.thread = None
        # self.thread_id = None
        self.frame_count = 0
        self.frame_queue = frame_queue
        self.use_thread = use_thread

        self.cpu_usage = []
        self.memory_percent = []
        self.fps_list = []
        self.cpu_temperature = []

    def monitor(self):
        r,f = self.cap.read()
        print('init camera success')
        while self.running:
            start_time = time.time()
            ret, frame = self.cap.read()

            self.frame_count += 1
            if not ret:
                print(f"无法读取摄像头{self.camera_id}的帧")
                continue
            
            if self.frame_queue is not None:
                self.frame_queue.put(frame)

            current_time = time.time()
            with self.lock:
                self.time_queue.append(current_time)
            if len(self.time_queue) == self.expected_fps:
                actual_fps = self.expected_fps / (self.time_queue[-1] - self.time_queue[0])
                self.fps_list.append(actual_fps)
                if actual_fps < self.expected_fps:  
                    frame_drop_logger.info(f"摄像头{self.camera_id}掉帧! 第{self.frame_count}帧, 当前帧率: {actual_fps:.2f}")

            cpu_usage = psutil.cpu_percent(interval=None)
            memory_percent = psutil.virtual_memory().percent
            self.cpu_usage.append(cpu_usage)
            self.memory_percent.append(memory_percent)

            cpu_usage_logger.info(f"摄像头{self.camera_id}  第{self.frame_count}帧  内存使用率: {memory_percent}%")
            cpu_usage_logger.info(f"摄像头{self.camera_id}  第{self.frame_count}帧  线程 CPU 使用率: {cpu_usage}%")
            try:
                temperatures = psutil.sensors_temperatures()
                if 'coretemp' in temperatures:
                    cpu_temp = temperatures['coretemp'][0].current
                    self.cpu_temperature.append(cpu_temp)
                    cpu_usage_logger.info(f"摄像头 {self.camera_id}  第 {self.frame_count} 帧  CPU 温度: {cpu_temp}°C")
            except AttributeError:
                pass  

    def no_thread(self):
        r,f = self.cap.read()
        self.running = True
        print(111)
        print('init camera success')
        while self.running:
            print(222)
            start_time = time.time()
            ret, frame = self.cap.read()

            self.frame_count += 1
            if not ret:
                print(f"无法读取摄像头{self.camera_id}的帧")
                continue
            
            if self.frame_queue is not None:
                self.frame_queue.put(frame)

            current_time = time.time()
            self.time_queue.append(current_time)
            if len(self.time_queue) == self.expected_fps:
                actual_fps = self.expected_fps / (self.time_queue[-1] - self.time_queue[0])
                if actual_fps < self.expected_fps:  
                    frame_drop_logger.info(f"摄像头{self.camera_id}掉帧! 第{self.frame_count}帧, 当前帧率: {actual_fps:.2f}")

    def start(self):
        if self.use_thread:
            self.thread = Thread(target=self.monitor)
            self.thread.start()
        else:
            self.no_thread()

    def stop(self):
        self.running = False
        self.thread.join()
        self.cap.release()

def update_plot(i, cam1, cam2, ax1, ax2, ax3):
    if len(cam1.fps_list) > 0:
        ax1.clear()
        ax1.plot(cam1.fps_list, label='Camera 1 FPS')
        ax1.plot(cam2.fps_list, label='Camera 2 FPS')
        ax1.set_ylim(0, cam1.expected_fps * 1.5)
        ax1.legend(loc='upper right')

    if len(cam1.cpu_usage) > 0:
        ax2.clear()
        ax2.plot(cam1.cpu_usage, label='Camera 1 CPU Usage')
        ax2.plot(cam2.cpu_usage, label='Camera 2 CPU Usage')
        ax2.set_ylim(0, 100)
        ax2.legend(loc='upper right')

    if len(cam1.memory_percent) > 0:
        ax3.clear()
        ax3.plot(cam1.memory_percent, label='Camera 1 Memory Usage')
        ax3.plot(cam2.memory_percent, label='Camera 2 Memory Usage')
        ax3.set_ylim(0, 100)
        ax3.legend(loc='upper right')

def main():
    expected_fps = 30
    resolution = (640, 480)
    frame_queue1 = queue.Queue()
    frame_queue2 = queue.Queue()
    use_thread = True
    cam1 = CameraMonitor(1, expected_fps, resolution, frame_queue1, use_thread=True)
    cam2 = CameraMonitor(2, expected_fps, resolution, frame_queue2, use_thread=True)

    counter = 0

    print(' 开始监测')
    if use_thread:
        try:
            while True:
                if keyboard.is_pressed('q'):
                    print("检测到按键 'q'，结束监测。")
                    fig.savefig('monitoring_plot.png')
                    cam1.stop()
                    cam2.stop()
                    break
                elif keyboard.is_pressed('s'):
                    print("检测到按键 's'，开始监测。")
                    cam1.running = True
                    cam1.start()
                    cam2.running = True
                    cam2.start()
                    root = tk.Tk()
                    root.title("监测结果")
                    fig, (ax1, ax2, ax3) = plt.subplots(3, 1, figsize=(10, 8))
                    canvas = FigureCanvasTkAgg(fig, master=root)
                    canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=1)
                    ani = animation.FuncAnimation(fig, update_plot, fargs=(cam1, cam2, ax1, ax2, ax3), interval=1000, cache_frame_data=False)
                    root.mainloop()
                elif keyboard.is_pressed('p'):
                    print("检测到按键 'p'，暂停监测。")
                    cam1.running = False
                    cam2.running = False

                # if not frame_queue1.empty() and not frame_queue2.empty():
                #     frame1 = frame_queue1.get()
                #     frame2 = frame_queue2.get()    
                #     counter += 1     

                #     current_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                #     cv2.putText(frame1, f'Frame {counter}', (10, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
                #     cv2.putText(frame1, f'time {current_time}', (10, 80), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)  
                #     cv2.putText(frame2, f'Frame {counter}', (10, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
                #     cv2.putText(frame2, f'time {current_time}', (10, 80), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)               
                #     h,w,c = frame1.shape

                #     frame2 = cv2.resize(frame2, (w, h))
                #     cv2.imshow('Camera 1 Image', frame1)
                #     cv2.imshow('Camera 2 Image', frame2)
                # cv2.waitKey(1)

        except KeyboardInterrupt: 
            cam1.stop()
            cam2.stop()
            print("监测结束")
        cv2.destroyAllWindows()
        fig.savefig('monitoring_plot.png')
        # plt.show()

    else:
        cam1 = CameraMonitor(1, expected_fps, resolution, frame_queue1, use_thread)
        cam1.start()

if __name__ == "__main__":
    main()
