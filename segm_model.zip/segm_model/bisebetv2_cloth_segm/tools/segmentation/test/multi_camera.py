import cv2
import numpy as np
import multiprocessing
import time
import copy
import sys
sys.path.insert(0, '')
sys.path.insert(0, '../../../')
sys.path.append('bisebetv2_cloth_segm')
import argparse
import math
import torch
import torch.nn.functional as F
import numpy as np
import cv2
import os
import lib.segmentation.data.transform_cv2 as T
from models.segmentation import model_factory
from configs.segmentation import set_cfg_from_file
import logging
import keyboard
import datetime

torch.set_grad_enabled(False)

parse = argparse.ArgumentParser() 
parse.add_argument('--config', dest='config', type=str, default='bisebetv2_cloth_segm\\configs\\segmentation\\bisenetv2_syt_segm_edge_black_widow_0703.py',) 
# parse.add_argument('--weight-path', type=str, default='bisebetv2_cloth_segm\\output\widow\\segmentation\\res\\2024-07-02_17-37-08\\model_19.pth',)  
parse.add_argument('--weight-path', type=str, default='bisebetv2_cloth_segm\\output\\widow\\segmentation\\res\\2024-07-03_19-58-34\\model_104.pth',)  
args = parse.parse_args()
cfg = set_cfg_from_file(args.config)
 
palette = np.random.randint(0, 256, (256, 3), dtype=np.uint8)
cfg_dict = dict(cfg.__dict__)
in_channel = cfg_dict['in_ch']

net = model_factory[cfg.model_type](cfg.n_cats,in_ch=in_channel, aux_mode='eval', net_config=cfg.net_config)
check_point = torch.load(args.weight_path, map_location='cpu')
if 'model_state_dict' in check_point:
    net.load_state_dict(check_point['model_state_dict'], strict=False)
else:
    net.load_state_dict(check_point, strict=False)
net.eval()

to_tensor = T.ToTensor(mean=(0.5, 0.5, 0.5), std=(0.5, 0.5, 0.5),)

target_size = cfg_dict['target_size']


def process_frame(frame, model):
    # ori_img = copy.deepcopy(frame)
    h, w = frame.shape[:2]
    image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    im = cv2.resize(image, target_size, interpolation=cv2.INTER_LINEAR)
    im = np.ascontiguousarray(im)
    im = to_tensor(dict(im=im, lb=None))['im'].unsqueeze(0)

    out = model(im)
    out = out[0].argmax(dim=1).cpu().numpy()

    out = np.where(out == 1, 0, out).astype(np.uint8)
    out = out.squeeze(0)
    out = np.where(out > 0, 255, out).astype(np.uint8)

    return frame

def camera_process(camera_index, frame_queue, stop_event, width, height):
    cap = cv2.VideoCapture(camera_index)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
    cap.set(cv2.CAP_PROP_FPS, 30)
    
    while not stop_event.is_set():
        ret, frame = cap.read()
        if not ret:
            break
        frame_queue.put(frame)
        
    cap.release()

def display_process(frame_queue, stop_event, model, name):
    cv2.namedWindow(name, cv2.WINDOW_NORMAL)
    cv2.resizeWindow(name, 800, 600)
    
    while not stop_event.is_set():
        if not frame_queue.empty():
            frame = frame_queue.get()
            segmented_image = process_frame(frame, model)
            cv2.imshow(name, segmented_image)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            stop_event.set()
            break

def main():

    camera1_index = 1
    camera2_index = 2
    width, height = 800, 600  # 设置分辨率
    queue_size = 10  # 队列大小

    frame_queue1 = multiprocessing.Queue(queue_size)
    frame_queue2 = multiprocessing.Queue(queue_size)
    stop_event = multiprocessing.Event()

    camera_process1 = multiprocessing.Process(target=camera_process, args=(camera1_index, frame_queue1, stop_event, width, height))
    camera_process2 = multiprocessing.Process(target=camera_process, args=(camera2_index, frame_queue2, stop_event, width, height))
    display_process_1 = multiprocessing.Process(target=display_process, args=(frame_queue1, stop_event, net, 'frame1'))
    display_process_2 = multiprocessing.Process(target=display_process, args=(frame_queue2, stop_event, net, 'frame2'))

    camera_process1.start()
    camera_process2.start()
    display_process_1.start()
    display_process_2.start()

    camera_process1.join()
    camera_process2.join()
    stop_event.set()
    display_process_1.join()
    display_process_2.join()

    cv2.destroyAllWindows()

if __name__ == '__main__':
    main()
