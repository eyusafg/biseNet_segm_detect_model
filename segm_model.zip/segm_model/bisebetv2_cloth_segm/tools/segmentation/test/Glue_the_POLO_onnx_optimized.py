import sys
sys.path.insert(0, '')
import numpy as np
import cv2
import time
import onnxruntime as rt
import os
from corner_detector_rect import find_fabric_corners_rect
from calculate_angle import analyze_angle
from serial_test import find_serial_port, build_frame, send_frame
import serial
from pixel_to_real import PixelToWorldConverter


'''
onnx 使用图优化
1.图优化 (15-25% 提升)
    算子融合：将卷积+BN+ReLU合并
    常量折叠：预计算静态值
    冗余消除：移除不必要操作
2.内存优化 (10-15% 提升)
    内存池管理，减少分配开销
    更好的缓存局部性
3.CPU并行优化 (20-30% 提升)
    多线程并行执行
    SIMD向量化指令 (AVX, SSE)
    算子级并行
4. 尝试cuda

'''

def init_model(model_path):
    """
    初始化ONNX模型，启用性能优化
    """
    # 设置执行提供者，优先使用GPU
    providers = ['CUDAExecutionProvider', 'CPUExecutionProvider']
    
    # 设置会话选项以优化性能
    sess_options = rt.SessionOptions()
    sess_options.graph_optimization_level = rt.GraphOptimizationLevel.ORT_ENABLE_ALL
    sess_options.enable_mem_pattern = True
    sess_options.enable_cpu_mem_arena = True
    
    rt_infer = rt.InferenceSession(model_path, sess_options=sess_options, providers=providers)
    input_name = rt_infer.get_inputs()[0].name
    outputs = rt_infer.get_outputs()
    outputs_names = list(map(lambda output: output.name, outputs))
    return rt_infer, input_name, outputs_names


def init_model(model_path):
    """
    初始化ONNX模型，启用性能优化
    """
    # 设置执行提供者，优先使用GPU
    providers = ['CUDAExecutionProvider', 'CPUExecutionProvider']
    
    # 设置会话选项以优化性能
    sess_options = rt.SessionOptions()
    sess_options.graph_optimization_level = rt.GraphOptimizationLevel.ORT_ENABLE_ALL
    sess_options.enable_mem_pattern = True
    sess_options.enable_cpu_mem_arena = True
    
    rt_infer = rt.InferenceSession(model_path, sess_options=sess_options, providers=providers)
    input_name = rt_infer.get_inputs()[0].name
    outputs = rt_infer.get_outputs()
    outputs_names = list(map(lambda output: output.name, outputs))
    return rt_infer, input_name, outputs_names


def init_model_basic(model_path):
    """
    基础ONNX模型初始化（无优化）
    """
    rt_infer = rt.InferenceSession(model_path)
    input_name = rt_infer.get_inputs()[0].name
    outputs = rt_infer.get_outputs()
    outputs_names = list(map(lambda output: output.name, outputs))
    return rt_infer, input_name, outputs_names


def benchmark_inference_speed(model_path, test_iterations=50):
    """
    对比优化前后的推理速度
    """
    print("=" * 60)
    print("ONNX推理性能对比测试")
    print("=" * 60)
    
    # 创建测试输入
    test_input = np.random.rand(1, 3, 384, 384).astype(np.float32)
    
    # 测试基础版本
    print("测试基础版本（无优化）...")
    rt_basic, input_name_basic, _ = init_model_basic(model_path)
    
    times_basic = []
    for i in range(test_iterations):
        start_time = time.time()
        _ = rt_basic.run(['preds'], {input_name_basic: test_input})
        times_basic.append(time.time() - start_time)
    
    avg_time_basic = np.mean(times_basic[5:])  # 跳过前5次预热
    
    # 测试优化版本
    print("测试优化版本...")
    rt_optimized, input_name_opt, _ = init_model(model_path)
    
    times_optimized = []
    for i in range(test_iterations):
        start_time = time.time()
        _ = rt_optimized.run(['preds'], {input_name_opt: test_input})
        times_optimized.append(time.time() - start_time)
    
    avg_time_optimized = np.mean(times_optimized[5:])  # 跳过前5次预热
    
    # 计算性能提升
    speedup = avg_time_basic / avg_time_optimized
    improvement = (1 - avg_time_optimized / avg_time_basic) * 100
    
    print(f"\n性能测试结果:")
    print(f"基础版本平均推理时间: {avg_time_basic*1000:.2f}ms")
    print(f"优化版本平均推理时间: {avg_time_optimized*1000:.2f}ms")
    print(f"性能提升: {improvement:.1f}% (加速比: {speedup:.2f}x)")
    print(f"基础版本FPS: {1/avg_time_basic:.1f}")
    print(f"优化版本FPS: {1/avg_time_optimized:.1f}")
    
    # 检测使用的执行提供者
    providers = rt_optimized.get_providers()
    print(f"当前使用的执行提供者: {providers[0]}")
    
    return rt_optimized, input_name_opt, _



if __name__ == '__main__':

    # onnx 优化对比
    model_path = 'Glue_the_hem_segm_20250909_model_19.onnx'
    benchmark_inference_speed(model_path)
    
    # ==================== 性能优化配置 ====================
    ENABLE_DISPLAY = True      # 设为False可提升性能（生产环境建议关闭）
    ENABLE_DEBUG_PRINT = True  # 设为False可减少打印开销
    ENABLE_TIMING = True       # 是否显示性能计时信息
    
    # ==================== 初始化参数 ====================
    # 加载单应性矩阵和相机参数
    H_path = r'camera_parames_DH\_20250915164723435_homography.npy'
    camera_matrix_path = r"camera_parames_DH\glue_DH_camera_matrix.npz"
    dist_coeffs_path = r"camera_parames_DH\glue_DH_dist_coeffs.npz"

    H = np.load(H_path)
    converter = PixelToWorldConverter(H)

    camera_matrix = np.load(camera_matrix_path)['camera_matrix']
    dist_coeffs = np.load(dist_coeffs_path)['dist_coeffs']

    # 初始化优化后的ONNX模型
    model_path = 'Glue_the_hem_segm_20250909_model_19.onnx'
    rt_infer, input_name, outputs_names = init_model(model_path)

    # 串口初始化
    ports = find_serial_port()
    ser = None
    if ports:
        port = ports[0].device
        ser = serial.Serial(port, baudrate=115200, bytesize=serial.EIGHTBITS, 
                           parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE, timeout=0.01)

    # ==================== 相机初始化 ====================
    cap = cv2.VideoCapture(1, cv2.CAP_DSHOW)
    cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*'MJPG'))
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1920)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 1080)
    # 设置缓冲区大小为1，减少延迟
    cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
    
    # ==================== 预分配内存缓冲区 ====================
    input_buffer = np.zeros((1, 3, 384, 384), dtype=np.float32)
    crop_buffer = np.zeros((600, 600, 3), dtype=np.uint8)
    resize_buffer = np.zeros((384, 384, 3), dtype=np.uint8)
    
    # ==================== 预计算常量 ====================
    IMG_SIZE = 384
    CROP_SIZE = 600
    SCALE_FACTOR = CROP_SIZE / IMG_SIZE * 0.07552  # 合并的比例因子
    VIRTUAL_LINE_OFFSET = 188
    SEGMENT_WIDTH_RATIO = 0.25  # 1/4
    SEGMENT_INDEX = 2
    BOUNDARY_THRESHOLD = 10
    
    ret, im = cap.read()
    if not ret:
        print("无法读取相机数据")
        exit(1)
    
    # ==================== 主处理循环 ====================
    frame_count = 0
    total_time = 0
    
    while ret:
        if ENABLE_TIMING:
            time_start = time.time()

        ret, im = cap.read()
        if not ret:
            break
            
        frame_count += 1
        
        # ==================== 图像预处理优化 ====================
        if ENABLE_DEBUG_PRINT:
            print(f'Frame {frame_count}, im.shape: {im.shape}')
        
        # 使用预分配的缓冲区进行图像处理
        crop_buffer[:] = im[400:1000, 400:1000]
        cv2.resize(crop_buffer, (IMG_SIZE, IMG_SIZE), dst=resize_buffer)
        im_cp = resize_buffer.copy() if ENABLE_DISPLAY else None
        
        # 直接在预分配的缓冲区中进行转换
        input_buffer[0] = resize_buffer[:, :, ::-1].transpose(2, 0, 1).astype(np.float32)
    
        # ==================== ONNX推理 ====================
        infer_img = rt_infer.run(['preds'], {input_name: input_buffer})[0]
        infer_img = np.array(infer_img[0, :, :]).astype(np.uint8) 

        pred1 = (infer_img == 1).astype(np.uint8) * 255
        
        # ==================== 角点检测 ====================
        corners, segment_points, contour_points, rect_box, rect_bottom_left, rect_bottom_right = find_fabric_corners_rect(pred1)
        
        if corners is None or len(corners) != 2:
            # 发送无效数据信号
            # if ser:
            #     invalid_frame = build_frame(x=0.0, y=0.0, angle=0.0, is_valid=False)
            #     send_frame(ser, invalid_frame)
            continue 

        # ==================== 优化后的角点分析 ====================
        # 预计算图像参数
        img_height, img_width = pred1.shape[:2]
        virtual_horizontal_line_y = img_height - VIRTUAL_LINE_OFFSET
        segment_width = img_width * SEGMENT_WIDTH_RATIO
        x_start = SEGMENT_INDEX * segment_width
        x_end = (SEGMENT_INDEX + 1) * segment_width + 20
        
        bottom_left_point, bottom_right_point = corners[0], corners[1]

        # 简化的条件判断逻辑
        right_x = bottom_right_point[0]
        x_invalid = False
        y_invalid = False
        distance_to_horizontal = 0
        angle_deg = 0
        mid_point = None
        avg_y = 0
        start_point = np.array([0, 0])
        end_point = np.array([0, 0])

        if right_x >= img_width - BOUNDARY_THRESHOLD:
            # 右角点到达图像右边界
            verticla_line_distance = 0
        elif x_start <= right_x <= x_end:
            # 右角点在两条虚拟线中间 - 需要计算角度和y距离
            x_invalid = True
            y_invalid = True
            verticla_line_distance = right_x - x_end
            
            result = analyze_angle(virtual_horizontal_line_y, segment_points, x_start, x_end)
            if result[0] is not None:  # filtered_points不为None
                filtered_points, angle_deg, distance_to_horizontal, mid_point, avg_y, start_point, end_point = result
            else:
                continue
        else:
            # 右角点在虚拟线外侧
            verticla_line_distance = right_x - x_end
            x_invalid = True

        # ==================== 坐标转换优化 ====================
        # 合并计算，减少重复乘法
        distance_to_horizontal = round(distance_to_horizontal * SCALE_FACTOR, 2)
        verticla_line_distance = round(verticla_line_distance * SCALE_FACTOR, 2)
    
        if ENABLE_DEBUG_PRINT:
            print(f'Y距离: {distance_to_horizontal}mm, X距离: {verticla_line_distance}mm, 角度: {angle_deg:.2f}°')

        # ==================== 串口通信 ====================
        if ser:
            valid_frame = build_frame(
                x=verticla_line_distance,
                y=distance_to_horizontal,
                angle=angle_deg,
                x_invalid=x_invalid,
                y_invalid=y_invalid
            )
            send_frame(ser, valid_frame)

        # ==================== 性能计时 ====================
        if ENABLE_TIMING:
            frame_time = time.time() - time_start
            total_time += frame_time
            avg_fps = frame_count / total_time if total_time > 0 else 0
            print(f'帧处理时间: {frame_time:.3f}s, 平均FPS: {avg_fps:.1f}')

        # ==================== 可选显示 ====================
        if ENABLE_DISPLAY:
            # 只在需要显示时才创建BGR图像
            pred_bgr = cv2.cvtColor(pred1, cv2.COLOR_GRAY2BGR)
            x_mid = int((x_start + x_end) / 2)

            # 绘制检测结果
            cv2.circle(pred_bgr, bottom_left_point, 8, (255, 0, 255), -1)  
            cv2.circle(pred_bgr, bottom_right_point, 8, (255, 0, 255), -1)  
            cv2.line(pred_bgr, tuple(np.array(bottom_right_point).astype(int)), 
                    (int(x_end), int(bottom_right_point[1])), (0, 144, 144), 3)
            
            # 绘制虚拟线
            cv2.line(pred_bgr, (int(x_start), 0), (int(x_start), img_height), (0, 255, 0), 2)
            cv2.line(pred_bgr, (int(x_end), 0), (int(x_end), img_height), (0, 255, 0), 2)
            cv2.line(pred_bgr, (0, int(virtual_horizontal_line_y)), 
                    (img_width, int(virtual_horizontal_line_y)), (0, 255, 0), 2)
            
            # 绘制轮廓点
            if segment_points is not None:
                for p in segment_points:
                    cv2.circle(pred_bgr, (int(p[0]), int(p[1])), 2, (0, 0, 255), -1)
            
            # 绘制角度线段和中点
            if mid_point is not None:
                cv2.circle(pred_bgr, (int(mid_point[0]), int(mid_point[1])), 5, (255, 0, 0), -1)
                cv2.line(pred_bgr, (x_mid, int(avg_y)), (x_mid, virtual_horizontal_line_y), (0, 255, 255), 2)
                cv2.line(pred_bgr, tuple(start_point.astype(int)), tuple(end_point.astype(int)), (255, 255, 0), 2)
            
            # 显示文本信息
            cv2.putText(pred_bgr, f"Angle: {angle_deg:.2f}°", (10, 30), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)
            cv2.putText(pred_bgr, f"Y: {distance_to_horizontal:.2f}mm", (10, 60), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)
            cv2.putText(pred_bgr, f"X: {verticla_line_distance:.2f}mm", (10, 90), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)
            cv2.putText(pred_bgr, f"FPS: {avg_fps:.1f}", (10, 120), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 0), 2)

            # 显示图像
            cv2.imshow('Detection Result', pred_bgr)
            cv2.imshow('Binary Mask', pred1)
            if im_cp is not None:
                cv2.imshow('Original', im_cp)
            
            # 按ESC键退出
            key = cv2.waitKey(1) & 0xFF
            if key == 27:  # ESC键
                break
    
    # ==================== 清理资源 ====================
    print(f"\n处理完成:")
    print(f"总帧数: {frame_count}")
    print(f"总时间: {total_time:.2f}s")
    print(f"平均FPS: {frame_count/total_time:.1f}" if total_time > 0 else "N/A")
    
    cap.release()
    cv2.destroyAllWindows()
    if ser:
        ser.close()
