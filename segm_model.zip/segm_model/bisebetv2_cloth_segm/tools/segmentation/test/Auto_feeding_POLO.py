import sys
sys.path.insert(0, '')
import numpy as np
import cv2
import time
import onnxruntime as rt
import os
from corner_detector_rect import find_fabric_corners_rect
from calculate_angle import analyze_angle
from serial_test import find_serial_port, build_frame, send_frame
import serial
from pixel_to_real import PixelToWorldConverter
import copy
from DHCaptureRag.new_camera import UsbCaptureSystem



'''
标定自动上料区域
识别布料边缘，获取角点
与压板抓手原点计算距离， 发送给下位机
'''

def get_max_contour(contours):
    max_idx = -1
    max_area = 0
    for i in range(len(contours)):
        area = cv2.contourArea(contours[i])
        if area > max_area:
            max_area = area
            max_idx = i
    return contours[max_idx]
def generate_boxes_along_contour(contour: np.array,image_size = (2748, 3672), box_size = (384, 384), shift_size=16, box_step=1.0):
    contour = np.array(contour)

    boxes = []
    i = 0
    j = 1
    point_num = len(contour)
    min_x_diff = 0
    min_y_diff = 0
    max_x_diff = 0
    max_y_diff = 0
    lt = copy.deepcopy(contour[0])
    rb = copy.deepcopy(contour[0])
    while j < point_num:
        if lt[0] > contour[j][0]:
            lt[0] = contour[j][0]
        if lt[1] > contour[j][1]:
            lt[1] = contour[j][1]
        if rb[0] < contour[j][0]:
            rb[0] = contour[j][0]
        if rb[1] < contour[j][1]:
            rb[1] = contour[j][1]
        vec_ij = rb - lt
        min_x_diff = vec_ij[0] if vec_ij[0] < min_x_diff else min_x_diff
        min_y_diff = vec_ij[1] if vec_ij[1] < min_y_diff else min_y_diff
        max_x_diff = vec_ij[0] if vec_ij[0] > max_x_diff else max_x_diff
        max_y_diff = vec_ij[1] if vec_ij[1] > max_y_diff else max_y_diff
        if (abs(vec_ij[0]) >= box_step * box_size[0]) or (abs(vec_ij[1]) >= box_step * box_size[1]):

            # 如果i和j的欧氏距离超过阈值，就画一个框，包络i到j之间所有的轮廓点
            box = {}
            box['x'] = lt[0] + min_x_diff
            box['y'] = lt[1] + min_y_diff
            box['width'] = max_x_diff - min_x_diff
            box['height'] = max_y_diff - min_y_diff

            offset_w = box_size[0] - box['width']
            offset_h = box_size[1] - box['height']
            # 确保box的大小符合box size
            # shift 将框增大一圈，确保囊括目标
            box['x'] -= offset_w / 2.0 + shift_size
            box['y'] -= offset_h / 2.0 + shift_size
            box['width'] += 2.0 * shift_size + offset_w
            box['height'] += 2.0 * shift_size + offset_h

            # 使其成为正方形
            max_length = max([box['width'], box['height']])
            if max_length % 32 != 0:
                max_length = np.ceil(max_length / 32) * 32

            x_center = box['x'] + box['width'] // 2
            y_center = box['y'] + box['height'] // 2

            box['x'] = x_center - max_length // 2
            box['y'] = y_center - max_length // 2
            box['width'] = max_length
            box['height'] = max_length

            # 将框增大一圈，确保囊括目标
            # box['x'] -= shift_size
            # box['y'] -= shift_size
            # box['width'] += 2 * shift_size
            # box['height'] += 2 * shift_size

            # 当边框位于图像边缘，且不满足box size，则往内偏移。
            if box['x'] + box_size[0] >= image_size[0]:
                box['x'] -= (box['x'] + box_size[0] - image_size[0]) + 1
            if box['y'] + box_size[1] >= image_size[1]:
                box['y'] -= (box['y'] + box_size[1] - image_size[1]) + 1


            box['x'] = 0 if box['x'] < 0 else box['x']
            box['y'] = 0 if box['y'] < 0 else box['y']


            # box['width'] = image_size[0] - box['x'] if box['x'] + box['width'] > image_size[0] else box['width']
            # box['height'] = image_size[1] - box['y'] if box['y'] + box['height'] > image_size[1] else box['height']

            boxes.append(box)

            min_x_diff = min_y_diff = max_x_diff = max_y_diff = 0
            i = j
            j = i + 1
            # lt = rb = contour[i]
            lt = copy.deepcopy(contour[i])
            rb = copy.deepcopy(contour[i])
        else:
            j += 1

        # 如果j - i 大于1， 说明还有一段轮廓没被框选
    if (j - i) > 1:
        j -= 1
        box = {}
        box['x'] = lt[0] + min_x_diff
        box['y'] = lt[1] + min_y_diff
        box['width'] = max_x_diff - min_x_diff
        box['height'] = max_y_diff - min_y_diff
        offset_w = box_size[0] - box['width']
        offset_h = box_size[1] - box['height']
        # 确保box的大小符合box size
        # shift 将框增大一圈，确保囊括目标
        box['x'] -= offset_w / 2.0 + shift_size
        box['y'] -= offset_h / 2.0 + shift_size
        box['width'] += 2.0 * shift_size + offset_w
        box['height'] += 2.0 * shift_size + offset_h


        max_length = max([box['width'], box['height']])
        if max_length % 32 != 0:
            max_length = np.ceil(max_length / 32) * 32

        x_center = box['x'] + box['width'] // 2
        y_center = box['y'] + box['height'] // 2

        box['x'] = x_center - max_length // 2
        box['y'] = y_center - max_length // 2
        box['width'] = max_length
        box['height'] = max_length

        # 将框增大一圈，确保囊括目标
        # box['x'] -= shift_size
        # box['y'] -= shift_size
        # box['width'] += 2 * shift_size
        # box['height'] += 2 * shift_size
        # 当边框位于图像边缘，且不满足box size，则往内偏移。
        if box['x'] + box_size[0] >= image_size[0]:
            box['x'] -= (box['x'] + box_size[0] - image_size[0]) + 1
        if box['y'] + box_size[1] >= image_size[1]:
            box['y'] -= (box['y'] + box_size[1] - image_size[1]) + 1
        box['x'] = 0 if box['x'] < 0 else box['x']
        box['y'] = 0 if box['y'] < 0 else box['y']

        # box['width'] = image_size[0] - box['x'] if box['x'] + box['width'] > image_size[0] else box['width']
        # box['height'] = image_size[1] - box['y'] if box['y'] + box['height'] > image_size[1] else box['height']

        # box['width'] = box_size[0] + 2 * shift_size
        # box['height'] = box_size[0] + 2 * shift_size

        boxes.append(box)
        # 最后一个轮廓点到最开始轮廓点之间没有画框，需要补上
    j = len(contour) - 1
    min_x_diff = min_y_diff = max_x_diff = max_y_diff = 0
    vec_ij = contour[j] - contour[0]
    min_x_diff = vec_ij[0] if vec_ij[0] < min_x_diff else min_x_diff
    min_y_diff = vec_ij[1] if vec_ij[1] < min_y_diff else min_y_diff
    max_x_diff = vec_ij[0] if vec_ij[0] > max_x_diff else max_x_diff
    max_y_diff = vec_ij[1] if vec_ij[1] > max_y_diff else max_y_diff
    box = {}
    box['x'] = lt[0] + min_x_diff
    box['y'] = lt[1] + min_y_diff
    box['width'] = max_x_diff - min_x_diff
    box['height'] = max_y_diff - min_y_diff
    offset_w = box_size[0] - box['width']
    offset_h = box_size[1] - box['height']
    # 确保box的大小符合box size
    # shift 将框增大一圈，确保囊括目标
    box['x'] -= offset_w / 2.0 + shift_size
    box['y'] -= offset_h / 2.0 + shift_size
    box['width'] += 2.0 * shift_size + offset_w
    box['height'] += 2.0 * shift_size + offset_h

    max_length = max([box['width'], box['height']])
    if max_length % 32 != 0:
        max_length = np.ceil(max_length / 32) * 32

    x_center = box['x'] + box['width'] // 2
    y_center = box['y'] + box['height'] // 2

    box['x'] = x_center - max_length // 2
    box['y'] = y_center - max_length // 2
    box['width'] = max_length
    box['height'] = max_length
    if box['x'] + box_size[0] >= image_size[0]:
        box['x'] -= (box['x'] + box_size[0] - image_size[0]) + 1
    if box['y'] + box_size[1] >= image_size[1]:
        box['y'] -= (box['y'] + box_size[1] - image_size[1]) + 1
    # box['x'] -= shift_size
    # box['y'] -= shift_size
    # box['width'] += 2 * shift_size
    # box['height'] += 2 * shift_size

    box['x'] = 0 if box['x'] < 0 else box['x']
    box['y'] = 0 if box['y'] < 0 else box['y']
    # box['width'] = image_size[0] - box['x'] if box['x'] + box['width'] > image_size[0] else box['width']
    # box['height'] = image_size[1] - box['y'] if box['y'] + box['height'] > image_size[1] else box['height']

    # boxes.append(box)

    return boxes

def init_model(model_path):
    rt_infer = rt.InferenceSession(model_path)
    input_name = rt_infer.get_inputs()[0].name
    outputs = rt_infer.get_outputs()
    outputs_names = list(map(lambda output: output.name, outputs))
    return rt_infer, input_name, outputs_names


def predict(im, rt_infer, input_name, outputs_names, 
            rt_infer_second, input_name_second, outputs_names_second,
            target_size=(384, 384), box_size=(352, 352), shift_size=16, box_step=1.0):
    # img_shape = im.shape
    # im = im[700:2500, 300:3950]
    im = im[700:2200, 300:3900] 

    img_shape = im.shape

    orgin_img = copy.deepcopy(im)

    im = cv2.resize(im, target_size)
    im = np.ascontiguousarray(im[:, :, ::-1].transpose(2, 0, 1))
    im = np.expand_dims(im, axis=0).astype(np.float32)
    infer_img_first = rt_infer.run(['preds'], {input_name: im})[0]
    infer_img_first = np.array(infer_img_first[0,:,:]).astype(np.uint8) 
    pred_first = np.where(infer_img_first > 0, 255, 0).astype(np.uint8)
    pred_first = cv2.resize(pred_first, (img_shape[1], img_shape[0]), interpolation=cv2.INTER_NEAREST)

    # second stage
    contours, _ = cv2.findContours(pred_first, cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE)  # 将所有轮廓点保存下来，不做近似处理
    cloth_contour = get_max_contour(contours)  # 最大轮廓 contur.shape= (n,1,2) n个轮廓，1个维度，2（x，y坐标）
    # contour = contours[0].astype(np.int32)
    cloth_contour = cloth_contour.reshape(cloth_contour.shape[0], cloth_contour.shape[2])
    # point_arr = np.array(cloth_contour, dtype=np.float32)
    # point_arr[:, 0] *= x_scale
    # point_arr[:, 1] *= y_scale
    boxes = generate_boxes_along_contour(cloth_contour, image_size=(img_shape[1], img_shape[0]),
                                         box_size=box_size, shift_size=shift_size, box_step=box_step)

    mask_second_origin = np.zeros([img_shape[0], img_shape[1]], dtype=np.uint8)
    for box in boxes:
        x_tl = box['x']
        y_tl = box['y']
        x_br = box['x'] + box['width']
        y_br = box['y'] + box['height']
        x_tl, y_tl, x_br, y_br = int(x_tl), int(y_tl), int(x_br), int(y_br)
        roi_img = orgin_img[y_tl:y_br, x_tl:x_br]
        roi_img_shape = roi_img.shape
        roi_mask = pred_first[y_tl:y_br, x_tl:x_br]

        roi_img_resize = cv2.resize(roi_img, target_size, interpolation=cv2.INTER_NEAREST)
        roi_mask_resize = cv2.resize(roi_mask, target_size, interpolation=cv2.INTER_NEAREST)
        roi_mask_resize = np.where(roi_mask_resize > 0, 255, 0).astype(np.uint8)
        if not len(roi_mask_resize.shape) == 3:
            second_img = np.dstack((roi_img_resize, np.expand_dims(roi_mask_resize, axis=-1)))
        else:
            second_img = np.dstack((roi_img_resize, roi_mask_resize))
        
        # 第二阶段推理
        # second_img = np.ascontiguousarray(second_img[:, :, ::-1].transpose(2, 0, 1))
        second_img = second_img.transpose(2, 0, 1)
        second_img = np.expand_dims(second_img, axis=0).astype(np.float32)
        infer_img_second = rt_infer_second.run(['preds'], {input_name_second: second_img})[0]
        infer_img_second = np.array(infer_img_second[0,:,:]).astype(np.uint8) 
        roi_pred = np.where(infer_img_second > 0, 255, 0).astype(np.uint8)
        roi_pred = cv2.resize(roi_pred, (roi_img_shape[1], roi_img_shape[0]), interpolation=cv2.INTER_NEAREST)
        
        mask_second_origin[y_tl:y_br, x_tl:x_br] += roi_pred

    mask_second = np.zeros([img_shape[0], img_shape[1]], dtype=np.uint8)
    contours, _ = cv2.findContours(mask_second_origin, cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE)
    cloth_contour = get_max_contour(contours)
    cv2.drawContours(mask_second, [cloth_contour], -1, 255, -1)

    return pred_first, mask_second




if __name__ == '__main__':


    # 加载模型
    model_path_first = 'auto_feed_model//model_69.onnx'
    rt_infer, input_name, outputs_names = init_model(model_path_first)

    model_path_second = 'auto_feed_model//model_19_ch4.onnx'
    rt_infer_second, input_name_second, outputs_names_second = init_model(model_path_second)


    # 加载单应性矩阵
    # H_path = r'camera_parames_DH\_20250915164723435_homography.npy'
    # camera_matrix_path = r"camera_parames_DH\glue_DH_camera_matrix.npz"
    # dist_coeffs_path = r"camera_parames_DH\glue_DH_dist_coeffs.npz"
    # H = np.load(H_path)
    # converter = PixelToWorldConverter(H)
    # camera_matrix = np.load(camera_matrix_path)['camera_matrix']
    # dist_coeffs = np.load(dist_coeffs_path)['dist_coeffs']

    # 进行第一阶段的推理
    
    cv2.namedWindow('pred_first', cv2.WINDOW_NORMAL)
    cv2.namedWindow('mask_second', cv2.WINDOW_NORMAL)
    # 初始化相机
    camera = UsbCaptureSystem()
    while True:
        frame = camera.get_image()
        if frame is None:
            continue
        # im = frame[700:2200, 300:3900]  # 布料的roi 大小
        pred_first, mask_second = predict(frame, rt_infer, input_name, outputs_names, 
                                           rt_infer_second, input_name_second, outputs_names_second,
                                           target_size=(384, 384), box_size=(352, 352), shift_size=16, box_step=1.0)
        
        
        cv2.imshow('pred_first', pred_first)
        cv2.imshow('mask_second', mask_second)
        cv2.waitKey(0)

cv2.destroyAllWindows()

