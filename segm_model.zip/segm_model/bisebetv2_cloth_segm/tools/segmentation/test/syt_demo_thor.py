import copy
import sys
sys.path.insert(0, '')
sys.path.insert(0, '../../../')
sys.path.append('bisebetv2_cloth_segm')
import argparse
import math
import torch
import torch.nn.functional as F
import numpy as np
import cv2
import os
import lib.segmentation.data.transform_cv2 as T
from models.segmentation import model_factory
from configs.segmentation import set_cfg_from_file
import time


# uncomment the following line if you want to reduce cpu usage, see issue #231
#  torch.set_num_threads(4)

torch.set_grad_enabled(False)
np.random.seed(123)

def select_final_value(y_list):
    # 计算差值
    diff_1 = abs(y_list[0] - y_list[1])
    diff_2 = abs(y_list[1] - y_list[2])
    diff_3 = abs(y_list[0] - y_list[2])
    
    if diff_1 <= diff_2 and diff_1 <= diff_3:
        closest_points = (y_list[0], y_list[1])
    elif diff_2 <= diff_1 and diff_2 <= diff_3:
        closest_points = (y_list[1], y_list[2])
    else:
        closest_points = (y_list[0], y_list[2])
    
    # 返回平均值
    return (closest_points[0] + closest_points[1]) / 2
           

# args
parse = argparse.ArgumentParser() 
parse.add_argument('--config', dest='config', type=str, default=r'bisebetv2_cloth_segm\\configs\\segmentation\\bisenetv2_syt_segm_edge_thor_1203.py',) 
parse.add_argument('--weight-path', type=str, default=r'thor_model_segm\model_50.pth',)  

# parse.add_argument('--img-path', dest='img_path', type=str, default='./example.png',)
args = parse.parse_args()
cfg = set_cfg_from_file(args.config)


palette = np.random.randint(0, 256, (256, 3), dtype=np.uint8)
cfg_dict = dict(cfg.__dict__)
in_channel = cfg_dict['in_ch']
# define model

if 'net_config' in cfg_dict:
    net = model_factory[cfg.model_type](cfg.n_cats,in_ch=in_channel, aux_mode='eval', net_config=cfg.net_config)
else:
    net = model_factory[cfg.model_type](cfg.n_cats,in_ch=in_channel, aux_mode='eval')

# net.load_state_dict(torch.load(args.weight_path, map_location='cpu'), strict=False)

check_point = torch.load(args.weight_path, map_location='cpu')
if 'model_state_dict' in check_point:
    net.load_state_dict(check_point['model_state_dict'], strict=False)
else:
    net.load_state_dict(check_point, strict=False)

net.eval()
# net.cuda()


# prepare data
if in_channel == 4:
    to_tensor = T.ToTensor(
        mean=(0.5, 0.5, 0.5, 0.0),  # city, rgb
        std=(0.5, 0.5, 0.5, 1.0),
    )
else:
    to_tensor = T.ToTensor(
        mean=(0.5, 0.5, 0.5),  # city, rgb
        std=(0.5, 0.5, 0.5),
    )

# img_dir =  'D:\Data\Round_neck'
img_dir = r'Dataset\thor\20251112'

if in_channel == 4:
    mask_dir = '/home/syt/datasets/cloth_segment/second_stage/train/masks/'
img_list = os.listdir(img_dir)
target_size = (640, 640)
if 'target_size' in cfg_dict:
    target_size = cfg_dict['target_size']
# cv2.namedWindow('pred_bgr',cv2.WINDOW_KEEPRATIO)
cv2.namedWindow('pred',cv2.WINDOW_KEEPRATIO)
cv2.namedWindow('dst',cv2.WINDOW_KEEPRATIO)
cv2.namedWindow('img',cv2.WINDOW_KEEPRATIO)
cv2.namedWindow('orgin_img',cv2.WINDOW_KEEPRATIO)
for img_path in img_list:
    print(img_dir + img_path)
    if img_path[:3]=='img':
        continue
    if os.path.isdir(img_path):
        continue
  
    im = cv2.imread(img_dir + '/' + img_path)

    cv2.imshow('img', im)
    img_shape = im.shape
    orgin_img = copy.deepcopy(im)
    im = cv2.resize(im, target_size)
    im = im[:, :, ::-1]  # bge to rgb
    im = np.ascontiguousarray(im)
    if in_channel == 4:
        mask_path = mask_dir+os.path.splitext(img_path)[0]+".png"  
        if not os.path.exists(mask_path):
            continue
        mask_first = cv2.imread(mask_path, cv2.IMREAD_GRAYSCALE)
        mask_first = cv2.resize(mask_first, target_size, interpolation=cv2.INTER_NEAREST)
        mask_first = np.where(mask_first > 0, 255, 0).astype(np.uint8)
        im = np.dstack((im, np.expand_dims(mask_first, axis=-1)))
    # im = to_tensor(dict(im=im, lb=None))['im'].unsqueeze(0).cuda()
    im = to_tensor(dict(im=im, lb=None))['im'].unsqueeze(0)
    # shape divisor
    org_size = im.size()[2:]
    # new_size = [math.ceil(el / 32) * 32 for el in im.size()[2:]]


    # inference
    # im = F.interpolate(im, size=new_size, align_corners=False, mode='bilinear')
    tm_begin = time.time()
    # out = net(im)[0]
    out = net(im)
    out = out[0]

    tm_end = time.time()
    print("Time cost infer is %lf seconds" % (tm_end - tm_begin))
    # out = F.interpolate(out, size=org_size, align_corners=False, mode='bilinear')
    out = out.argmax(dim=1)

    # visualize
    out = out.squeeze().detach().cpu().numpy()
    pred = np.where(out > 0, 255, 0).astype(np.uint8)
    # row, col = np.nonzero(pred)
    # max_row = max(row) - 50
    # max_col = max(col[row == max(row)])
    # min_col = min(col[row == max(row)])
    # min_col = min(col)
    # cv2.circle(orgin_img, (min_col, max_row), 10, (0,255,0), -1)
    # cv2.circle(orgin_img, (max_col, max_row), 10, (0,255,0), -1)

    pred = cv2.resize(pred, (img_shape[1], img_shape[0]), interpolation=cv2.INTER_NEAREST)
    pred_bgr = cv2.cvtColor(pred, cv2.COLOR_GRAY2BGR)
    # cv2.imwrite('./pred_bgr.png', pred_bgr)
    # contours, _ = cv2.findContours(pred, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    # max_cn = max(contours, key=cv2.contourArea)
    # x, y, w, h = cv2.boundingRect(max_cn)
    # # cv2.rectangle(orgin_img, (x, y), (x+w, y+h), (0, 255, 0), 2)
    # cnt = cv2.approxPolyDP(max_cn, 0.0025*cv2.arcLength(max_cn, True), True)
    # cnt_np = np.squeeze(cnt)
    # for i in cnt:
    #     cv2.circle(orgin_img, (int(i[0][0]), int(i[0][1])), 2, (0, 0, 255), -1)
        
    # if 'start' in img_path.split('.')[0].split('_')[-1]:
    #     '''
    #     先取轮廓中心的x， 取小于这个x的点集
    #     取y值最小以及y值最大且x值最小的两个点作为关键点
    #     有一种情况， 在角点边缘可能聚集了两个点， 很近， 需要在进行判断， x和y是不是都很近， x比所选的小， y相距10-20个像素
    #     '''
    #     # M = cv2.moments(cnt)
    #     # # 使用矩计算中点
    #     # center_x = int(M['m10'] / M['m00'])
    #     '''
    #     对center_x 还需要做一个限制， 最大边缘是多少
    #     '''
    #     center_x = x + 168
    #     cnt_np = cnt_np[cnt_np[:, 0] < center_x]
  
    #     min_y_index = np.argmin(cnt_np[:, 1])
    #     min_y_point = cnt_np[min_y_index]

    #     # 找到 y 值最大的点，并在这些点中找到 x 值最小的点
    #     max_y_value = np.max(cnt_np[:, 1])
    #     max_y_indices = np.where(cnt_np[:, 1] == max_y_value)[0]
    #     max_y_points = cnt_np[max_y_indices]
    #     min_x_index_among_max_y_points = np.argmin(max_y_points[:, 0])
    #     max_y_min_x_point = max_y_points[min_x_index_among_max_y_points]

    #     # 筛选与 min_y_point 的 y 值相差在 40 以内的点，并且 x 值小于 min_y_point 的 x 值
    #     min_y_threshold = min_y_point[1] - 30
    #     max_y_threshold = min_y_point[1] + 30
    #     filtered_by_min_y = cnt_np[(cnt_np[:, 1] >= min_y_threshold) & (cnt_np[:, 1] <= max_y_threshold) & (cnt_np[:, 0] < min_y_point[0])]
    #     print('filtered_by_min_y', filtered_by_min_y)
    #     # 筛选与 max_y_min_x_point 的 y 值相差在 40 以内的点，并且 x 值小于 max_y_min_x_point 的 x 值
    #     min_y_threshold = max_y_min_x_point[1] - 30
    #     max_y_threshold = max_y_min_x_point[1] + 30
    #     filtered_by_max_y_min_x = cnt_np[(cnt_np[:, 1] >= min_y_threshold) & (cnt_np[:, 1] <= max_y_threshold) & (cnt_np[:, 0] < max_y_min_x_point[0])]
    #     pts = [filtered_by_min_y, filtered_by_max_y_min_x]
    #     print('pts', pts)
    #     # 在原图上画出这两个关键点
    #     cv2.line(orgin_img, (int(center_x), 0), (int(center_x), 800), (255, 0, 0), 5)
    #     if filtered_by_min_y.size > 0:
    #         cv2.circle(orgin_img, (int(filtered_by_min_y[0][0]), int(filtered_by_min_y[0][1])), 5, (255, 0, 0), -1)  # y 值最小的点
    #     else:
    #         cv2.circle(orgin_img, (int(min_y_point[0]), int(min_y_point[1])), 5, (255, 0, 0), -1)  # y 值最小的点
    #     if filtered_by_max_y_min_x.size > 0:
    #         cv2.circle(orgin_img, (int(filtered_by_max_y_min_x[0][0]), int(filtered_by_max_y_min_x[0][1])), 5, (0, 255, 0), -1)  # y 值最大且 x 值最小的点
    #     else:
    #         cv2.circle(orgin_img, (int(max_y_min_x_point[0]), int(max_y_min_x_point[1])), 5, (0, 255, 0), -1)  # y 值最大且 x 值最小的点
    # else:
    #     '''
    #     同理， 取y值最小、最大值， 但是x取最大值
    #     '''
    #     # M = cv2.moments(cnt)
    #     # # 使用矩计算中点
    #     # center_x = int(M['m10'] / M['m00'])
    #     # print(x)
    #     center_x = x + w - 168
    #     cnt_np = cnt_np[cnt_np[:, 0] > center_x]
    #     # 找到 y 值最小的点
    #     min_y_index = np.argmin(cnt_np[:, 1])
    #     min_y_point = cnt_np[min_y_index]

    #     max_y_value = np.max(cnt_np[:, 1])
    #     max_y_indices = np.where(cnt_np[:, 1] == max_y_value)[0]
    #     max_y_points = cnt_np[max_y_indices]
    #     max_x_in_max_y_points = np.argmax(max_y_points[:, 0])
    #     max_y_max_x_point = max_y_points[max_x_in_max_y_points]

    #     # 筛选与 min_y_point 的 y 值相差在 40 以内的点，并且 x 值小于 min_y_point 的 x 值
    #     min_y_threshold = min_y_point[1] - 30 
    #     max_y_threshold = min_y_point[1] + 30
    #     filtered_by_min_y = cnt_np[(cnt_np[:, 1] >= min_y_threshold) & (cnt_np[:, 1] <= max_y_threshold) & (cnt_np[:, 0] > min_y_point[0])]
    #     print('filtered_by_min_y', filtered_by_min_y)
    #     # 筛选与 max_y_min_x_point 的 y 值相差在 40 以内的点，并且 x 值小于 max_y_min_x_point 的 x 值
    #     min_y_threshold = max_y_max_x_point[1] - 30
    #     max_y_threshold = max_y_max_x_point[1] + 30
    #     filtered_by_max_y_min_x = cnt_np[(cnt_np[:, 1] >= min_y_threshold) & (cnt_np[:, 1] <= max_y_threshold) & (cnt_np[:, 0] > max_y_max_x_point[0])]

    #     cv2.line(orgin_img, (int(center_x), 0), (int(center_x), 800), (255, 0, 0), 5)
    #     if filtered_by_min_y.size > 0:
    #         cv2.circle(orgin_img, (int(filtered_by_min_y[0][0]), int(filtered_by_min_y[0][1])), 5, (255, 0, 0), -1)  # y 值最小的点
    #     else:
    #         cv2.circle(orgin_img, (int(min_y_point[0]), int(min_y_point[1])), 10, (255, 0, 0), -1)  # y 值最小的点
    #     if filtered_by_max_y_min_x.size > 0:
    #         cv2.circle(orgin_img, (int(filtered_by_max_y_min_x[0][0]), int(filtered_by_max_y_min_x[0][1])), 5, (0, 255, 0), -1)  # y 值最大且 x 值最小的点
    #     else:
    #         cv2.circle(orgin_img, (int(max_y_max_x_point[0]), int(max_y_max_x_point[1])), 10, (0, 255, 0), -1)  # y 值最大且 x 值最大的点

    # 按照y坐标排序
    # sorted_cnt_x = sorted(cnt, key=lambda x: x[0][0])
    # total_num = len(sorted_cnt_x)
    # max_index = math.ceil(total_num/2)
    # print(max_index)

    # sorted_cnt_y = sorted(cnt, key=lambda x: x[0][1])
    # sorted_cnt_y = sorted_cnt_y[:3]  # 取y值最小的两个点与kp作比较， 取三个点
    # y_sorted = [i[0][1] for i in sorted_cnt_y]
    # y_final_value = select_final_value(y_sorted) # 取y值

    # if img_path.split('.')[0].split('_')[-1] == 'start':
    #     top_three = sorted_cnt_x[:3] 
    #     sorted_cnt_x = sorted(top_three, key=lambda x: x[0][1])
    #     if abs(sorted_cnt_x[:2][0][0][0] - sorted_cnt_x[:2][1][0][0]) < 10:
    #         x_final_value = (sorted_cnt_x[:2][0][0][0] + sorted_cnt_x[:2][1][0][0]) / 2
    #     else:
    #         x_final_value = sorted_cnt_x[:2][0][0][0]
    # else:
    #     top_three = sorted_cnt_x[-3:]
    #     sorted_cnt_x = sorted(top_three, key=lambda x: x[0][1])
    #     if abs(sorted_cnt_x[:2][0][0][0] - sorted_cnt_x[:2][1][0][0]) < 10:
    #         x_final_value = (sorted_cnt_x[:2][0][0][0] + sorted_cnt_x[:2][1][0][0]) / 2
    #     else:
    #         x_final_value = sorted_cnt_x[:2][0][0][0]

    
    # cv2.circle(orgin_img, (int(x_final_value), int(y_final_value)), 2, (0, 255, 0), 3)
    # cv2.circle(orgin_img, (int(top_two[0][0][0]), int(top_two[0][0][1])), 2, (0, 255, 0), 3)


    dst = cv2.addWeighted(orgin_img, 0.8, pred_bgr, 0.5, 0)

    # out_result_path = 'out_result'
    # os.makedirs(out_result_path, exist_ok=True)
    # cv2.imwrite(os.path.join(out_result_path, img_path), dst)

    # cv2.imshow('pred_bgr', pred_bgr)     
    cv2.imshow('pred', pred)     
    cv2.imshow('dst', dst)
    cv2.imshow('orgin_img', orgin_img)
    key = cv2.waitKey(0)
    if ord('q') == key:
        break
