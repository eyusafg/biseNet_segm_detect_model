import cv2
import numpy as np
import os
import threading
import time
import queue
import copy
import sys
sys.path.insert(0, '')
sys.path.insert(0, '../../../')
sys.path.append('bisebetv2_cloth_segm')
import argparse
import math
import torch
import torch.nn.functional as F
import numpy as np
import cv2
import os
import lib.segmentation.data.transform_cv2 as T
from models.segmentation import model_factory
from configs.segmentation import set_cfg_from_file
import logging
import keyboard
import datetime



parse = argparse.ArgumentParser() 
parse.add_argument('--config', dest='config', type=str, default='bisebetv2_cloth_segm\\configs\\segmentation\\bisenetv2_syt_segm_edge_black_widow_0703.py',) 
# parse.add_argument('--weight-path', type=str, default='bisebetv2_cloth_segm\\output\widow\\segmentation\\res\\2024-07-02_17-37-08\\model_19.pth',)  
parse.add_argument('--weight-path', type=str, default='bisebetv2_cloth_segm\\output\\widow\\segmentation\\res\\2024-07-03_19-58-34\\model_104.pth',)  
args = parse.parse_args()
cfg = set_cfg_from_file(args.config)
palette = np.random.randint(0, 256, (256, 3), dtype=np.uint8)
cfg_dict = dict(cfg.__dict__)
in_channel = cfg_dict['in_ch']
net = model_factory[cfg.model_type](cfg.n_cats,in_ch=in_channel, aux_mode='eval', net_config=cfg.net_config)
check_point = torch.load(args.weight_path, map_location='cpu')
if 'model_state_dict' in check_point:
    net.load_state_dict(check_point['model_state_dict'], strict=False)
else:
    net.load_state_dict(check_point, strict=False)
net.eval()
to_tensor = T.ToTensor(mean=(0.5, 0.5, 0.5), std=(0.5, 0.5, 0.5),)
target_size = cfg_dict['target_size']


def threading_infer(model, frame, queue_out):
    
    # image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    # im = cv2.resize(image, target_size, interpolation=cv2.INTER_LINEAR)
    # im = np.ascontiguousarray(im)
    # im = to_tensor(dict(im=im, lb=None))['im'].unsqueeze(0)
    # with torch.no_grad():
    #     out = model(im)
    # out = out[0].argmax(dim=1).cpu().numpy()

    # out = np.where(out == 1, 0, out).astype(np.uint8)
    # out = out.squeeze(0)
    # out = np.where(out > 0, 255, out).astype(np.uint8)
    queue_out.put(frame)


cap1 = cv2.VideoCapture(1)
cap2 = cv2.VideoCapture(2)
cap1.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*'MJPG'))
cap2.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*'MJPG'))
cap1.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
cap1.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
cap2.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
cap2.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
cap1.set(cv2.CAP_PROP_FPS, 30)
cap2.set(cv2.CAP_PROP_FPS, 30)
print(cap1.get(cv2.CAP_PROP_FPS))
print(cap2.get(cv2.CAP_PROP_FPS))
ret1, frameq = cap1.read()
ret2, framea = cap2.read()
print('camera init success')

frame_queue1 = queue.Queue(maxsize=10)
frame_queue2 = queue.Queue(maxsize=10)

while True:
    if cap1.isOpened() and cap2.isOpened():

        ret1, frame1 = cap1.read()
        ret2, frame2 = cap2.read()
        threading1 = threading.Thread(target=threading_infer, args=(net, frame1, frame_queue1))
        threading2 = threading.Thread(target=threading_infer, args=(net, frame2, frame_queue2))
        
        threading1.start()
        threading2.start()

        out1 = frame_queue1.get()
        out2 = frame_queue2.get()
        cv2.imshow('out1', out1)
        cv2.imshow('out2', out2)
        if cv2.waitKey(1) & 0xff == ord('q'):
            break

threading1.join()
threading2.join()

cap1.release()
cap2.release()
cv2.destroyAllWindows()