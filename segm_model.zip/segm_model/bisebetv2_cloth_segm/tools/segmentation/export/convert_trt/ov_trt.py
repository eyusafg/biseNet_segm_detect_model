
import os
import os.path as osp
import cv2
import numpy as np
import argparse

import tensorrt as trt
print(trt.__version__)
import pycuda.driver as cuda
import pycuda.autoinit
import time


parser = argparse.ArgumentParser(description=" ")
parser.add_argument('--command', default='run', help='')
parser.add_argument('--onnx', default='model.onnx', help='.')
parser.add_argument('--quant', default='fp32', help='')
parser.add_argument('--savepth', default='./model_10_16.trt', help='')
parser.add_argument('--mdpth', default='model_10_16.trt', type=str)
parser.add_argument('--impth', default='hulk_images', help='')
parser.add_argument('--outpth', default='./res.png', help='')
args = parser.parse_args()

np.random.seed(123)
in_datatype = trt.nptype(trt.float32)
out_datatype = trt.nptype(trt.int32)
palette = np.random.randint(0, 256, (256, 3)).astype(np.uint8)

ctx = pycuda.autoinit.context
trt.init_libnvinfer_plugins(None, "")
TRT_LOGGER = trt.Logger()



def get_image(impath, size):
    mean = np.array([0.5, 0.5, 0.5], dtype=np.float32)[:, None, None]
    var = np.array([0.5, 0.5, 0.5], dtype=np.float32)[:, None, None]
    iH, iW = size[0], size[1]
    im = cv2.imread(impath)
    if iH == 256:
        im = im[0:256,:]
    # im_cp = im.copy()
    img = im[:, :, ::-1]
    # orgH, orgW, _ = img.shape
    img = cv2.resize(img, (iW, iH)).astype(np.float32)
    img = img.transpose(2, 0, 1)
    # img = img.transpose(2, 0, 1) / 255.
    img = (img - mean) / var
    return img



def allocate_buffers(engine):
    h_input = cuda.pagelocked_empty(
            trt.volume(engine.get_binding_shape(0)), dtype=in_datatype)
    print(engine.get_binding_shape(0))
    d_input = cuda.mem_alloc(h_input.nbytes)
    h_outputs, d_outputs = [], []
    n_outs = 1
    for i in range(n_outs):
        h_output = cuda.pagelocked_empty(
                trt.volume(engine.get_binding_shape(i+1)),
                dtype=out_datatype)
        d_output = cuda.mem_alloc(h_output.nbytes)
        h_outputs.append(h_output)
        d_outputs.append(d_output)
    stream = cuda.Stream()
    return (
        stream,
        h_input,
        d_input,
        h_outputs,
        d_outputs,
    )



def build_engine_from_onnx(onnx_file_path):
    engine = None
    EXPLICIT_BATCH = 1 << (int)(trt.NetworkDefinitionCreationFlag.EXPLICIT_BATCH)  # batch 显示处理
    with trt.Builder(TRT_LOGGER) as builder, builder.create_network(EXPLICIT_BATCH) as network, builder.create_builder_config() as config, trt.OnnxParser(network, TRT_LOGGER) as parser, trt.Runtime(TRT_LOGGER) as runtime:
        # 创建网络 并加载ONNX模型
        # Parse model file
        print(f'Loading ONNX file from path {onnx_file_path}...')
        assert os.path.exists(onnx_file_path), f'cannot find {onnx_file_path}'
        with open(onnx_file_path, 'rb') as fr:
            if not parser.parse(fr.read()):
                print ('ERROR: Failed to parse the ONNX file.')
                for error in range(parser.num_errors):
                    print (parser.get_error(error))
                assert False

        # build settings
        builder.max_batch_size = 128  # 最大batchsize
        config.max_workspace_size = 1 << 30 # 1G 
        if args.quant == 'fp16':
            config.set_flag(trt.BuilderFlag.FP16)

        print("Start to build Engine")
        plan = builder.build_serialized_network(network, config)
        engine = runtime.deserialize_cuda_engine(plan)
    return engine


def serialize_engine_to_file(engine, savepth):
    plan = engine.serialize()
    with open(savepth, "wb") as fw:
        fw.write(plan)  # 序列化engine到文件


def deserialize_engine_from_file(savepth):
    with open(savepth, 'rb') as fr, trt.Runtime(TRT_LOGGER) as runtime:
        engine = runtime.deserialize_cuda_engine(fr.read())
    return engine # 反序列化engine


def main():
    OFFSET = 50
    if args.command == 'compile':
        engine = build_engine_from_onnx(args.onnx)
        serialize_engine_to_file(engine, args.savepth)

    elif args.command == 'run':
        engine = deserialize_engine_from_file(args.mdpth)
        ishape = engine.get_binding_shape(0) # 输入尺寸
        # tm_begin_vis = time.time()

        (
            stream,
            h_input,
            d_input,
            h_outputs,
            d_outputs,
        ) = allocate_buffers(engine)
        # ctx.push()
        context = engine.create_execution_context()
        # ctx.pop()
        bds = [int(d_input), ] + [int(el) for el in d_outputs]
        dummy_data = np.random.rand(*ishape).astype(np.float32)  
        cuda.memcpy_htod_async(d_input, dummy_data, stream)  
        context.execute_async(bindings=bds, stream_handle=stream.handle) 
        # stream.synchronize() 

        image_paths = [os.path.join(args.impth, filename) for filename in os.listdir(args.impth) if filename.endswith(('.jpg', '.png', '.jpeg'))]

        for image_path in image_paths:
            tm_begin_vis = time.time()
            img = get_image(image_path, ishape[2:])
            h_input = np.ascontiguousarray(img)
            cuda.memcpy_htod_async(d_input, h_input, stream)
            context.execute_async(bindings=bds, stream_handle=stream.handle)

            for h_output, d_output in zip(h_outputs, d_outputs):
                cuda.memcpy_dtoh_async(h_output, d_output, stream)
            stream.synchronize()

            oshape = engine.get_binding_shape(1)
            pred = h_outputs[0].reshape(oshape)[0,:,:]
            tm_end_vis = time.time()
            print(f"Inference time for {image_path} is {tm_end_vis - tm_begin_vis} seconds")

            pred = np.where(pred > 0, 255, 0).astype(np.uint8)
        # tm_end_vis = time.time()

            # cv2.imshow('pred', pred)
            # cv2.waitKey(0)
        # time1 = time.time()
        # contours, _ = cv2.findContours(pred, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        # max_area = 0
        # for cnt in contours:
        #     area = cv2.contourArea(cnt)
        #     if area > max_area:
        #         max_area = area
        # # print('max_area:', max_area)  
        # if max_area > 27011 * 0.25:
        #     row, col = np.nonzero(pred)
        #     min_row = min(row)
        #     max_col = max(col[row == min_row])
        #     min_col = min(col[row == min_row])
        #     # cv2.circle(origin_img, (min_col, min_row), 10, (0, 0, 255), -1)
        #     cv2.circle(im_cp, (max_col, min_row), 10, (0, 255, 125), -1)
        #     print('max_col:', max_col)
        #     offset = OFFSET / 640 * max_col
        #     offset = round(offset, 2) * 100
        #     # print('offset:', offset)
        #     # client.write_single_register(322, int(offset))
        #     time2 = time.time()
        #     print("postprecoseing Time cost vis is %lf seconds" % (time2 - time1))
        #     # with open('offsets.txt', 'a') as file:    
        #     #     file.write(f"{offset}\n")
        #     # time_str = time.strftime(f'%Y-%m-%d_%H-%M-%S_{i}', time.localtime(time.time()))
        #     # with open('offsets.txt', 'a') as file:
        #     #     file.write(f"{time_str}: {offset}\n")
            

        #     # pred = cv2.resize(pred, (img_shape[1], img_shape[0]), interpolation=cv2.INTER_NEAREST)
        #     # pred = cv2.cvtColor(pred, cv2.COLOR_GRAY2BGR)
        #     # dst = cv2.addWeighted(origin_img, 0.8, pred, 0.5, 0)
        #     dst = cv2.circle(im_cp, (max_col, 1), 3, (0, 255, 0), -1)

        #     # time_str = time.strftime('%Y-%m-%d_%H-%M-%S', time.localtime(time.time()))
        #     out_result_path = 'out_result'
        #     # # os.makedirs(out_result_path, exist_ok=True)
        #     cv2.imwrite(os.path.join(out_result_path, '1' + '.png'), dst)
        #     # cv2.imwrite(os.path.join(out_result_path, time_str + '.png'), dst)
        #     # i += 1

if __name__ == '__main__':
    main()

