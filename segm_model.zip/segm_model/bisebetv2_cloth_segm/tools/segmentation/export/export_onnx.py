import argparse
import sys
sys.path.insert(0, '')
sys.path.insert(0, '../../../')
sys.path.append('bisebetv2_cloth_segm')

import torch

from models.segmentation import model_factory
from configs.segmentation import set_cfg_from_file

torch.set_grad_enabled(False)


parse = argparse.ArgumentParser()
parse.add_argument('--config', dest='config', type=str,
        default=r'bisebetv2_cloth_segm\configs\segmentation\bisenetv2_syt_segm_edge_thor_1203.py',)
parse.add_argument('--weight-path', dest='weight_pth', type=str,
        default=r'thor_model_segm\model_50.pth')
parse.add_argument('--outpath', dest='out_pth', type=str,
        default='thor//thor_segm_model_50.onnx')
parse.add_argument('--aux-mode', dest='aux_mode', type=str,
        default='pred')
args = parse.parse_args()


cfg = set_cfg_from_file(args.config)
if cfg.use_sync_bn: cfg.use_sync_bn = False

net = model_factory[cfg.model_type](cfg.n_cats, cfg.in_ch, aux_mode=args.aux_mode, net_config=cfg.net_config) 
# net.load_pretrain(args.weight_pth)
check_point = torch.load(args.weight_pth, map_location='cpu')
if 'model_state_dict' in check_point:
    net.load_state_dict(check_point['model_state_dict'], strict=False)
else:
    net.load_state_dict(check_point, strict=False)
# net.load_state_dict(torch.load(args.weight_pth, map_location='cpu'), strict=False)
net.export()

#  dummy_input = torch.randn(1, 3, *cfg.crop_size)
target_size = (384, 384)
if 'target_size' in dict(cfg.__dict__):
    target_size = cfg.target_size
dummy_input = torch.randn(1, cfg.in_ch, target_size[1], target_size[0])
input_names = ['input_image']
output_names = ['preds',]

torch.onnx.export(net, dummy_input, args.out_pth,
    input_names=input_names, output_names=output_names,
    verbose=False, opset_version=11, )

