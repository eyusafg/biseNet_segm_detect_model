import openvino as ov
import  openvino.tools.mo as mo
import os 
from openvino.tools import mo
from openvino.runtime import serialize


# mo.convert_model returns an openvino.runtime.Model object
ov_model = mo.convert_model('model.onnx')

serialize(ov_model, xml_path='openvino_ir/' + "distilbert.xml")
