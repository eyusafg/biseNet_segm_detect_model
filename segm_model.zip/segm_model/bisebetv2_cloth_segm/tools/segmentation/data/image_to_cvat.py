import sys
sys.path.insert(0, '')
sys.path.insert(0, '../../../')
from bisebetv2_cloth_segm.lib.segmentation.data.syt_segm_dataset import SytSegmDataset
import numpy as np
import copy
import cv2
import os
import time
from lxml import etree
from lib.segmentation.data.contours_to_cvat import contours_to_cvat
def to_cvat(input_dir, output_dir, in_channle):
    if not os.path.exists(output_dir+'\\img'):
        os.makedirs(os.path.join(output_dir, 'img'))
    root_name = 'annotations'
    root_name_length = len(root_name)
    etree_root = etree.Element(root_name)

    xml_file_path = os.path.join(output_dir, 'img', 'annotations.xml')
    with open(xml_file_path, 'wb') as f:
        f.write(bytes('<%s>\n' % root_name, encoding="utf8"))

    dataset = SytSegmDataset(input_dir, in_ch=in_channle, augment_flag=False, return_img=True)

    dataset_lenght=dataset.__len__()
    tree_num = 0
    for idx, (img, label) in enumerate(dataset):
        print('\rrunning: %d/%d' % (idx+1, dataset_lenght), end='')
        # return numpy
        label = np.where(label > 0, 255, 0).astype(np.uint8)
        if in_channle == 4:
            mask = copy.deepcopy(img[:, :, 3:])
            img = img[:, :, :3].astype(np.uint8)

        local_time = time.strftime('%Y-%m-%d_%H-%M-%S', time.localtime())
        img_name = '%s_%d' % (local_time, idx)
        cv2.imwrite(output_dir + '/img/' + img_name + '.png', img)

        img_child = etree.Element('image')
        label_contours, _ = cv2.findContours(label, cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE)
        contours_to_cvat(img_child, label_contours, (img.shape[1], img.shape[0]), '衣服', img_name)

        if in_channle == 4:
            mask_contours, _ = cv2.findContours(mask, cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE)
            contours_to_cvat(img_child, mask_contours, (img.shape[1], img.shape[0]), 'mask', img_name)

        etree_root.append(img_child)
        tree_num += 1
        if tree_num >= 1000:
            xml_string = etree.tostring(etree_root, encoding='utf-8', pretty_print=True, method='xml')
            with open(xml_file_path, 'ab+') as f:
                f.write(xml_string[(root_name_length + 3):-(root_name_length + 4)])
                etree_root.clear()



        # show image
        # cv2.drawContours(img, label_contours, -1, (200, 200, 50), 2)
        # if in_channle == 4:
        #     cv2.imshow("mask", mask)
        # cv2.imshow('img', img)
        # cv2.imshow("label", label)
        
        # if cv2.waitKey(0) == ord('q'):
        #     cv2.destroyAllWindows()
        #     break
    print()
    xml_string = etree.tostring(etree_root, encoding='utf-8', pretty_print=True, method='xml')
    with open(xml_file_path, 'ab+') as f:
        f.write(xml_string[(root_name_length + 3):-(root_name_length + 4)])
        etree_root.clear()
    with open(xml_file_path, 'ab+') as f:
        f.write(bytes('</%s>' % root_name, encoding="utf8"))

if __name__ == '__main__':
    img_dir = r'ch4_data\round_neck_1130\test'
    output_dir = 'Datasets\\round_neck_113\\test'
    to_cvat(img_dir,
            output_dir,
            in_channle=4  # 记得改通道数
            )