import copy
import sys
sys.path.insert(0, '')
sys.path.insert(0, '../../../')
import argparse
import math
import torch
import torch.nn.functional as F
import numpy as np
import cv2
import os
import bisebetv2_cloth_segm.lib.segmentation.data.transform_cv2 as T
from bisebetv2_cloth_segm.models.segmentation import model_factory
from bisebetv2_cloth_segm.configs.segmentation import set_cfg_from_file
import time
from bisebetv2_cloth_segm.lib.segmentation.data.generate_boxes_along_contour import generate_boxes_along_contour, get_max_contour
# from lxml import etree
# from lib.segmentation.data.contours_to_cvat import contours_to_cvat
from bisebetv2_cloth_segm.lib.segmentation.data.syt_segm_dataset import SytSegmDataset
import multiprocessing
# uncomment the following line if you want to reduce cpu usage, see issue #231
#  torch.set_num_threads(4)

torch.set_grad_enabled(False)
np.random.seed(123)
# list_ = list(range(31))
# lists_length = len(list_) // 8
# sublists = [list_[i:i + lists_length] for i in range(0, len(list_), lists_length)]
# print(sublists)
# for i in range(0, len(list_), lists_length):
#     print(i, end=' ')
#     # print(i * lists_length, end=' ')
#     end_idx = i + lists_length - 1
#     if end_idx >= len(list_):
#         end_idx = len(list_)-1
#     print(end_idx)

torch.cuda.empty_cache()

# args
parse = argparse.ArgumentParser()
parse.add_argument('--config', dest='config', type=str, default=r'bisebetv2_cloth_segm\\configs\\segmentation\\bisenetv2_syt_segm_edge_round_1129.py',)
# parse.add_argument('--config', dest='config', type=str, default='bisebetv2_cloth_segm\configs\segmentation\\bisenetv2_syt_segm_edge_round_neck_0924_2592_1944.py',)
# parse.add_argument('--weight-path', type=str, default='bisebetv2_cloth_segm/output/neck/segmentation/res/2024-08-08_11-49-36\model_9.pth',)
# parse.add_argument('--weight-path', type=str, default='bisebetv2_cloth_segm\\output\\neck\\segmentation\\res\\2024-09-24_17-10-46\model_4.pth',)
parse.add_argument('--weight-path', type=str, default=r'model_59.pth',)
# parse.add_argument('--img-path', dest='img_path', type=str, default='./example.png',)
args = parse.parse_args()
cfg = set_cfg_from_file(args.config)
# lock = multiprocessing.Manager().Lock()
# Counter = multiprocessing.Value('i', 0)
def save_data(output_dir, boxes, orgin_img, label, mask, img_idx):
    img_child_list = []
    # root_name = 'annotations'
    # etree_root = etree.Element(root_name)
    # root_name_length = len(root_name)
    # boxes_length = len(boxes)
    for roi_idx, box in enumerate(boxes):
        x_tl = box['x']
        y_tl = box['y']
        x_br = box['x'] + box['width']
        y_br = box['y'] + box['height']

        # roi = image[y_tl : y_br, x_tl: x_br] # 原图上取roi
        x_tl, y_tl, x_br, y_br = int(x_tl), int(y_tl), int(x_br), int(y_br)
        # pt1 = (x_tl, y_tl)
        # pt2 = (x_br, y_br)
        # cv2.rectangle(image, pt1, pt2, (0, 255, 127), 4)
        # cv2.rectangle(mask, (x_tl, y_tl), (x_br, y_br), 255, 4)

        roi_image = orgin_img[y_tl:y_br, x_tl:x_br].astype(np.uint8)
        roi_label = label[y_tl:y_br, x_tl:x_br]
        roi_mask = mask[y_tl:y_br, x_tl:x_br]
        # show_contour = np.zeros([roi_mask.shape[0], roi_mask.shape[1], 1], np.uint8)
        local_time = time.strftime('%Y-%m-%d_%H-%M-%S', time.localtime())
        img_name = '%s_%d_%d' % (local_time, img_idx, roi_idx)
        # time1 = time.time()
        cv2.imwrite(output_dir + '/images/' + img_name + '.png', roi_image)
        cv2.imwrite(output_dir + '/labels/' + img_name + '.png', roi_label)
        cv2.imwrite(output_dir + '/masks/' + img_name + '.png', roi_mask)
        # print('保存', img_idx, time.time() - time1)

        # label_contours, _ = cv2.findContours(roi_label, cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE)
        # mask_contours, _ = cv2.findContours(roi_mask, cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE)

        # img_child = etree.Element('image')
        # contours_to_cvat(img_child, label_contours, (roi_image.shape[1], roi_image.shape[0]), '衣服', img_name)
        # contours_to_cvat(img_child, mask_contours, (roi_image.shape[1], roi_image.shape[0]), 'mask', img_name)
        # etree_root.append(img_child)
def save_scale_data(output_dir, dataset, target_size, box_steps, box_size, shift_size, begin_idx, batch_size):
    end_idx = begin_idx + batch_size
    if end_idx > dataset.__len__():
        end_idx = dataset.__len__()
    for idx in range(begin_idx, end_idx):
        print('scale: id:%d %d/%d' % (begin_idx // batch_size, idx - begin_idx, end_idx - begin_idx - 1))
    # idx = batch_size * list_idx + batch_idx
        im, label = dataset[idx]
        # cv2.imshow('label', label)
        # cv2.waitKey(0)
        contours, _ = cv2.findContours(label, cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE)  # 将所有轮廓点保存下来，不做近似处理
        if len(contours) == 0:
            return
        # print('\rrunning: %d/%d' % (idx + 1, dataset_lenght), end='')
        img_shape = im.shape
        orgin_img = copy.deepcopy(im)

        mask = cv2.resize(label, target_size, interpolation=cv2.INTER_NEAREST)
        mask = cv2.resize(mask, (img_shape[1], img_shape[0]), interpolation=cv2.INTER_NEAREST)

        cloth_contour = get_max_contour(contours)  # 最大轮廓 contur.shape= (n,1,2) n个轮廓，1个维度，2（x，y坐标）
        cloth_contour = cloth_contour.reshape(cloth_contour.shape[0], cloth_contour.shape[2])
        boxes = []
        for box_step in box_steps:
            step_boxes = generate_boxes_along_contour(cloth_contour, image_size=(img_shape[1], img_shape[0]),
                                                      box_size=box_size, shift_size=shift_size, box_step=box_step)
            boxes.extend(step_boxes)
        save_data(output_dir, boxes, orgin_img, label, mask, idx)
def save_infer_data(output_dir, dataset, net, target_size, box_steps, box_size,shift_size, begin_idx, batch_size):
    to_tensor = T.ToTensor(
        mean=dataset.tensor_mean,  # city, rgb
        std=dataset.tensor_std,
    )
    end_idx = begin_idx + batch_size
    dataset_length = dataset.__len__()
    if end_idx > dataset_length:
        end_idx = dataset_length
    # global lock
    # global Counter
    for idx in range(begin_idx, end_idx):
        print('infer: id:%d %d/%d' %(begin_idx//batch_size, idx-begin_idx, end_idx-begin_idx-1))
        # idx = batch_size * list_idx + batch_idx
        im, label = dataset[idx]
        img_shape = im.shape

        orgin_img = copy.deepcopy(im)
        im = cv2.resize(im, target_size, interpolation=cv2.INTER_NEAREST)
        im = im[:, :, ::-1]  # bge to rgb
        im = np.ascontiguousarray(im)
        im = to_tensor(dict(im=im, lb=None))['im'].unsqueeze(0).cuda()
        # im = to_tensor(dict(im=im, lb=None))['im'].unsqueeze(0)
        # shape divisor
        org_size = im.size()[2:]
        new_size = [math.ceil(el / 32) * 32 for el in im.size()[2:]]

        # inference
        # im = F.interpolate(im, size=new_size, align_corners=False, mode='bilinear')
        # tm_begin = time.time()
        out = net(im)
        out = out[0]
        # tm_end = time.time()
        # print("Time cost infer is %lf seconds" % (tm_end - tm_begin))
        # out = F.interpolate(out, size=org_size, align_corners=False, mode='bilinear')
        out = out.argmax(dim=1)

        # visualize
        out = out.squeeze().detach().cpu().numpy()
        pred = np.where(out > 0, 255, 0).astype(np.uint8)
        pred = cv2.resize(pred, (img_shape[1], img_shape[0]), interpolation=cv2.INTER_NEAREST)
        cv2.namedWindow('pred', cv2.WINDOW_NORMAL)
        cv2.imshow('pred', pred)
        cv2.waitKey(0)
        contours, _ = cv2.findContours(label, cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE)  # 将所有轮廓点保存下来，不做近似处理
        if len(contours) == 0:
            return
        cloth_contour = get_max_contour(contours)  # 最大轮廓 contur.shape= (n,1,2) n个轮廓，1个维度，2（x，y坐标）
        cloth_contour = cloth_contour.reshape(cloth_contour.shape[0], cloth_contour.shape[2])
        boxes = []
        for box_step in box_steps:
            step_boxes = generate_boxes_along_contour(cloth_contour, image_size=(img_shape[1], img_shape[0]),
                                                      box_size=box_size, shift_size=shift_size, box_step=box_step)
            boxes.extend(step_boxes)
        save_data(output_dir, boxes, orgin_img, label, pred, idx)

def infer_second_data(img_dir,output_dir,processes, box_steps=[1.0], box_size = (352, 352), shift_size = 16):
    # palette = np.random.randint(0, 256, (256, 3), dtype=np.uint8)
    cfg_dict = dict(cfg.__dict__)
    in_channel = cfg_dict['in_ch']
    target_size = (384, 384)
    if 'target_size' in cfg_dict:
        target_size = cfg_dict['target_size']
    # define model

    if 'net_config' in cfg_dict:
        net = model_factory[cfg.model_type](cfg.n_cats,in_ch=in_channel, aux_mode='eval', net_config=cfg.net_config)
    else:
        net = model_factory[cfg.model_type](cfg.n_cats,in_ch=in_channel, aux_mode='eval')
    # net = model_factory[cfg.model_type](cfg.n_cats, aux_mode='eval')
    check_point = torch.load(args.weight_path, map_location='cpu')
    if 'model_state_dict' in check_point:
        net.load_state_dict(check_point['model_state_dict'], strict=False)
    else:
        net.load_state_dict(check_point, strict=False)
    net.eval()
    net.cuda()
    # dataset = SytSegmDataset(img_dir, target_size, 3, augment_flag=False,return_img=True)
    dataset = SytSegmDataset(img_dir, cfg.class_mapping,cfg.class_colors, cfg.inv, target_size, 3, augment_flag=False, return_img=True)

    dataset_lenght = dataset.__len__()
    batch_size = dataset_lenght // processes
    if dataset_lenght < batch_size or batch_size == 0:
        batch_size = dataset_lenght

    ctx = torch.multiprocessing.get_context("spawn")
    pool = ctx.Pool(processes=processes)
    for begin_idx in range(0, dataset_lenght, batch_size):
        # save_infer_data(output_dir, dataset, net, target_size, box_steps, box_size, shift_size, begin_idx, batch_size)
        pool.apply_async(save_infer_data, (
                        output_dir, dataset, net, target_size, box_steps, box_size,shift_size, begin_idx, batch_size),error_callback=err_call_back)
        
    pool.close()  # 关闭进程池，不能再添加进程
    pool.join()  # 主进程等待所有进程执行完毕
        # save_infer_data(output_dir, dataset,net, target_size, box_steps, box_size, shift_size, begin_idx, batch_size)
    
    ### 进行资源释放
    del net
    torch.cuda.empty_cache()
    torch.cuda.synchronize()


def err_call_back(err):
    print(f'出错啦~ error：{str(err)}')
def scale_second_data(img_dir,output_dir, processes, box_steps=[1.0], box_size = (352, 352), shift_size = 16):
    cfg_dict = dict(cfg.__dict__)
    target_size = (384, 384)
    if 'target_size' in cfg_dict:
        target_size = cfg_dict['target_size']
    dataset = SytSegmDataset(img_dir, cfg.class_mapping,cfg.class_colors, cfg.inv, target_size, 3, augment_flag=False, return_img=True)
    dataset_lenght = dataset.__len__()
    batch_size = dataset_lenght // processes
    if dataset_lenght < batch_size or batch_size == 0:
        batch_size = dataset_lenght
    pool = multiprocessing.Pool(processes=processes)
    for begin_idx in range(0, dataset_lenght, batch_size):
        pool.apply_async(save_scale_data, (
                        output_dir, dataset, target_size, box_steps, box_size, shift_size, begin_idx, batch_size))
    pool.close()  # 关闭进程池，不能再添加进程
    pool.join()  # 主进程等待所有进程执行完毕
    # begin_idx = 1
    # save_scale_data(output_dir, dataset, target_size, box_steps, box_size, shift_size, begin_idx, batch_size)

    # return etree_root
if __name__ == '__main__':
    # img_dir = '/home/syt/datasets/first/train'
    img_dir = r'D:\Data\Round_Neck_Data\images'
    output_dir = 'ch4_data\\round_neck_1130\\test'
    processes = 4
    # Counter = multiprocessing.Value('i', 0)
    # lock = multiprocessing.Lock()
    # etree_root = etree.Element(root_name)
    if not os.path.exists(output_dir+'/images'):
        os.makedirs(output_dir+'/images')
        os.makedirs(output_dir+'/masks')
        os.makedirs(output_dir+'/labels')

    # scale_second_data(img_dir, output_dir, processes, box_steps=[1.0, 0.2])
    infer_second_data(img_dir, output_dir, processes, box_steps=[1.0, 0.2])

