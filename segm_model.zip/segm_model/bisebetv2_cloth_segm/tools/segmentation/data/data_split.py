import random
import sys
sys.path.insert(0, '')
sys.path.insert(0, '../../../')
sys.path.append('bisebetv2_cloth_segm')
from lib.segmentation.data.syt_segm_dataset import SytSegmDataset
import xml.etree.ElementTree as ET
import os
import time
import shutil


def data_split(full_list, ratio, shuffle=False):
    """
    数据集拆分: 将列表full_list按比例ratio（随机）划分为2个子列表sublist_1与sublist_2
    :param full_list: 数据列表
    :param ratio:     子列表1
    :param shuffle:   子列表2
    :return:
    """
    n_total = len(full_list)
    offset = int(n_total * ratio)
    if n_total == 0 or offset < 1:
        return [], full_list
    if shuffle:
        random.shuffle(full_list)
    sublist_1 = full_list[:offset]
    sublist_2 = full_list[offset:]
    return sublist_1, sublist_2


# data = list(range(20))
# print(data)
# sub_data1, sub_data2 = data_split(data, ratio=0.7, shuffle=True)
# print(sub_data1)
# print(sub_data2)
# print(sub_data2[2:6])
# # [14, 4, 3, 10, 5, 19]
# # [3, 10, 5, 19]

if __name__ == "__main__":
    in_channel = 3 # 记得改通道数！
    ratio = 0.7  # 训练集：验证集
    max_val_num = 1000  # 验证集最大值，当按比例超过最大值，会限制在最大值。

    input_dir = r'Lnner_Lining_imgs_roi\images'
    output_dir = r'Lnner_Lining_imgs_roi'
    output_dir = os.path.join(output_dir, 'output', time.strftime('%Y-%m-%d_%H-%M-%S', time.localtime()))

    print('output path:', output_dir)


    dataset = SytSegmDataset(input_dir, in_ch=in_channel, augment_flag=False, return_img=True)
    if dataset.cvat_mode_:
        dataset_num = len(dataset.image_first_index_)-1
        list_length = dataset.__len__()
        if list_length > max_val_num / (1.0 - ratio):
            ratio = 1.0 - max_val_num / list_length

        curr_idx=0
        root_name = 'annotations'
        root_name_length = len(root_name)

        for i in range(dataset_num):
            curr_idx+=1
            train_list, val_list = data_split(
                dataset.image_list_[dataset.image_first_index_[i]+1:
                                    dataset.image_first_index_[i+1]+1],
                ratio=ratio,
                shuffle=True)

            train_etree_root = ET.Element(root_name)
            if not os.path.exists(output_dir):
                train_dir = os.path.join(output_dir, 'train')
                val_dir = os.path.join(output_dir, 'val')
                os.makedirs(train_dir)
                os.makedirs(val_dir)
            # etree_root = infer_second_data(img_dir, output_dir, etree_root, box_steps=[1.0, 0.1])
            tree_num = 0
            xml_file_path = os.path.join(train_dir, 'train.xml')
            with open(xml_file_path, 'wb') as f:
                f.write(bytes('<%s>\n' % root_name, encoding="utf8"))
            for el in train_list:
                print('\rrunning: %d/%d' % (curr_idx, list_length), end='')
                img_name = el.get('name')
                img_name_start = el.get('name').split('/')[0]
                img_path_end = dataset.xml_files_[i][0].split('/')[-1]
                if img_name_start == img_path_end:
                    img_name = el.get('name').split('/')[-1]
                img_path = os.path.join(dataset.xml_files_[i][0], img_name)
             
                # if not os.path.exists(os.path.join(train_dir, img_name)):
                #     os.makedirs(train_dir, img_name)
                #     os.makedirs(val_dir, img_name)
             

                shutil.move(img_path, os.path.join(train_dir, img_name))
                train_etree_root.append(el)
                tree_num += 1
                if tree_num >= 1000:
                    xml_string = ET.tostring(train_etree_root, encoding='utf-8', method='xml')
                    with open(xml_file_path, 'ab+') as f:
                        f.write(xml_string[(root_name_length + 2):-(root_name_length + 4)])
                        train_etree_root.clear()
            xml_string = ET.tostring(train_etree_root, encoding='utf-8', method='xml')
            with open(xml_file_path, 'ab+') as f:
                f.write(xml_string[(root_name_length + 2):-(root_name_length + 4)])
                train_etree_root.clear()
            with open(xml_file_path, 'ab+') as f:
                f.write(bytes('</%s>' % root_name, encoding="utf8"))

            train_list.clear()
            # xml_string = ET.tostring(etree_root, encoding='utf-8', pretty_print=True, method='xml')


            val_etree_root = ET.Element('annotations')
            tree_num = 0
            # etree_root = infer_second_data(img_dir, output_dir, etree_root, box_steps=[1.0, 0.1])
            xml_file_path = os.path.join(val_dir, 'val.xml')
            with open(xml_file_path, 'wb') as f:
                f.write(bytes('<%s>\n' % root_name, encoding="utf8"))
            for el in val_list:
                print('\rrunning: %d/%d' % (curr_idx, list_length), end='')
                img_name = el.get('name')
                img_name_start = el.get('name').split('/')[0]
                img_path_end = dataset.xml_files_[i][0].split('/')[-1]
                if img_name_start == img_path_end:
                    img_name = el.get('name').split('/')[-1]
                img_path = os.path.join(dataset.xml_files_[i][0], img_name)
       
                shutil.move(img_path, os.path.join(val_dir, img_name))
                val_etree_root.append(el)
                tree_num += 1
                if tree_num >= 1000:
                    xml_string = ET.tostring(val_etree_root, encoding='utf-8', method='xml')
                    with open(xml_file_path, 'ab+') as f:
                        f.write(xml_string[(root_name_length + 2):-(root_name_length + 4)])
                        val_etree_root.clear()
            print('writing xml')
            xml_string = ET.tostring(val_etree_root, encoding='utf-8', method='xml')
            with open(xml_file_path, 'ab+') as f:
                f.write(xml_string[(root_name_length + 2):-(root_name_length + 4)])
                val_etree_root.clear()

            val_list.clear()
            
            # xml_string = ET.tostring(etree_root, encoding='utf-8', pretty_print=True, method='xml')
            with open(xml_file_path, 'ab+') as f:
                f.write(bytes('</%s>' % root_name, encoding="utf8"))
        dataset.image_list_.clear()
    else:
        exists_masks = False
        dataset_list = [list(t) for t in zip(dataset.image_list_, dataset.label_list_)]
        list_length = dataset_list.__len__()
        if list_length > max_val_num/(1.0-ratio):
            ratio = 1.0 - max_val_num/list_length
        train_list, val_list = data_split(dataset_list, ratio, True)
        dataset_list.clear()
        curr_idx = 0
        for file_name in train_list:
            curr_idx += 1
            print('\rrunning: %d/%d' %(curr_idx, list_length), end='')
            dir_path = os.path.split(os.path.split(file_name[1])[0])[0]
            if dir_path == '/':
                dir_path = ''

            in_images_dir = input_dir + dir_path + '/images/'
            in_masks_dir = input_dir + dir_path + '/masks/'
            in_labels_dir = input_dir + dir_path + '/labels/'
            train_dir = output_dir + '/train/' + dir_path
            train_images_dir = train_dir + '/images/'
            train_masks_dir = train_dir + '/masks/'
            train_labels_dir = train_dir + '/labels/'
            image_name = os.path.split(file_name[0])[-1]
            label_name = os.path.split(file_name[1])[-1]
            if os.path.exists(in_masks_dir + label_name):
                exists_masks = True
            else:
                exists_masks = False

            if not os.path.exists(train_images_dir):
                os.makedirs(train_images_dir)
                os.makedirs(train_labels_dir)
                if exists_masks:
                    os.makedirs(train_masks_dir)

            if exists_masks:
                os.rename(in_masks_dir+label_name,
                          train_masks_dir+label_name)
            os.rename(in_labels_dir + label_name,
                      train_labels_dir + label_name)
            os.rename(in_images_dir + image_name,
                      train_images_dir + image_name)
        for file_name in val_list:
            curr_idx += 1
            print('\rrunning: %d/%d' %(curr_idx, list_length), end='')
            dir_path = os.path.split(os.path.split(file_name[1])[0])[0]
            if dir_path == '/':
                dir_path = ''

            in_images_dir = input_dir + dir_path + '/images/'
            in_masks_dir = input_dir + dir_path + '/masks/'
            in_labels_dir = input_dir + dir_path + '/labels/'
            val_dir = output_dir + '/val/' + dir_path
            val_images_dir = val_dir + '/images/'
            val_masks_dir = val_dir + '/masks/'
            val_labels_dir = val_dir + '/labels/'
            image_name = os.path.split(file_name[0])[-1]
            label_name = os.path.split(file_name[1])[-1]
            if os.path.exists(in_masks_dir + label_name):
                exists_masks = True
            else:
                exists_masks = False

            if not os.path.exists(val_images_dir):
                os.makedirs(val_images_dir)
                os.makedirs(val_labels_dir)
                if exists_masks:
                    os.makedirs(val_masks_dir)
            if exists_masks:
                os.rename(in_masks_dir+label_name,
                          val_masks_dir+label_name)
            os.rename(in_labels_dir + label_name,
                      val_labels_dir + label_name)
            os.rename(in_images_dir + image_name,
                      val_images_dir + image_name)
        print()