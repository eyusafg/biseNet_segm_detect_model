import os
from lxml import etree

def merge_cvat_xml(xml_path1, xml_path2, output_path, conflict_resolve='rename'):
    """
    合并两个CVAT标注XML文件
    
    参数：
    xml_path1 : str - 第一个XML文件路径
    xml_path2 : str - 第二个XML文件路径 
    output_path : str - 合并结果输出路径
    conflict_resolve : str - 冲突解决策略:
        'rename' : 自动重命名重复图像 (默认)
        'overwrite' : 用第二个文件覆盖重复项
        'skip' : 保留第一个文件的条目
    """
    # 解析第一个XML文件
    parser = etree.XMLParser(remove_blank_text=True)
    tree1 = etree.parse(xml_path1, parser)
    root1 = tree1.getroot()
    
    # 解析第二个XML文件
    tree2 = etree.parse(xml_path2, parser)
    root2 = tree2.getroot()
    
    # 创建索引字典（name: element）
    existing = {img.get('name'): img for img in root1.iter('image')}
    
    # 合并处理
    for img2 in root2.iter('image'):
        name = img2.get('name')
        if name in existing:
            if conflict_resolve == 'overwrite':
                root1.remove(existing[name])
                root1.append(img2)
            elif conflict_resolve == 'rename':
                new_name = f"{os.path.splitext(name)[0]}_merged{os.path.splitext(name)[1]}"
                img2.set('name', new_name)
                root1.append(img2)
            elif conflict_resolve == 'skip':
                continue
        else:
            root1.append(img2)
    
    # 保持XML格式缩进
    etree.indent(root1, space="  ")
    
    # 写入合并结果
    with open(output_path, 'wb') as f:
        f.write(b'<?xml version="1.0" encoding="utf-8"?>\n')
        f.write(etree.tostring(root1, pretty_print=True, encoding='utf-8'))

if __name__ == '__main__':

    merge_cvat_xml(
        xml_path1=r'C:\DH_data\polo_img\0915_roi\annotations.xml',
        xml_path2=r'C:\DH_data\polo_img\0925_roi\annotations.xml',
        output_path='merged_annotations.xml',
        conflict_resolve='overwrite'  # 可选：'overwrite', 'skip'
    )
