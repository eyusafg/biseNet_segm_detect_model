"""
改进的数据增强主流程
支持多进程并行处理和进度跟踪
"""
import os
import cv2
import numpy as np
import multiprocessing as mp
from typing import List, Tuple, Dict
from tqdm import tqdm
from lxml import etree
import uuid
from functools import partial

from augmentation_engine import AugmentationEngine, AugmentConfig
from label_dict import big_size_labels_dict_kpt


class AugmentedDatasetGenerator:
    """增强数据集生成器"""
    
    def __init__(self, 
                 base_path: str,
                 output_path: str,
                 background_dir: str = None,
                 num_samples_per_image: int = 30,
                 num_workers: int = 4):
        """
        Args:
            base_path: 原始数据根目录（包含images和annotations_ori.xml）
            output_path: 输出目录
            background_dir: 背景图像目录
            num_samples_per_image: 每张原始图像生成的样本数
            num_workers: 并行进程数
        """
        self.base_path = base_path
        self.output_path = output_path
        self.background_dir = background_dir
        self.num_samples = num_samples_per_image
        self.num_workers = num_workers
        
        # 配置路径
        self.image_dir = os.path.join(base_path, 'images')
        self.xml_path = os.path.join(base_path, 'annotations_ori.xml')
        
        # 输出路径
        self.output_img_dir = os.path.join(output_path, 'images')
        self.output_xml_path = os.path.join(output_path, 'annotations_auged.xml')
        
        # 创建输出目录
        os.makedirs(self.output_img_dir, exist_ok=True)
        
        # 初始化增强引擎
        self.aug_config = AugmentConfig(
            enable_color_aug=True,
            enable_geometric_aug=True,
            enable_background_aug=(background_dir is not None),
            scale_range=(0.7, 1.2),
            rotate_range=(-50, 50),
            translate_range=(0.05, 0.3),
            background_blur=True,
        )
    
    def parse_keypoints_from_xml(self, img_name: str) -> List[Tuple[float, float]]:
        """从XML文件解析关键点"""
        tree = etree.parse(self.xml_path)
        root = tree.getroot()
        
        label_dict = big_size_labels_dict_kpt
        kpt_names = list(label_dict.keys())
        kpt_dict = {kpt_name: (0, 0) for kpt_name in kpt_names}
        
        for child in root:
            if child.tag == 'image':
                if len(child) < 1:
                    continue
                
                img_path = child.get('name')
                if img_name != img_path:
                    continue
                
                for anno in child:
                    if anno.tag != 'points':
                        continue
                    
                    label_name = anno.get('label')
                    if label_name in kpt_dict:
                        points = anno.get('points').split(';')[0].split(',')
                        x, y = float(points[0]), float(points[1])
                        kpt_dict[label_name] = (x, y)
                
                # 按顺序返回关键点
                img_anno_pts = [kpt_dict[kpt_name] for kpt_name in kpt_names]
                return img_anno_pts
        
        return []
    
    def create_xml_annotation(self, image_data: Dict) -> etree.Element:
        """创建XML标注元素"""
        img_element = etree.Element('image')
        img_element.set('id', image_data['id'])
        img_element.set('name', image_data['name'])
        img_element.set('subset', 'Train')
        img_element.set('width', str(image_data['width']))
        img_element.set('height', str(image_data['height']))
        
        for point in image_data['points']:
            point_element = etree.Element('points')
            point_element.set('label', point['label'])
            point_element.set('occluded', '0')
            point_element.set('source', 'augmented')
            point_element.set('z_order', '0')
            point_element.set('points', f"{point['x']:.2f},{point['y']:.2f}")
            point_element.text = ''
            img_element.append(point_element)
        
        return img_element
    
    def process_single_image(self, img_name: str, mask_dir: str) -> List[Dict]:
        """
        处理单张图像，生成增强样本
        
        Returns:
            List of image_data dictionaries
        """
        # 加载原始图像
        img_path = os.path.join(self.image_dir, img_name)
        img = cv2.imread(img_path)
        if img is None:
            print(f"警告: 无法加载图像 {img_name}")
            return []
        
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        
        # 加载掩码
        mask_path = os.path.join(mask_dir, img_name)
        if not os.path.exists(mask_path):
            print(f"警告: 掩码不存在 {img_name}")
            return []
        
        mask = cv2.imread(mask_path, cv2.IMREAD_GRAYSCALE)
        if mask is None:
            print(f"警告: 无法加载掩码 {img_name}")
            return []
        
        # 解析关键点
        keypoints = self.parse_keypoints_from_xml(img_name)
        if not keypoints or len(keypoints) < 12:
            print(f"警告: 关键点数量不足 {img_name}")
            return []
        
        # 创建增强引擎
        engine = AugmentationEngine(self.aug_config, self.background_dir)
        
        # 批量生成增强样本
        aug_results = engine.batch_augment(img, mask, keypoints, self.num_samples)
        
        # 保存结果
        image_data_list = []
        base_name = os.path.splitext(img_name)[0]
        
        for idx, (aug_img, aug_mask, aug_kpts) in enumerate(aug_results):
            # 生成文件名
            aug_img_name = f"{base_name}_aug_{idx:04d}.png"
            aug_img_path = os.path.join(self.output_img_dir, aug_img_name)
            
            # 保存图像
            cv2.imwrite(aug_img_path, cv2.cvtColor(aug_img, cv2.COLOR_RGB2BGR))
            
            # 创建标注数据
            h, w = aug_img.shape[:2]
            image_data = self._create_image_data(aug_kpts, aug_img_name, w, h)
            
            if image_data:
                image_data_list.append(image_data)
        
        return image_data_list
    
    def _create_image_data(self, keypoints: List[Tuple], img_name: str,
                          width: int, height: int) -> Dict:
        """创建图像数据字典"""
        label_dict = big_size_labels_dict_kpt
        kpt_names = list(label_dict.keys())
        
        if len(keypoints) < len(kpt_names):
            return None
        
        point_data = []
        for i, (x, y) in enumerate(keypoints[:len(kpt_names)]):
            point_data.append({
                'label': kpt_names[i],
                'x': float(x),
                'y': float(y)
            })
        
        return {
            'id': str(uuid.uuid4()),
            'name': img_name,
            'width': width,
            'height': height,
            'points': point_data
        }
    
    def generate(self, mask_dir: str = None):
        """
        生成增强数据集
        
        Args:
            mask_dir: 掩码目录，如果为None则使用base_path/masks
        """
        if mask_dir is None:
            mask_dir = os.path.join(self.base_path, 'masks')
        
        # 获取所有图像
        img_files = [f for f in os.listdir(self.image_dir) 
                    if f.lower().endswith(('.png', '.jpg', '.jpeg'))]
        
        print(f"开始处理 {len(img_files)} 张图像...")
        print(f"每张图像生成 {self.num_samples} 个样本")
        print(f"使用 {self.num_workers} 个进程")
        
        # 创建XML根元素
        annotations = etree.Element('annotations')
        
        # 使用多进程处理（如果进程数>1）
        if self.num_workers > 1:
            pool = mp.Pool(processes=self.num_workers)
            process_func = partial(self.process_single_image, mask_dir=mask_dir)
            
            results = []
            with tqdm(total=len(img_files), desc="处理图像") as pbar:
                for result in pool.imap(process_func, img_files):
                    results.append(result)
                    pbar.update(1)
            
            pool.close()
            pool.join()
        else:
            # 单进程处理
            results = []
            for img_name in tqdm(img_files, desc="处理图像"):
                result = self.process_single_image(img_name, mask_dir)
                results.append(result)
        
        # 整合所有标注
        total_samples = 0
        for image_data_list in results:
            for image_data in image_data_list:
                xml_element = self.create_xml_annotation(image_data)
                annotations.append(xml_element)
                total_samples += 1
        
        # 保存XML文件
        tree = etree.ElementTree(annotations)
        tree.write(self.output_xml_path, pretty_print=True, 
                  encoding='utf-8', xml_declaration=True)
        
        print(f"\n✓ 增强完成!")
        print(f"  - 处理原始图像: {len(img_files)} 张")
        print(f"  - 生成增强样本: {total_samples} 张")
        print(f"  - 图像保存至: {self.output_img_dir}")
        print(f"  - 标注保存至: {self.output_xml_path}")


def main():
    """主函数"""
    # ==================== 配置参数 ====================
    BASE_PATH = r'C:\measure_size_gui\Data\sweater_data\20250731_dahuo'
    OUTPUT_PATH = r'Datasets\gened_img'
    BACKGROUND_DIR = r'Datasets\bg'
    
    # 可选：如果mask不在base_path/masks目录，可以指定
    MASK_DIR = r'C:\measure_size_gui\Data\sweater_data\20250731_dahuo\cut_out\DaHuo\masks'
    
    NUM_SAMPLES = 30  # 每张原始图像生成的样本数
    NUM_WORKERS = min(8, max(1, os.cpu_count() - 1))  # 并行进程数
    
    # ==================== 创建生成器并运行 ====================
    generator = AugmentedDatasetGenerator(
        base_path=BASE_PATH,
        output_path=OUTPUT_PATH,
        background_dir=BACKGROUND_DIR,
        num_samples_per_image=NUM_SAMPLES,
        num_workers=NUM_WORKERS
    )
    
    generator.generate(mask_dir=MASK_DIR)


if __name__ == "__main__":
    main()

