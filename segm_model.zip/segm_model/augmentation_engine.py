"""
服装图像数据增强引擎
提供颜色、几何、背景等多种增强方法
"""
import numpy as np
import cv2
import random
from typing import Tuple, List, Optional
from dataclasses import dataclass


@dataclass
class AugmentConfig:
    """增强配置参数"""
    # 颜色增强
    enable_color_aug: bool = True
    color_methods: List[str] = None  # ['hsv_shift', 'lab_transform', 'texture_preserving']
    
    # 几何增强
    enable_geometric_aug: bool = True
    scale_range: Tuple[float, float] = (0.7, 1.2)
    rotate_range: Tuple[float, float] = (-45, 45)
    translate_range: Tuple[float, float] = (0.05, 0.25)
    
    # 背景增强
    enable_background_aug: bool = True
    background_blur: bool = True
    
    def __post_init__(self):
        if self.color_methods is None:
            self.color_methods = ['hsv_shift', 'lab_transform', 'texture_preserving', 
                                 'saturation_boost', 'hue_rotate', 'monochrome']


class ColorAugmentor:
    """颜色增强器 - 专注于保留纹理的颜色变换"""
    
    @staticmethod
    def hsv_color_shift(img: np.ndarray, mask: np.ndarray, 
                       hue_shift: Optional[float] = None,
                       sat_scale: Optional[float] = None) -> np.ndarray:
        """
        HSV颜色空间变换，保留原始亮度和纹理
        
        Args:
            img: RGB图像 (uint8)
            mask: 二值掩码
            hue_shift: 色相偏移 (-180~180)，None则随机
            sat_scale: 饱和度缩放 (0.3~2.5)，None则随机
        """
        if img.dtype != np.uint8:
            img = np.clip(img, 0, 255).astype(np.uint8)
        
        result = img.copy()
        cloth_mask = mask > 0
        
        if not np.any(cloth_mask):
            return result
        
        # 转换到HSV空间
        hsv = cv2.cvtColor(img, cv2.COLOR_RGB2HSV).astype(np.float32)
        h, s, v = cv2.split(hsv)
        
        # 保存原始亮度（纹理信息）
        original_v = v.copy()
        
        # 应用变换
        if hue_shift is None:
            hue_shift = np.random.uniform(-180, 180)
        if sat_scale is None:
            sat_scale = np.random.uniform(0.5, 2.0)
        
        # 仅在掩码区域变换
        h[cloth_mask] = (h[cloth_mask] + hue_shift) % 180
        s[cloth_mask] = np.clip(s[cloth_mask] * sat_scale, 0, 255)
        v[cloth_mask] = original_v[cloth_mask]  # 保留原始亮度
        
        # 转换回RGB
        hsv_transformed = cv2.merge([h, s, v]).astype(np.uint8)
        result = cv2.cvtColor(hsv_transformed, cv2.COLOR_HSV2RGB)
        
        return result
    
    @staticmethod
    def lab_color_transform(img: np.ndarray, mask: np.ndarray,
                           a_scale: Optional[float] = None,
                           b_scale: Optional[float] = None) -> np.ndarray:
        """
        LAB颜色空间变换，保留亮度通道
        
        Args:
            img: RGB图像
            mask: 二值掩码
            a_scale: a通道缩放因子
            b_scale: b通道缩放因子
        """
        if img.dtype != np.uint8:
            img = np.clip(img, 0, 255).astype(np.uint8)
        
        result = img.copy()
        cloth_mask = mask > 0
        
        if not np.any(cloth_mask):
            return result
        
        # 转换到LAB空间
        lab = cv2.cvtColor(img, cv2.COLOR_RGB2LAB).astype(np.float32)
        l, a, b = cv2.split(lab)
        
        # 保存原始亮度
        original_l = l.copy()
        
        # 随机生成变换参数
        if a_scale is None:
            a_scale = np.random.uniform(0.6, 1.6)
        if b_scale is None:
            b_scale = np.random.uniform(0.6, 1.6)
        
        a_shift = np.random.uniform(-40, 40)
        b_shift = np.random.uniform(-40, 40)
        
        # 应用变换（仅在掩码区域）
        a[cloth_mask] = np.clip(
            (a[cloth_mask] - 128) * a_scale + 128 + a_shift, 
            0, 255
        )
        b[cloth_mask] = np.clip(
            (b[cloth_mask] - 128) * b_scale + 128 + b_shift, 
            0, 255
        )
        l[cloth_mask] = original_l[cloth_mask]  # 保留原始亮度
        
        # 转换回RGB
        lab_transformed = cv2.merge([l, a, b]).astype(np.uint8)
        result = cv2.cvtColor(lab_transformed, cv2.COLOR_LAB2RGB)
        
        return result
    
    @staticmethod
    def texture_preserving_monochrome(img: np.ndarray, mask: np.ndarray,
                                     target_hue: Optional[int] = None) -> np.ndarray:
        """
        单色变换，完美保留纹理细节
        
        Args:
            img: RGB图像
            mask: 二值掩码
            target_hue: 目标色相 (0-180)，None则随机
        """
        if img.dtype != np.uint8:
            img = np.clip(img, 0, 255).astype(np.uint8)
        
        result = img.copy()
        cloth_mask = mask > 0
        
        if not np.any(cloth_mask):
            return result
        
        # 获取原始亮度信息
        hsv = cv2.cvtColor(img, cv2.COLOR_RGB2HSV)
        original_v = hsv[:, :, 2].copy()
        
        # 生成单色HSV图像
        if target_hue is None:
            target_hue = np.random.randint(0, 180)
        
        saturation = np.random.randint(50, 200)
        
        mono_hsv = hsv.copy()
        mono_hsv[cloth_mask, 0] = target_hue
        mono_hsv[cloth_mask, 1] = saturation
        mono_hsv[cloth_mask, 2] = original_v[cloth_mask]  # 保留原始亮度
        
        result = cv2.cvtColor(mono_hsv, cv2.COLOR_HSV2RGB)
        
        return result
    
    @staticmethod
    def apply_random_color_augmentation(img: np.ndarray, mask: np.ndarray,
                                       method: Optional[str] = None) -> np.ndarray:
        """
        随机应用一种颜色增强方法
        
        Args:
            img: RGB图像
            mask: 二值掩码
            method: 指定方法名，None则随机选择
        """
        methods = {
            'hsv_shift': ColorAugmentor.hsv_color_shift,
            'lab_transform': ColorAugmentor.lab_color_transform,
            'monochrome': ColorAugmentor.texture_preserving_monochrome,
        }
        
        if method is None:
            method = random.choice(list(methods.keys()))
        
        if method in methods:
            return methods[method](img, mask)
        else:
            return img.copy()


class GeometricAugmentor:
    """几何变换增强器"""
    
    @staticmethod
    def safe_affine_transform(img: np.ndarray, mask: np.ndarray, 
                             keypoints: List[Tuple[float, float]],
                             scale: float, angle: float,
                             tx: float, ty: float) -> Tuple[np.ndarray, np.ndarray, List]:
        """
        安全的仿射变换，确保物体不会超出边界
        
        Args:
            img: 输入图像
            mask: 掩码
            keypoints: 关键点列表 [(x1,y1), (x2,y2), ...]
            scale: 缩放比例
            angle: 旋转角度（度）
            tx, ty: 平移像素数
            
        Returns:
            transformed_img, transformed_mask, transformed_keypoints
        """
        h, w = img.shape[:2]
        center = (w / 2, h / 2)
        
        # 构建变换矩阵
        M = cv2.getRotationMatrix2D(center, angle, scale)
        M[0, 2] += tx
        M[1, 2] += ty
        
        # 应用变换
        transformed_img = cv2.warpAffine(img, M, (w, h), 
                                        borderMode=cv2.BORDER_CONSTANT,
                                        borderValue=(0, 0, 0))
        transformed_mask = cv2.warpAffine(mask, M, (w, h),
                                         borderMode=cv2.BORDER_CONSTANT,
                                         borderValue=0)
        
        # 变换关键点
        transformed_kpts = []
        for x, y in keypoints:
            # 应用仿射变换
            new_x = M[0, 0] * x + M[0, 1] * y + M[0, 2]
            new_y = M[1, 0] * x + M[1, 1] * y + M[1, 2]
            transformed_kpts.append((new_x, new_y))
        
        return transformed_img, transformed_mask, transformed_kpts
    
    @staticmethod
    def random_geometric_augmentation(img: np.ndarray, mask: np.ndarray,
                                     keypoints: List[Tuple[float, float]],
                                     config: AugmentConfig,
                                     max_attempts: int = 5) -> Tuple:
        """
        随机几何增强，带有效性验证
        
        Returns:
            (aug_img, aug_mask, aug_kpts, success)
        """
        h, w = img.shape[:2]
        original_area = np.sum(mask > 0)
        
        for attempt in range(max_attempts):
            # 随机生成变换参数
            scale = np.random.uniform(*config.scale_range)
            angle = np.random.uniform(*config.rotate_range)
            
            translate_ratio = np.random.uniform(*config.translate_range)
            tx = np.random.uniform(-translate_ratio * w, translate_ratio * w)
            ty = np.random.uniform(-translate_ratio * h, translate_ratio * h)
            
            # 应用变换
            aug_img, aug_mask, aug_kpts = GeometricAugmentor.safe_affine_transform(
                img, mask, keypoints, scale, angle, tx, ty
            )
            
            # 验证变换质量
            current_area = np.sum(aug_mask > 0)
            area_ratio = current_area / original_area if original_area > 0 else 0
            
            # 检查条件：
            # 1. 物体面积保留至少70%
            # 2. 所有关键点在图像范围内
            if area_ratio < 0.7:
                continue
            
            valid_kpts = all(
                0 <= x < w and 0 <= y < h 
                for x, y in aug_kpts
            )
            
            if valid_kpts and len(aug_kpts) >= len(keypoints):
                return aug_img, aug_mask, aug_kpts, True
        
        # 所有尝试失败，返回原始数据
        return img, mask, keypoints, False


class BackgroundAugmentor:
    """背景增强器"""
    
    def __init__(self, background_dir: str):
        """
        Args:
            background_dir: 背景图像目录
        """
        self.background_dir = background_dir
        self.bg_cache = []
        self._load_backgrounds()
    
    def _load_backgrounds(self):
        """预加载背景图像路径"""
        import os
        if not os.path.exists(self.background_dir):
            print(f"警告: 背景目录不存在: {self.background_dir}")
            return
        
        bg_files = [f for f in os.listdir(self.background_dir) 
                   if f.lower().endswith(('.png', '.jpg', '.jpeg'))]
        self.bg_cache = [os.path.join(self.background_dir, f) for f in bg_files]
    
    def replace_background(self, img: np.ndarray, mask: np.ndarray,
                          blur_edge: bool = True) -> np.ndarray:
        """
        替换背景，支持边缘模糊融合
        
        Args:
            img: 前景图像
            mask: 前景掩码
            blur_edge: 是否模糊边缘
        """
        if len(self.bg_cache) == 0:
            return img
        
        # 随机选择背景
        bg_path = random.choice(self.bg_cache)
        bg = cv2.imread(bg_path)
        
        if bg is None:
            return img
        
        # 调整背景大小
        bg = cv2.cvtColor(bg, cv2.COLOR_BGR2RGB)
        if bg.shape[:2] != img.shape[:2]:
            bg = cv2.resize(bg, (img.shape[1], img.shape[0]))
        
        # 边缘模糊处理
        if blur_edge:
            # 使用高斯模糊创建平滑的alpha通道
            mask_blur = cv2.GaussianBlur(mask, (15, 15), 0).astype(np.float32) / 255.0
        else:
            mask_blur = (mask > 0).astype(np.float32)
        
        # Alpha混合
        mask_3d = np.stack([mask_blur] * 3, axis=-1)
        result = (img.astype(np.float32) * mask_3d + 
                 bg.astype(np.float32) * (1 - mask_3d))
        
        return np.clip(result, 0, 255).astype(np.uint8)


class AugmentationEngine:
    """数据增强引擎 - 统一管理所有增强操作"""
    
    def __init__(self, config: AugmentConfig, background_dir: Optional[str] = None):
        """
        Args:
            config: 增强配置
            background_dir: 背景图像目录
        """
        self.config = config
        self.color_aug = ColorAugmentor()
        self.geo_aug = GeometricAugmentor()
        
        if background_dir and config.enable_background_aug:
            self.bg_aug = BackgroundAugmentor(background_dir)
        else:
            self.bg_aug = None
    
    def augment(self, img: np.ndarray, mask: np.ndarray,
                keypoints: List[Tuple[float, float]],
                color_method: Optional[str] = None) -> Tuple:
        """
        执行完整的数据增强流程
        
        Args:
            img: 输入图像 (RGB, uint8)
            mask: 二值掩码
            keypoints: 关键点列表
            color_method: 指定颜色变换方法（可选）
            
        Returns:
            (aug_img, aug_mask, aug_keypoints, success)
        """
        aug_img = img.copy()
        aug_mask = mask.copy()
        aug_kpts = keypoints.copy()
        
        # 1. 几何变换
        if self.config.enable_geometric_aug:
            aug_img, aug_mask, aug_kpts, success = \
                self.geo_aug.random_geometric_augmentation(
                    aug_img, aug_mask, aug_kpts, self.config
                )
            if not success:
                return img, mask, keypoints, False
        
        # 2. 颜色变换
        if self.config.enable_color_aug:
            if color_method is None:
                color_method = random.choice(self.config.color_methods)
            
            aug_img = self.color_aug.apply_random_color_augmentation(
                aug_img, aug_mask, method=color_method
            )
        
        # 3. 背景替换
        if self.bg_aug is not None and self.config.enable_background_aug:
            aug_img = self.bg_aug.replace_background(
                aug_img, aug_mask, blur_edge=self.config.background_blur
            )
        
        return aug_img, aug_mask, aug_kpts, True
    
    def batch_augment(self, img: np.ndarray, mask: np.ndarray,
                     keypoints: List[Tuple[float, float]],
                     num_samples: int) -> List[Tuple]:
        """
        批量生成增强样本
        
        Returns:
            List of (aug_img, aug_mask, aug_keypoints)
        """
        results = []
        attempts = 0
        max_attempts = num_samples * 3  # 最多尝试3倍次数
        
        while len(results) < num_samples and attempts < max_attempts:
            aug_img, aug_mask, aug_kpts, success = self.augment(img, mask, keypoints)
            
            if success:
                results.append((aug_img, aug_mask, aug_kpts))
            
            attempts += 1
        
        if len(results) < num_samples:
            print(f"警告: 只生成了 {len(results)}/{num_samples} 个有效样本")
        
        return results


# ==================== 便捷函数 ====================

def create_default_augmentor(background_dir: str = None) -> AugmentationEngine:
    """创建默认配置的增强器"""
    config = AugmentConfig(
        enable_color_aug=True,
        enable_geometric_aug=True,
        enable_background_aug=(background_dir is not None),
        scale_range=(0.75, 1.15),
        rotate_range=(-40, 40),
        translate_range=(0.05, 0.2),
    )
    return AugmentationEngine(config, background_dir)


def quick_augment(img: np.ndarray, mask: np.ndarray,
                 keypoints: List[Tuple[float, float]],
                 num_samples: int = 10,
                 background_dir: str = None) -> List[Tuple]:
    """
    快速增强接口
    
    Args:
        img: RGB图像
        mask: 二值掩码
        keypoints: 关键点列表
        num_samples: 生成样本数
        background_dir: 背景图像目录
        
    Returns:
        List of (aug_img, aug_mask, aug_keypoints)
    """
    engine = create_default_augmentor(background_dir)
    return engine.batch_augment(img, mask, keypoints, num_samples)

